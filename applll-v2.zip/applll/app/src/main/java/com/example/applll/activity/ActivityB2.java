package com.example.applll.activity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.applll.R;
import com.example.applll.Utility;
import com.example.applll.service.DbManger;
import com.example.applll.service.MySQLiteHelper;

public class ActivityB2 extends AppCompatActivity {

    private MySQLiteHelper helper = DbManger.getIntance(this);

    private String[] args1 = {"acc_ID","CLSBDM","LTZ1", "LTZ2", "LTZ3", "LTZ4", "LTY1", "LTY2", "LTY3", "LTY4", "LWZ1", "LWZ2",
            "LWZ3", "LWZ4", "LWY1", "LWY2", "LWY3", "LWY4", "CMZ1", "CMZ2", "CMY1", "CMY2", "CCZ1", "CCZ2", "CCY1", "CCY2",
            "YZBZ", "YZBY", "CDZ1", "CDZ2", "CDZ3", "CDZ4", "CDY1", "CDY2", "CDY3", "CDY4", "HSJZ", "HSJY", "BXGQB", "BXGHB",
            "FDBLQB", "FDBLHB", "YGQ", "PZSX", "JSSDG", "JSSHWB", "CXQBZC", "CXHBZC", "CXZBBZC", "CXDBZC", "CXYBBZC", "CDDB",
            "DP", "BT", "PQG", "CHZHQ"};
    private String[] args3={ "acc_ID","CLSBDM","WZ", "DY", "XDCSSCD", "JYKWZ", "CZ", "YL", "YXSSCD", "FDONGJ", "FDIANJ", "QDJ",
            "CYB", "DHXQ", "JYLQQ", "KQLQQ", "ZKZLQ", "BXH", "BSQLHQ", "SRQ", "LNQ", "JQQG", "PQQG", "WLZYQ", "LQYG", "QXYG",
            "ZDYG", "ZLZXYG", "KTYSJ", "ABSKZQ", "ZQDA", "YQDA", "LQFS", "YBB", "ZXP", "GFJ", "YSPBFQ", "DYQ", "ZQDB", "ZQM",
            "ZHM", "JXH", "STX", "JSWZY", "FJSZY", "HPZY", "YQDB", "YQM", "YHM", "QBZC", "ZBBZC", "DBZC", "ZHCD", "ZYWP",
            "HBZC", "YBBZC", "DB", "YHCD", "SSCD"};
    private String[] args10={"acc_ID","CLSBDM","MYQS","QHBW"};

    private TextView myqsshow, ltz1show, ltz2show, ltz3show, ltz4show, lty1show, lty2show, lty3show, lty4show, lwz1show,
            lwz2show, lwz3show, lwz4show, lwy1show, lwy2show, lwy3show, lwy4show, cmz1show, cmz2show, cmy1show, cmy2show,
            ccz1show, ccz2show, ccy1show, ccy2show, yzbzshow, yzbyshow, cdz1show, cdz2show, cdz3show, cdz4show, cdy1show,
            cdy2show, cdy3show, cdy4show, hsjzshow, hsjyshow, bxgqbshow, bxghbshow, fdblqbshow, fdblhbshow, ygqshow,
            pzsxshow, jssdgshow, jsshwbshow, cxqbzcshow, cxhbzcshow, cxzbbzcshow, cxybbzcshow, cxdbzcshow, cxdbshow, dpshow,
            btshow, pqgshow, chzhqshow, wzshow, dyshow, xdcsscdshow, jykwzshow, czshow, ylshow, yxsscdshow, fdongjshow,
            fdianjshow, qdjshow, cybshow, dhxqshow, jylqqshow, kqlqqshow, zkzlqshow, bxhshow, bsqlhqshow, srqshow, lnqshow,
            jqqgshow, pqqgshow, wlzyqshow, lqygshow, qxygshow, zdygshow, zlzxygshow, ktysjshow, ABSkzqshow, zqdAshow,
            yqdAshow, lqfsshow, ybbshow, zxpshow, gfjshow, yspbfqshow, dyqshow, zqdBshow, zqmshow, zhmshow, jxhshow, stxshow,
            jswzyshow, fjszyshow, hpzyshow, yqdBshow, yqmshow, yhmshow, qbzcshow, zbbzcshow, dbzcshow, zhcdshow, hbzcshow,
            ybbzcshow, dbshow, yhcdshow, sscdshow;

    private Spinner myqs, ltz1, ltz2, ltz3, ltz4, lty1, lty2, lty3, lty4, lwz1, lwz2, lwz3, lwz4, lwy1, lwy2, lwy3, lwy4, cmz1, cmz2,
            cmy1, cmy2, ccz1, ccz2, ccy1, ccy2, yzbz, yzby, cdz1, cdz2, cdz3, cdz4, cdy1, cdy2, cdy3, cdy4, hsjz, hsjy, bxgqb, bxghb,
            fdblqb, fdblhb, ygq, jssdg, cxqbzc, cxzbbzc, cxybbzc, dp, pqg, pzsx, jsshwb, cxhbzc, cxdbzc, cxdb, bt, chzhq, wz, dy,
            xdcsscd, jykwz, cz, yl, yxsscd, fdongj, fdianj, qdj, cyb, dhxq, jylqq, kqlqq, zkzlq, bxh, bsqlhq, srq, lnq, jqqg, pqqg,
            wlzyq, lqyg, qxyg, zdyg, zlzxyg, ktysj, ABSkzq, zqdA, yqdA, lqfs, ybb, zxp, gfj, yspbfq, dyq, zqdB, zqm, zhm, jxh, stx,
            jswzy, fjszy, hpzy, yqdB, yqm, yhm, qbzc, zbbzc, dbzc, zhcd, hbzc, ybbzc, db, yhcd, sscd;

    private EditText qhbw, zywp;
    String acc_ID_time,clsbdm,wjm;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_b2);

        Intent intent0=getIntent();
        acc_ID_time=intent0.getStringExtra("acc_ID_time");
        clsbdm=intent0.getStringExtra("clsbdm");
        wjm=intent0.getStringExtra("wjm");
        myqsshow = findViewById(R.id.b2_tv_show_myqs);
        ltz1show = findViewById(R.id.b2_tv_show_ltz1);
        ltz2show = findViewById(R.id.b2_tv_show_ltz2);
        ltz3show = findViewById(R.id.b2_tv_show_ltz3);
        ltz4show = findViewById(R.id.b2_tv_show_ltz4);
        lty1show = findViewById(R.id.b2_tv_show_lty1);
        lty2show = findViewById(R.id.b2_tv_show_lty2);
        lty3show = findViewById(R.id.b2_tv_show_lty3);
        lty4show = findViewById(R.id.b2_tv_show_lty4);
        lwz1show = findViewById(R.id.b2_tv_show_lwz1);
        lwz2show = findViewById(R.id.b2_tv_show_lwz2);
        lwz3show = findViewById(R.id.b2_tv_show_lwz3);
        lwz4show = findViewById(R.id.b2_tv_show_lwz4);
        lwy1show = findViewById(R.id.b2_tv_show_lwy1);
        lwy2show = findViewById(R.id.b2_tv_show_lwy2);
        lwy3show = findViewById(R.id.b2_tv_show_lwy3);
        lwy4show = findViewById(R.id.b2_tv_show_lwy4);
        cmz1show = findViewById(R.id.b2_tv_show_cmz1);
        cmz2show = findViewById(R.id.b2_tv_show_cmz2);
        cmy1show = findViewById(R.id.b2_tv_show_cmy1);
        cmy2show = findViewById(R.id.b2_tv_show_cmy2);
        ccz1show = findViewById(R.id.b2_tv_show_ccz1);
        ccz2show = findViewById(R.id.b2_tv_show_ccz2);
        ccy1show = findViewById(R.id.b2_tv_show_ccy1);
        ccy2show = findViewById(R.id.b2_tv_show_ccy2);
        yzbzshow = findViewById(R.id.b2_tv_show_yzbz);
        yzbyshow = findViewById(R.id.b2_tv_show_yzby);
        cdz1show = findViewById(R.id.b2_tv_show_cdz1);
        cdz2show = findViewById(R.id.b2_tv_show_cdz2);
        cdz3show = findViewById(R.id.b2_tv_show_cdz3);
        cdz4show = findViewById(R.id.b2_tv_show_cdz4);
        cdy1show = findViewById(R.id.b2_tv_show_cdy1);
        cdy2show = findViewById(R.id.b2_tv_show_cdy2);
        cdy3show = findViewById(R.id.b2_tv_show_cdy3);
        cdy4show = findViewById(R.id.b2_tv_show_cdy4);
        hsjzshow = findViewById(R.id.b2_tv_show_hsjz);
        hsjyshow = findViewById(R.id.b2_tv_show_hsjy);
        bxgqbshow = findViewById(R.id.b2_tv_show_bxgqb);
        bxghbshow = findViewById(R.id.b2_tv_show_bxghb);
        fdblqbshow = findViewById(R.id.b2_tv_show_fdblqb);
        fdblhbshow = findViewById(R.id.b2_tv_show_fdblhb);
        ygqshow = findViewById(R.id.b2_tv_show_ygq);
        pzsxshow = findViewById(R.id.b2_tv_show_pzsx);
        jssdgshow = findViewById(R.id.b2_tv_show_jssdg);
        jsshwbshow = findViewById(R.id.b2_tv_show_jsshwb);
        cxqbzcshow = findViewById(R.id.b2_tv_show_cxqbzc);
        cxhbzcshow = findViewById(R.id.b2_tv_show_cxhbzc);
        cxzbbzcshow = findViewById(R.id.b2_tv_show_cxzbbzc);
        cxdbzcshow = findViewById(R.id.b2_tv_show_cxdbzc);
        cxybbzcshow = findViewById(R.id.b2_tv_show_cxybbzc);
        cxdbshow = findViewById(R.id.b2_tv_show_cxdb);
        dpshow = findViewById(R.id.b2_tv_show_dp);
        btshow = findViewById(R.id.b2_tv_show_bt);
        pqgshow = findViewById(R.id.b2_tv_show_pqg);
        chzhqshow = findViewById(R.id.b2_tv_show_chzhq);
        wzshow = findViewById(R.id.b2_tv_show_wz);
        dyshow = findViewById(R.id.b2_tv_show_dy);
        xdcsscdshow = findViewById(R.id.b2_tv_show_xdcsscd);
        jykwzshow = findViewById(R.id.b2_tv_show_jykwz);
        czshow = findViewById(R.id.b2_tv_show_cz);
        ylshow = findViewById(R.id.b2_tv_show_yl);
        yxsscdshow = findViewById(R.id.b2_tv_show_yxsscd);
        fdongjshow = findViewById(R.id.b2_tv_show_fdongj);
        fdianjshow = findViewById(R.id.b2_tv_show_fdianj);
        qdjshow = findViewById(R.id.b2_tv_show_qdj);
        cybshow = findViewById(R.id.b2_tv_show_cyb);
        dhxqshow = findViewById(R.id.b2_tv_show_dhxq);
        jylqqshow = findViewById(R.id.b2_tv_show_jylqq);
        kqlqqshow = findViewById(R.id.b2_tv_show_kqlqq);
        zkzlqshow = findViewById(R.id.b2_tv_show_zkzlq);
        bxhshow = findViewById(R.id.b2_tv_show_bxh);
        bsqlhqshow = findViewById(R.id.b2_tv_show_bsqlhq);
        srqshow = findViewById(R.id.b2_tv_show_srq);
        lnqshow = findViewById(R.id.b2_tv_show_lnq);
        jqqgshow = findViewById(R.id.b2_tv_show_jqqg);
        pqqgshow = findViewById(R.id.b2_tv_show_pqqg);
        wlzyqshow = findViewById(R.id.b2_tv_show_wlzyq);
        lqygshow = findViewById(R.id.b2_tv_show_lqyg);
        qxygshow = findViewById(R.id.b2_tv_show_qxyg);
        zdygshow = findViewById(R.id.b2_tv_show_zdyg);
        zlzxygshow = findViewById(R.id.b2_tv_show_zlzxyg);
        ktysjshow = findViewById(R.id.b2_tv_show_ktysj);
        ABSkzqshow = findViewById(R.id.b2_tv_show_ABSkzq);
        zqdAshow = findViewById(R.id.b2_tv_show_zqdA);
        yqdAshow = findViewById(R.id.b2_tv_show_yqdA);
        lqfsshow = findViewById(R.id.b2_tv_show_lqfs);
        ybbshow = findViewById(R.id.b2_tv_show_ybb);
        zxpshow = findViewById(R.id.b2_tv_show_zxp);
        gfjshow = findViewById(R.id.b2_tv_show_gfj);
        yspbfqshow = findViewById(R.id.b2_tv_show_yspbfq);
        dyqshow = findViewById(R.id.b2_tv_show_dyq);
        zqdBshow = findViewById(R.id.b2_tv_show_zqdB);
        zqmshow = findViewById(R.id.b2_tv_show_zqm);
        zhmshow = findViewById(R.id.b2_tv_show_zhm);
        jxhshow = findViewById(R.id.b2_tv_show_jxh);
        stxshow = findViewById(R.id.b2_tv_show_stx);
        jswzyshow = findViewById(R.id.b2_tv_show_jswzy);
        fjszyshow = findViewById(R.id.b2_tv_show_fjszy);
        hpzyshow = findViewById(R.id.b2_tv_show_hpzy);
        yqdBshow = findViewById(R.id.b2_tv_show_yqdB);
        yqmshow = findViewById(R.id.b2_tv_show_yqm);
        yhmshow = findViewById(R.id.b2_tv_show_yhm);
        qbzcshow = findViewById(R.id.b2_tv_show_qbzc);
        zbbzcshow = findViewById(R.id.b2_tv_show_zbbzc);
        dbzcshow = findViewById(R.id.b2_tv_show_dbzc);
        zhcdshow = findViewById(R.id.b2_tv_show_zhcd);
        hbzcshow = findViewById(R.id.b2_tv_show_hbzc);
        ybbzcshow = findViewById(R.id.b2_tv_show_ybbzc);
        dbshow = findViewById(R.id.b2_tv_show_db);
        yhcdshow = findViewById(R.id.b2_tv_show_yhcd);
        sscdshow = findViewById(R.id.b2_tv_show_sscd);

        myqs = findViewById(R.id.b2_sp_myqs);
        ltz1 = findViewById(R.id.b2_sp_ltz1);
        ltz2 = findViewById(R.id.b2_sp_ltz2);
        ltz3 = findViewById(R.id.b2_sp_ltz3);
        ltz4 = findViewById(R.id.b2_sp_ltz4);
        lty1 = findViewById(R.id.b2_sp_lty1);
        lty2 = findViewById(R.id.b2_sp_lty2);
        lty3 = findViewById(R.id.b2_sp_lty3);
        lty4 = findViewById(R.id.b2_sp_lty4);
        lwz1 = findViewById(R.id.b2_sp_lwz1);
        lwz2 = findViewById(R.id.b2_sp_lwz2);
        lwz3 = findViewById(R.id.b2_sp_lwz3);
        lwz4 = findViewById(R.id.b2_sp_lwz4);
        lwy1 = findViewById(R.id.b2_sp_lwy1);
        lwy2 = findViewById(R.id.b2_sp_lwy2);
        lwy3 = findViewById(R.id.b2_sp_lwy3);
        lwy4 = findViewById(R.id.b2_sp_lwy4);
        cmz1 = findViewById(R.id.b2_sp_cmz1);
        cmz2 = findViewById(R.id.b2_sp_cmz2);
        cmy1 = findViewById(R.id.b2_sp_cmy1);
        cmy2 = findViewById(R.id.b2_sp_cmy2);
        ccz1 = findViewById(R.id.b2_sp_ccz1);
        ccz2 = findViewById(R.id.b2_sp_ccz2);
        ccy1 = findViewById(R.id.b2_sp_ccy1);
        ccy2 = findViewById(R.id.b2_sp_ccy2);
        yzbz = findViewById(R.id.b2_sp_yzbz);
        yzby = findViewById(R.id.b2_sp_yzby);
        cdz1 = findViewById(R.id.b2_sp_cdz1);
        cdz2 = findViewById(R.id.b2_sp_cdz2);
        cdz3 = findViewById(R.id.b2_sp_cdz3);
        cdz4 = findViewById(R.id.b2_sp_cdz4);
        cdy1 = findViewById(R.id.b2_sp_cdy1);
        cdy2 = findViewById(R.id.b2_sp_cdy2);
        cdy3 = findViewById(R.id.b2_sp_cdy3);
        cdy4 = findViewById(R.id.b2_sp_cdy4);
        hsjz = findViewById(R.id.b2_sp_hsjz);
        hsjy = findViewById(R.id.b2_sp_hsjy);
        bxgqb = findViewById(R.id.b2_sp_bxgqb);
        bxghb = findViewById(R.id.b2_sp_bxghb);
        fdblqb = findViewById(R.id.b2_sp_fdblqb);
        fdblhb = findViewById(R.id.b2_sp_fdblhb);
        ygq = findViewById(R.id.b2_sp_ygq);
        jssdg = findViewById(R.id.b2_sp_jssdg);
        cxqbzc = findViewById(R.id.b2_sp_cxqbzc);
        cxzbbzc = findViewById(R.id.b2_sp_cxzbbzc);
        cxybbzc = findViewById(R.id.b2_sp_cxybbzc);
        dp = findViewById(R.id.b2_sp_dp);
        pqg = findViewById(R.id.b2_sp_pqg);
        pzsx = findViewById(R.id.b2_sp_pzsx);
        jsshwb = findViewById(R.id.b2_sp_jsshwb);
        cxhbzc = findViewById(R.id.b2_sp_cxhbzc);
        cxdbzc = findViewById(R.id.b2_sp_cxdbzc);
        cxdb = findViewById(R.id.b2_sp_cxdb);
        bt = findViewById(R.id.b2_sp_bt);
        chzhq = findViewById(R.id.b2_sp_chzhq);
        wz = findViewById(R.id.b2_sp_wz);
        dy = findViewById(R.id.b2_sp_dy);
        xdcsscd = findViewById(R.id.b2_sp_xdcsscd);
        jykwz = findViewById(R.id.b2_sp_jykwz);
        cz = findViewById(R.id.b2_sp_cz);
        yl = findViewById(R.id.b2_sp_yl);
        yxsscd = findViewById(R.id.b2_sp_yxsscd);
        fdongj = findViewById(R.id.b2_sp_fdongj);
        fdianj = findViewById(R.id.b2_sp_fdianj);
        qdj = findViewById(R.id.b2_sp_qdj);
        cyb = findViewById(R.id.b2_sp_cyb);
        dhxq = findViewById(R.id.b2_sp_dhxq);
        jylqq = findViewById(R.id.b2_sp_jylqq);
        kqlqq = findViewById(R.id.b2_sp_kqlqq);
        zkzlq = findViewById(R.id.b2_sp_zkzlq);
        bxh = findViewById(R.id.b2_sp_bxh);
        bsqlhq = findViewById(R.id.b2_sp_bsqlhq);
        srq = findViewById(R.id.b2_sp_srq);
        lnq = findViewById(R.id.b2_sp_lnq);
        jqqg = findViewById(R.id.b2_sp_jqqg);
        pqqg = findViewById(R.id.b2_sp_pqqg);
        wlzyq = findViewById(R.id.b2_sp_wlzyq);
        lqyg = findViewById(R.id.b2_sp_lqyg);
        qxyg = findViewById(R.id.b2_sp_qxyg);
        zdyg = findViewById(R.id.b2_sp_zdyg);
        zlzxyg = findViewById(R.id.b2_sp_zlzxyg);
        ktysj = findViewById(R.id.b2_sp_ktysj);
        ABSkzq = findViewById(R.id.b2_sp_ABSkzq);
        zqdA = findViewById(R.id.b2_sp_zqdA);
        yqdA = findViewById(R.id.b2_sp_yqdA);
        lqfs = findViewById(R.id.b2_sp_lqfs);
        ybb = findViewById(R.id.b2_sp_ybb);
        zxp = findViewById(R.id.b2_sp_zxp);
        gfj = findViewById(R.id.b2_sp_gfj);
        yspbfq = findViewById(R.id.b2_sp_yspbfq);
        dyq = findViewById(R.id.b2_sp_dyq);
        zqdB = findViewById(R.id.b2_sp_zqdB);
        zqm = findViewById(R.id.b2_sp_zqm);
        zhm = findViewById(R.id.b2_sp_zhm);
        jxh = findViewById(R.id.b2_sp_jxh);
        stx = findViewById(R.id.b2_sp_stx);
        jswzy = findViewById(R.id.b2_sp_jswzy);
        fjszy = findViewById(R.id.b2_sp_fjszy);
        hpzy = findViewById(R.id.b2_sp_hpzy);
        yqdB = findViewById(R.id.b2_sp_yqdB);
        yqm = findViewById(R.id.b2_sp_yqm);
        yhm = findViewById(R.id.b2_sp_yhm);
        qbzc = findViewById(R.id.b2_sp_qbzc);
        zbbzc = findViewById(R.id.b2_sp_zbbzc);
        dbzc = findViewById(R.id.b2_sp_dbzc);
        zhcd = findViewById(R.id.b2_sp_zhcd);
        hbzc = findViewById(R.id.b2_sp_hbzc);
        ybbzc = findViewById(R.id.b2_sp_ybbzc);
        db = findViewById(R.id.b2_sp_db);
        yhcd = findViewById(R.id.b2_sp_yhcd);
        sscd = findViewById(R.id.b2_sp_sscd);

        qhbw = findViewById(R.id.b2_et_qhbw);
        zywp = findViewById(R.id.b2_et_zywp);

        Utility.ifOrnot(this, myqs, myqsshow);
        Utility.ifOrnot(this, ltz1, ltz1show);
        Utility.ifOrnot(this, ltz2, ltz2show);
        Utility.ifOrnot(this, ltz3, ltz3show);
        Utility.ifOrnot(this, ltz4, ltz4show);
        Utility.ifOrnot(this, lty1, lty1show);
        Utility.ifOrnot(this, lty2, lty2show);
        Utility.ifOrnot(this, lty3, lty3show);
        Utility.ifOrnot(this, lty4, lty4show);
        Utility.ifOrnot(this, lwz1, lwz1show);
        Utility.ifOrnot(this, lwz2, lwz2show);
        Utility.ifOrnot(this, lwz3, lwz3show);
        Utility.ifOrnot(this, lwz4, lwz4show);
        Utility.ifOrnot(this, lwy1, lwy1show);
        Utility.ifOrnot(this, lwy2, lwy2show);
        Utility.ifOrnot(this, lwy3, lwy3show);
        Utility.ifOrnot(this, lwy4, lwy4show);
        Utility.ifOrnot(this, cmz1, cmz1show);
        Utility.ifOrnot(this, cmz2, cmz2show);
        Utility.ifOrnot(this, cmy1, cmy1show);
        Utility.ifOrnot(this, cmy2, cmy2show);
        Utility.ifOrnot(this, ccz1, ccz1show);
        Utility.ifOrnot(this, ccz2, ccz2show);
        Utility.ifOrnot(this, ccy1, ccy1show);
        Utility.ifOrnot(this, ccy2, ccy2show);
        Utility.ifOrnot(this, yzbz, yzbzshow);
        Utility.ifOrnot(this, yzby, yzbyshow);
        Utility.ifOrnot(this, cdz1, cdz1show);
        Utility.ifOrnot(this, cdz2, cdz2show);
        Utility.ifOrnot(this, cdz3, cdz3show);
        Utility.ifOrnot(this, cdz4, cdz4show);
        Utility.ifOrnot(this, cdy1, cdy1show);
        Utility.ifOrnot(this, cdy2, cdy2show);
        Utility.ifOrnot(this, cdy3, cdy3show);
        Utility.ifOrnot(this, cdy4, cdy4show);
        Utility.ifOrnot(this, hsjz, hsjzshow);
        Utility.ifOrnot(this, hsjy, hsjyshow);
        Utility.ifOrnot(this, bxgqb, bxgqbshow);
        Utility.ifOrnot(this, bxghb, bxghbshow);
        Utility.ifOrnot(this, fdblqb, fdblqbshow);
        Utility.ifOrnot(this, fdblhb, fdblhbshow);
        Utility.ifOrnot(this, ygq, ygqshow);
        Utility.ifOrnot(this, jssdg, pzsxshow);
        Utility.ifOrnot(this, cxqbzc, jssdgshow);
        Utility.ifOrnot(this, cxzbbzc, jsshwbshow);
        Utility.ifOrnot(this, cxybbzc, cxqbzcshow);
        Utility.ifOrnot(this, dp, cxhbzcshow);
        Utility.ifOrnot(this, pqg, cxzbbzcshow);
        Utility.ifOrnot(this, pzsx, cxybbzcshow);
        Utility.ifOrnot(this, jsshwb, cxdbzcshow);
        Utility.ifOrnot(this, cxhbzc, cxdbshow);
        Utility.ifOrnot(this, cxdbzc, dpshow);
        Utility.ifOrnot(this, cxdb, btshow);
        Utility.ifOrnot(this, bt, pqgshow);
        Utility.ifOrnot(this, chzhq, chzhqshow);
        Utility.ifOrnot(this, wz, wzshow);
        Utility.ifOrnot(this, dy, dyshow);
        Utility.ifOrnot(this, xdcsscd, xdcsscdshow);
        Utility.ifOrnot(this, jykwz, jykwzshow);
        Utility.ifOrnot(this, cz, czshow);
        Utility.ifOrnot(this, yl, ylshow);
        Utility.ifOrnot(this, yxsscd, yxsscdshow);
        Utility.ifOrnot(this, fdongj, fdongjshow);
        Utility.ifOrnot(this, fdianj, fdianjshow);
        Utility.ifOrnot(this, qdj, qdjshow);
        Utility.ifOrnot(this, cyb, cybshow);
        Utility.ifOrnot(this, dhxq, dhxqshow);
        Utility.ifOrnot(this, jylqq, jylqqshow);
        Utility.ifOrnot(this, kqlqq, kqlqqshow);
        Utility.ifOrnot(this, zkzlq, zkzlqshow);
        Utility.ifOrnot(this, bxh, bxhshow);
        Utility.ifOrnot(this, bsqlhq, bsqlhqshow);
        Utility.ifOrnot(this, srq, srqshow);
        Utility.ifOrnot(this, lnq, lnqshow);
        Utility.ifOrnot(this, jqqg, jqqgshow);
        Utility.ifOrnot(this, pqqg, pqqgshow);
        Utility.ifOrnot(this, wlzyq, wlzyqshow);
        Utility.ifOrnot(this, lqyg, lqygshow);
        Utility.ifOrnot(this, qxyg, qxygshow);
        Utility.ifOrnot(this, zdyg, zdygshow);
        Utility.ifOrnot(this, zlzxyg, zlzxygshow);
        Utility.ifOrnot(this, ktysj, ktysjshow);
        Utility.ifOrnot(this, ABSkzq, ABSkzqshow);
        Utility.ifOrnot(this, zqdA, zqdAshow);
        Utility.ifOrnot(this, yqdA, yqdAshow);
        Utility.ifOrnot(this, lqfs, lqfsshow);
        Utility.ifOrnot(this, ybb, ybbshow);
        Utility.ifOrnot(this, zxp, zxpshow);
        Utility.ifOrnot(this, gfj, gfjshow);
        Utility.ifOrnot(this, yspbfq, yspbfqshow);
        Utility.ifOrnot(this, dyq, dyqshow);
        Utility.ifOrnot(this, zqdB, zqdBshow);
        Utility.ifOrnot(this, zqm, zqmshow);
        Utility.ifOrnot(this, zhm, zhmshow);
        Utility.ifOrnot(this, jxh, jxhshow);
        Utility.ifOrnot(this, stx, stxshow);
        Utility.ifOrnot(this, jswzy, jswzyshow);
        Utility.ifOrnot(this, fjszy, fjszyshow);
        Utility.ifOrnot(this, hpzy, hpzyshow);
        Utility.ifOrnot(this, yqdB, yqdBshow);
        Utility.ifOrnot(this, yqm, yqmshow);
        Utility.ifOrnot(this, yhm, yhmshow);
        Utility.ifOrnot(this, qbzc, qbzcshow);
        Utility.ifOrnot(this, zbbzc, zbbzcshow);
        Utility.ifOrnot(this, dbzc, dbzcshow);
        Utility.ifOrnot(this, zhcd, zhcdshow);
        Utility.ifOrnot(this, hbzc, hbzcshow);
        Utility.ifOrnot(this, ybbzc, ybbzcshow);
        Utility.ifOrnot(this, db, dbshow);
        Utility.ifOrnot(this, yhcd, yhcdshow);
        Utility.ifOrnot(this, sscd, sscdshow);

    }

    public void click(View view) {
        switch (view.getId()) {
            case R.id.b2_btn_next:
                SQLiteDatabase ddbb = helper.getWritableDatabase();

                String s1 = Utility.connect(myqs      , myqsshow);
                String s3 = Utility.connect(ltz1      , ltz1show);
                String s4 = Utility.connect(ltz2      , ltz2show);
                String s5 = Utility.connect(ltz3      , ltz3show);
                String s6 = Utility.connect(ltz4      , ltz4show);
                String s7 = Utility.connect(lty1      , lty1show);
                String s8 = Utility.connect(lty2      , lty2show);
                String s9 = Utility.connect(lty3      , lty3show);
                String s10 = Utility.connect(lty4     , lty4show);
                String s11 = Utility.connect(lwz1     , lwz1show);
                String s12 = Utility.connect(lwz2     , lwz2show);
                String s13 = Utility.connect(lwz3     , lwz3show);
                String s14 = Utility.connect(lwz4     , lwz4show);
                String s15 = Utility.connect(lwy1     , lwy1show);
                String s16 = Utility.connect(lwy2     , lwy2show);
                String s17 = Utility.connect(lwy3     , lwy3show);
                String s18 = Utility.connect(lwy4     , lwy4show);
                String s19 = Utility.connect(cmz1     , cmz1show);
                String s20 = Utility.connect(cmz2     , cmz2show);
                String s21 = Utility.connect(cmy1     , cmy1show);
                String s22 = Utility.connect(cmy2     , cmy2show);
                String s23 = Utility.connect(ccz1     , ccz1show);
                String s24 = Utility.connect(ccz2     , ccz2show);
                String s25 = Utility.connect(ccy1     , ccy1show);
                String s26 = Utility.connect(ccy2     , ccy2show);
                String s27 = Utility.connect(yzbz     , yzbzshow);
                String s28 = Utility.connect(yzby     , yzbyshow);
                String s29 = Utility.connect(cdz1     , cdz1show);
                String s30 = Utility.connect(cdz2     , cdz2show);
                String s31 = Utility.connect(cdz3     , cdz3show);
                String s32 = Utility.connect(cdz4     , cdz4show);
                String s33 = Utility.connect(cdy1     , cdy1show);
                String s34 = Utility.connect(cdy2     , cdy2show);
                String s35 = Utility.connect(cdy3     , cdy3show);
                String s36 = Utility.connect(cdy4     , cdy4show);
                String s37 = Utility.connect(hsjz     , hsjzshow);
                String s38 = Utility.connect(hsjy     , hsjyshow);
                String s39 = Utility.connect(bxgqb    , bxgqbshow);
                String s40 = Utility.connect(bxghb    , bxghbshow);
                String s41 = Utility.connect(fdblqb   , fdblqbshow);
                String s42 = Utility.connect(fdblhb   , fdblhbshow);
                String s43 = Utility.connect(ygq      , ygqshow);
                String s44 = Utility.connect(pzsx     , pzsxshow);
                String s45 = Utility.connect(jssdg    , jssdgshow);
                String s46 = Utility.connect(jsshwb   , jsshwbshow);
                String s47 = Utility.connect(cxqbzc   , cxqbzcshow);
                String s48 = Utility.connect(cxhbzc   , cxhbzcshow);
                String s49 = Utility.connect(cxzbbzc  , cxzbbzcshow);
                String s50 = Utility.connect(cxdbzc   , cxdbzcshow);
                String s51 = Utility.connect(cxybbzc  , cxybbzcshow);
                String s52 = Utility.connect(cxdb     , cxdbshow);
                String s53 = Utility.connect(dp       , dpshow);
                String s54 = Utility.connect(bt       , btshow);
                String s55 = Utility.connect(pqg      , pqgshow);
                String s56 = Utility.connect(chzhq    , chzhqshow);
                String s57 = Utility.connect(wz       , wzshow);
                String s58 = Utility.connect(dy       , dyshow);
                String s59 = Utility.connect(xdcsscd  , xdcsscdshow);
                String s60 = Utility.connect(jykwz    , jykwzshow);
                String s61 = Utility.connect(cz       , czshow);
                String s62 = Utility.connect(yl       , ylshow);
                String s63 = Utility.connect(yxsscd   , yxsscdshow);
                String s64 = Utility.connect(fdongj   , fdongjshow);
                String s65 = Utility.connect(fdianj   , fdianjshow);
                String s66 = Utility.connect(qdj      , qdjshow);
                String s67 = Utility.connect(cyb      , cybshow);
                String s68 = Utility.connect(dhxq     , dhxqshow);
                String s69 = Utility.connect(jylqq    , jylqqshow);
                String s70 = Utility.connect(kqlqq    , kqlqqshow);
                String s71 = Utility.connect(zkzlq    , zkzlqshow);
                String s72 = Utility.connect(bxh      , bxhshow);
                String s73 = Utility.connect(bsqlhq   , bsqlhqshow);
                String s74 = Utility.connect(srq      , srqshow);
                String s75 = Utility.connect(lnq      , lnqshow);
                String s76 = Utility.connect(jqqg     , jqqgshow);
                String s77 = Utility.connect(pqqg     , pqqgshow);
                String s78 = Utility.connect(wlzyq    , wlzyqshow);
                String s79 = Utility.connect(lqyg     , lqygshow);
                String s80 = Utility.connect(qxyg     , qxygshow);
                String s81 = Utility.connect(zdyg     , zdygshow);
                String s82 = Utility.connect(zlzxyg   , zlzxygshow);
                String s83 = Utility.connect(ktysj    , ktysjshow);
                String s84 = Utility.connect(ABSkzq   , ABSkzqshow);
                String s85 = Utility.connect(zqdA     , zqdAshow);
                String s86 = Utility.connect(yqdA     , yqdAshow);
                String s87 = Utility.connect(lqfs     , lqfsshow);
                String s88 = Utility.connect(ybb      , ybbshow);
                String s89 = Utility.connect(zxp      , zxpshow);
                String s90 = Utility.connect(gfj      , gfjshow);
                String s91 = Utility.connect(yspbfq   , yspbfqshow);
                String s92 = Utility.connect(dyq      , dyqshow);
                String s93 = Utility.connect(zqdB     , zqdBshow);
                String s94 = Utility.connect(zqm      , zqmshow);
                String s95 = Utility.connect(zhm      , zhmshow);
                String s96 = Utility.connect(jxh      , jxhshow);
                String s97 = Utility.connect(stx      , stxshow);
                String s98 = Utility.connect(jswzy    , jswzyshow);
                String s99 = Utility.connect(fjszy    , fjszyshow);
                String s100 = Utility.connect(hpzy    , hpzyshow);
                String s101 = Utility.connect(yqdB    , yqdBshow);
                String s102 = Utility.connect(yqm     , yqmshow);
                String s103 = Utility.connect(yhm     , yhmshow);
                String s104 = Utility.connect(qbzc    , qbzcshow);
                String s105 = Utility.connect(zbbzc   , zbbzcshow);
                String s106 = Utility.connect(dbzc    , dbzcshow);
                String s107 = Utility.connect(zhcd    , zhcdshow);
                String s109 = Utility.connect(hbzc    , hbzcshow);
                String s110 = Utility.connect(ybbzc   , ybbzcshow);
                String s111 = Utility.connect(db      , dbshow);
                String s112 = Utility.connect(yhcd    , yhcdshow);
                String s113 = Utility.connect(sscd    , sscdshow);
                String s2 = qhbw.getText().toString();
                String s108 = zywp.getText().toString();

                String[] args2 = {acc_ID_time,clsbdm,s3, s4, s5, s6, s7, s8, s9, s10, s11, s12, s13, s14, s15, s16, s17, s18, s19,
                        s20, s21, s22, s23, s24, s25, s26, s27, s28, s29, s30, s31, s32, s33, s34, s35, s36, s37, s38,
                        s39, s40, s41, s42, s43, s44, s45, s46, s47, s48, s49, s50, s51, s52, s53, s54, s55, s56};
                String[] args4={ acc_ID_time,clsbdm,s57,
                        s58, s59, s60, s61, s62, s63, s64, s65, s66, s67, s68, s69, s70, s71, s72, s73, s74, s75, s76,
                        s77, s78, s79, s80, s81, s82, s83, s84, s85, s86, s87, s88, s89, s90, s91, s92, s93, s94, s95,
                        s96, s97, s98, s99, s100, s101, s102, s103, s104, s105, s106, s107, s108, s109, s110, s111,
                        s112, s113};
                String[] args20={acc_ID_time,clsbdm,s1,s2};
                Utility.insert(ddbb,"baseinfo_bqh",args10,args20);

                Utility.insert(ddbb, "baseinfo_b2W", args1, args2);
                Utility.insert(ddbb, "baseinfo_b2N", args3, args4);
                Intent intent = new Intent(ActivityB2.this, ActivityBB.class);
                intent.putExtra("acc_ID_time",acc_ID_time);
                intent.putExtra("wjm",wjm);
                intent.putExtra("clsbdm",clsbdm);
                startActivity(intent);
                break;
            case R.id.b2_btn_photo:
                Intent intent_camera = new Intent(ActivityB2.this, CameraActivity.class);
                intent_camera.putExtra("wjm",wjm);
                startActivity(intent_camera);
                break;
        }
    }
}