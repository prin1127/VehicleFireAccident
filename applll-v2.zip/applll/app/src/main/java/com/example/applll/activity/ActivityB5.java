package com.example.applll.activity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.applll.R;
import com.example.applll.Utility;
import com.example.applll.service.DbManger;
import com.example.applll.service.MySQLiteHelper;

public class ActivityB5 extends AppCompatActivity {

    private MySQLiteHelper helper= DbManger.getIntance(this);

    private String[] args1 = {"acc_ID","CLSBDM","LTZ1","LTZ2","LTZ3","LTY1","LTY2","LTY3","LWZ1","LWZ2",
            "LWZ3","LWY1","LWY2","LWY3","CMZ1","CMY1","CMY2","CMY3","CWBZ1","CWBZ2","CWBZ3","CWBY1",
            "CWBY2","CWBY3","CDZ1","CDZ2","CDY1","CDY2","HSJZ","HSJY","CCZ1","CCZ2","CCZ3","CCZ4",
            "CCZ5","CCZ6","CCY1","CCY2","CCY3","CCY4","CCY5","CCY6","BXGQB","BXGHB","FDBLQB","FDBLHB",
            "YGQQB","YGQHB","DG","DBKT","DP","PQG","CHZHQ"};
    private String[] args3 = {"acc_ID","CLSBDM","WZA","DY","DYXDCSSCD","DLDCCWZ","CDKWZ",
            "CDQWZ","WKCZ","EDDY","EDRL","CZFS","HDZT","DLDCCSSCD","DCDTLX","DCDTXH","DCDTEDRL","DCDTEDDY",
            "WZB","DCGLXTSSCD","DDJ","DJKZQ","JSX","DYZHQ","GYPDH","BXH","JQQG","PQQG","BSQLHQ","ZKZLQZKB",
            "SRQ","LQFS","ABSKZQ","ZQD","YQD","FDONGJ","QDJ","FDIANJ","YBB","JXH","ZXP","DHKG","GFJ",
            "YSPBFQ","JTQ","JSWZY","FJSZY","CKZY","QBDB","HBDB","ZQCD","ZHCD","YQCD","YHCD","Z1CM",
            "Y1CM","Y2CM","Y3CM","ZYWP","SSCD"};
    private String[] args10={"acc_ID","CLSBDM","MYQS","QHBW"};

    private Spinner myqs,ltz1,ltz2,ltz3,lty1,lty2,lty3,lwz1,lwz2,lwz3,lwy1,lwy2,lwy3,cmz1,cmy1,cmy2,
            cmy3,cwbz1,cwbz2,cwbz3,cwby1,cwby2,cwby3,cdz1,cdz2,cdy1,cdy2,hsjz,hsjy,ccz1,ccz2,ccz3,ccz4,
            ccz5,ccz6,ccy1,ccy2,ccy3,ccy4,ccy5,ccy6,bxgqb,bxghb,fdblqb,fdblhb,ygqqb,ygqhb,dg,dbkt,dp,
            pqg,chzhq,wzA,dy,dyxdcsscd,dldccwz,cdkwz,cdqwz,wkcz,czfs,dldccsscd,wzB,dcglxtsscd,ddj,djkzq,
            jsx,dyzhq,gypdh,bxh,jqqg,pqqg,bsqlhq,zkzlqzkb,srq,lqfs,ABSkzq,zqd,yqd,fdongj,qdj,fdianj,ybb,
            jxh,zxp,dhkg,gfj,yspbfq,jtq,jswzy,fjszy,ckzy,qbdb,hbdb,zqcd,zhcd,yqcd,yhcd,z1cm,y1cm,y2cm,
            y3cm,sscd;
    
    private TextView myqsshow,ltz1show,ltz2show,ltz3show,lty1show,lty2show,lty3show,lwz1show,lwz2show,
            lwz3show,lwy1show,lwy2show,lwy3show,cmz1show,cmy1show,cmy2show,cmy3show,cwbz1show,cwbz2show,
            cwbz3show,cwby1show,cwby2show,cwby3show,cdz1show,cdz2show,cdy1show,cdy2show,hsjzshow,hsjyshow,
            ccz1show,ccz2show,ccz3show,ccz4show,ccz5show,ccz6show,ccy1show,ccy2show,ccy3show,ccy4show,
            ccy5show,ccy6show,bxgqbshow,bxghbshow,fdblqbshow,fdblhbshow,ygqqbshow,ygqhbshow,dgshow,dbktshow,
            dpshow,pqgshow,chzhqshow,wzAshow,dyshow,dyxdcsscdshow,dldccwzshow,cdkwzshow,cdqwzshow,wkczshow,
            czfsshow,dldccsscdshow,wzBshow,dcglxtsscdshow,ddjshow,djkzqshow,jsxshow,dyzhqshow,gypdhshow,
            bxhshow,jqqgshow,pqqgshow,bsqlhqshow,zkzlqzkbshow,srqshow,lqfsshow,ABSkzqshow,zqdshow,yqdshow,
            fdongjshow,qdjshow,fdianjshow,ybbshow,jxhshow,zxpshow,dhkgshow,gfjshow,yspbfqshow,jtqshow,
            jswzyshow,fjszyshow,ckzyshow,qbdbshow,hbdbshow,zqcdshow,zhcdshow,yqcdshow,yhcdshow,z1cmshow,
            y1cmshow,y2cmshow,y3cmshow,sscdshow;

    private EditText qhbw,eddy,edrl,hdzt,dcdtlx,dcdtxh,dcdtedrl,dcdteddy,zywp;
    String acc_ID_time,clsbdm,wjm;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_b5);
        Intent intent0=getIntent();
        acc_ID_time=intent0.getStringExtra("acc_ID_time");
        clsbdm=intent0.getStringExtra("CLSBDM");
        wjm=intent0.getStringExtra("wjm");

        myqs       =findViewById(R.id.b5_sp_myqs      );
        ltz1       =findViewById(R.id.b5_sp_ltz1      );
        ltz2       =findViewById(R.id.b5_sp_ltz2      );
        ltz3       =findViewById(R.id.b5_sp_ltz3      );
        lty1       =findViewById(R.id.b5_sp_lty1      );
        lty2       =findViewById(R.id.b5_sp_lty2      );
        lty3       =findViewById(R.id.b5_sp_lty3      );
        lwz1       =findViewById(R.id.b5_sp_lwz1      );
        lwz2       =findViewById(R.id.b5_sp_lwz2      );
        lwz3       =findViewById(R.id.b5_sp_lwz3      );
        lwy1       =findViewById(R.id.b5_sp_lwy1      );
        lwy2       =findViewById(R.id.b5_sp_lwy2      );
        lwy3       =findViewById(R.id.b5_sp_lwy3      );
        cmz1       =findViewById(R.id.b5_sp_cmz1      );
        cmy1       =findViewById(R.id.b5_sp_cmy1      );
        cmy2       =findViewById(R.id.b5_sp_cmy2      );
        cmy3       =findViewById(R.id.b5_sp_cmy3      );
        cwbz1      =findViewById(R.id.b5_sp_cwbz1     );
        cwbz2      =findViewById(R.id.b5_sp_cwbz2     );
        cwbz3      =findViewById(R.id.b5_sp_cwbz3     );
        cwby1      =findViewById(R.id.b5_sp_cwby1     );
        cwby2      =findViewById(R.id.b5_sp_cwby2     );
        cwby3      =findViewById(R.id.b5_sp_cwby3     );
        cdz1       =findViewById(R.id.b5_sp_cdz1      );
        cdz2       =findViewById(R.id.b5_sp_cdz2      );
        cdy1       =findViewById(R.id.b5_sp_cdy1      );
        cdy2       =findViewById(R.id.b5_sp_cdy2      );
        hsjz       =findViewById(R.id.b5_sp_hsjz      );
        hsjy       =findViewById(R.id.b5_sp_hsjy      );
        ccz1       =findViewById(R.id.b5_sp_ccz1      );
        ccz2       =findViewById(R.id.b5_sp_ccz2      );
        ccz3       =findViewById(R.id.b5_sp_ccz3      );
        ccz4       =findViewById(R.id.b5_sp_ccz4      );
        ccz5       =findViewById(R.id.b5_sp_ccz5      );
        ccz6       =findViewById(R.id.b5_sp_ccz6      );
        ccy1       =findViewById(R.id.b5_sp_ccy1      );
        ccy2       =findViewById(R.id.b5_sp_ccy2      );
        ccy3       =findViewById(R.id.b5_sp_ccy3      );
        ccy4       =findViewById(R.id.b5_sp_ccy4      );
        ccy5       =findViewById(R.id.b5_sp_ccy5      );
        ccy6       =findViewById(R.id.b5_sp_ccy6      );
        bxgqb      =findViewById(R.id.b5_sp_bxgqb     );
        bxghb      =findViewById(R.id.b5_sp_bxghb     );
        fdblqb     =findViewById(R.id.b5_sp_fdblqb    );
        fdblhb     =findViewById(R.id.b5_sp_fdblhb    );
        ygqqb      =findViewById(R.id.b5_sp_ygqqb     );
        ygqhb      =findViewById(R.id.b5_sp_ygqhb     );
        dg         =findViewById(R.id.b5_sp_dg        );
        dbkt       =findViewById(R.id.b5_sp_dbkt      );
        dp         =findViewById(R.id.b5_sp_dp        );
        pqg        =findViewById(R.id.b5_sp_pqg       );
        chzhq      =findViewById(R.id.b5_sp_chzhq     );
        wzA        =findViewById(R.id.b5_sp_wzA       );
        dy         =findViewById(R.id.b5_sp_dy        );
        dyxdcsscd  =findViewById(R.id.b5_sp_dyxdcsscd );
        dldccwz    =findViewById(R.id.b5_sp_dldccwz   );
        cdkwz      =findViewById(R.id.b5_sp_cdkwz     );
        cdqwz      =findViewById(R.id.b5_sp_cdqwz     );
        wkcz       =findViewById(R.id.b5_sp_wkcz      );
        czfs       =findViewById(R.id.b5_sp_czfs      );
        dldccsscd  =findViewById(R.id.b5_sp_dldccsscd );
        wzB        =findViewById(R.id.b5_sp_wzB       );
        dcglxtsscd =findViewById(R.id.b5_sp_dcglxtsscd);
        ddj        =findViewById(R.id.b5_sp_ddj       );
        djkzq      =findViewById(R.id.b5_sp_djkzq     );
        jsx        =findViewById(R.id.b5_sp_jsx       );
        dyzhq      =findViewById(R.id.b5_sp_dyzhq     );
        gypdh      =findViewById(R.id.b5_sp_gypdh     );
        bxh        =findViewById(R.id.b5_sp_bxh       );
        jqqg       =findViewById(R.id.b5_sp_jqqg      );
        pqqg       =findViewById(R.id.b5_sp_pqqg      );
        bsqlhq     =findViewById(R.id.b5_sp_bsqlhq    );
        zkzlqzkb   =findViewById(R.id.b5_sp_zkzlqzkb  );
        srq        =findViewById(R.id.b5_sp_srq       );
        lqfs       =findViewById(R.id.b5_sp_lqfs      );
        ABSkzq     =findViewById(R.id.b5_sp_ABSkzq    );
        zqd        =findViewById(R.id.b5_sp_zqd       );
        yqd        =findViewById(R.id.b5_sp_yqd       );
        fdongj     =findViewById(R.id.b5_sp_fdongj    );
        qdj        =findViewById(R.id.b5_sp_qdj       );
        fdianj     =findViewById(R.id.b5_sp_fdianj    );
        ybb        =findViewById(R.id.b5_sp_ybb       );
        jxh        =findViewById(R.id.b5_sp_jxh       );
        zxp        =findViewById(R.id.b5_sp_zxp       );
        dhkg       =findViewById(R.id.b5_sp_dhkg      );
        gfj        =findViewById(R.id.b5_sp_gfj       );
        yspbfq     =findViewById(R.id.b5_sp_yspbfq    );
        jtq        =findViewById(R.id.b5_sp_jtq       );
        jswzy      =findViewById(R.id.b5_sp_jswzy     );
        fjszy      =findViewById(R.id.b5_sp_fjszy     );
        ckzy       =findViewById(R.id.b5_sp_ckzy      );
        qbdb       =findViewById(R.id.b5_sp_qbdb      );
        hbdb       =findViewById(R.id.b5_sp_hbdb      );
        zqcd       =findViewById(R.id.b5_sp_zqcd      );
        zhcd       =findViewById(R.id.b5_sp_zhcd      );
        yqcd       =findViewById(R.id.b5_sp_yqcd      );
        yhcd       =findViewById(R.id.b5_sp_yhcd      );
        z1cm       =findViewById(R.id.b5_sp_z1cm      );
        y1cm       =findViewById(R.id.b5_sp_y1cm      );
        y2cm       =findViewById(R.id.b5_sp_y2cm      );
        y3cm       =findViewById(R.id.b5_sp_y3cm      );
        sscd       =findViewById(R.id.b5_sp_sscd      );
        
        myqsshow       =findViewById(R.id.b5_tv_show_myqs      );
        ltz1show       =findViewById(R.id.b5_tv_show_ltz1      );
        ltz2show       =findViewById(R.id.b5_tv_show_ltz2      );
        ltz3show       =findViewById(R.id.b5_tv_show_ltz3      );
        lty1show       =findViewById(R.id.b5_tv_show_lty1      );
        lty2show       =findViewById(R.id.b5_tv_show_lty2      );
        lty3show       =findViewById(R.id.b5_tv_show_lty3      );
        lwz1show       =findViewById(R.id.b5_tv_show_lwz1      );
        lwz2show       =findViewById(R.id.b5_tv_show_lwz2      );
        lwz3show       =findViewById(R.id.b5_tv_show_lwz3      );
        lwy1show       =findViewById(R.id.b5_tv_show_lwy1      );
        lwy2show       =findViewById(R.id.b5_tv_show_lwy2      );
        lwy3show       =findViewById(R.id.b5_tv_show_lwy3      );
        cmz1show       =findViewById(R.id.b5_tv_show_cmz1      );
        cmy1show       =findViewById(R.id.b5_tv_show_cmy1      );
        cmy2show       =findViewById(R.id.b5_tv_show_cmy2      );
        cmy3show       =findViewById(R.id.b5_tv_show_cmy3      );
        cwbz1show      =findViewById(R.id.b5_tv_show_cwbz1     );
        cwbz2show      =findViewById(R.id.b5_tv_show_cwbz2     );
        cwbz3show      =findViewById(R.id.b5_tv_show_cwbz3     );
        cwby1show      =findViewById(R.id.b5_tv_show_cwby1     );
        cwby2show      =findViewById(R.id.b5_tv_show_cwby2     );
        cwby3show      =findViewById(R.id.b5_tv_show_cwby3     );
        cdz1show       =findViewById(R.id.b5_tv_show_cdz1      );
        cdz2show       =findViewById(R.id.b5_tv_show_cdz2      );
        cdy1show       =findViewById(R.id.b5_tv_show_cdy1      );
        cdy2show       =findViewById(R.id.b5_tv_show_cdy2      );
        hsjzshow       =findViewById(R.id.b5_tv_show_hsjz      );
        hsjyshow       =findViewById(R.id.b5_tv_show_hsjy      );
        ccz1show       =findViewById(R.id.b5_tv_show_ccz1      );
        ccz2show       =findViewById(R.id.b5_tv_show_ccz2      );
        ccz3show       =findViewById(R.id.b5_tv_show_ccz3      );
        ccz4show       =findViewById(R.id.b5_tv_show_ccz4      );
        ccz5show       =findViewById(R.id.b5_tv_show_ccz5      );
        ccz6show       =findViewById(R.id.b5_tv_show_ccz6      );
        ccy1show       =findViewById(R.id.b5_tv_show_ccy1      );
        ccy2show       =findViewById(R.id.b5_tv_show_ccy2      );
        ccy3show       =findViewById(R.id.b5_tv_show_ccy3      );
        ccy4show       =findViewById(R.id.b5_tv_show_ccy4      );
        ccy5show       =findViewById(R.id.b5_tv_show_ccy5      );
        ccy6show       =findViewById(R.id.b5_tv_show_ccy6      );
        bxgqbshow      =findViewById(R.id.b5_tv_show_bxgqb     );
        bxghbshow      =findViewById(R.id.b5_tv_show_bxghb     );
        fdblqbshow     =findViewById(R.id.b5_tv_show_fdblqb    );
        fdblhbshow     =findViewById(R.id.b5_tv_show_fdblhb    );
        ygqqbshow      =findViewById(R.id.b5_tv_show_ygqqb     );
        ygqhbshow      =findViewById(R.id.b5_tv_show_ygqhb     );
        dgshow         =findViewById(R.id.b5_tv_show_dg        );
        dbktshow       =findViewById(R.id.b5_tv_show_dbkt      );
        dpshow         =findViewById(R.id.b5_tv_show_dp        );
        pqgshow        =findViewById(R.id.b5_tv_show_pqg       );
        chzhqshow      =findViewById(R.id.b5_tv_show_chzhq     );
        wzAshow        =findViewById(R.id.b5_tv_show_wzA       );
        dyshow         =findViewById(R.id.b5_tv_show_dy        );
        dyxdcsscdshow  =findViewById(R.id.b5_tv_show_dyxdcsscd );
        dldccwzshow    =findViewById(R.id.b5_tv_show_dldccwz   );
        cdkwzshow      =findViewById(R.id.b5_tv_show_cdkwz     );
        cdqwzshow      =findViewById(R.id.b5_tv_show_cdqwz     );
        wkczshow       =findViewById(R.id.b5_tv_show_wkcz      );
        czfsshow       =findViewById(R.id.b5_tv_show_czfs      );
        dldccsscdshow  =findViewById(R.id.b5_tv_show_dldccsscd );
        wzBshow        =findViewById(R.id.b5_tv_show_wzB       );
        dcglxtsscdshow =findViewById(R.id.b5_tv_show_dcglxtsscd);
        ddjshow        =findViewById(R.id.b5_tv_show_ddj       );
        djkzqshow      =findViewById(R.id.b5_tv_show_djkzq     );
        jsxshow        =findViewById(R.id.b5_tv_show_jsx       );
        dyzhqshow      =findViewById(R.id.b5_tv_show_dyzhq     );
        gypdhshow      =findViewById(R.id.b5_tv_show_gypdh     );
        bxhshow        =findViewById(R.id.b5_tv_show_bxh       );
        jqqgshow       =findViewById(R.id.b5_tv_show_jqqg      );
        pqqgshow       =findViewById(R.id.b5_tv_show_pqqg      );
        bsqlhqshow     =findViewById(R.id.b5_tv_show_bsqlhq    );
        zkzlqzkbshow   =findViewById(R.id.b5_tv_show_zkzlqzkb  );
        srqshow        =findViewById(R.id.b5_tv_show_srq       );
        lqfsshow       =findViewById(R.id.b5_tv_show_lqfs      );
        ABSkzqshow     =findViewById(R.id.b5_tv_show_ABSkzq    );
        zqdshow        =findViewById(R.id.b5_tv_show_zqd       );
        yqdshow        =findViewById(R.id.b5_tv_show_yqd       );
        fdongjshow     =findViewById(R.id.b5_tv_show_fdongj    );
        qdjshow        =findViewById(R.id.b5_tv_show_qdj       );
        fdianjshow     =findViewById(R.id.b5_tv_show_fdianj    );
        ybbshow        =findViewById(R.id.b5_tv_show_ybb       );
        jxhshow        =findViewById(R.id.b5_tv_show_jxh       );
        zxpshow        =findViewById(R.id.b5_tv_show_zxp       );
        dhkgshow       =findViewById(R.id.b5_tv_show_dhkg      );
        gfjshow        =findViewById(R.id.b5_tv_show_gfj       );
        yspbfqshow     =findViewById(R.id.b5_tv_show_yspbfq    );
        jtqshow        =findViewById(R.id.b5_tv_show_jtq       );
        jswzyshow      =findViewById(R.id.b5_tv_show_jswzy     );
        fjszyshow      =findViewById(R.id.b5_tv_show_fjszy     );
        ckzyshow       =findViewById(R.id.b5_tv_show_ckzy      );
        qbdbshow       =findViewById(R.id.b5_tv_show_qbdb      );
        hbdbshow       =findViewById(R.id.b5_tv_show_hbdb      );
        zqcdshow       =findViewById(R.id.b5_tv_show_zqcd      );
        zhcdshow       =findViewById(R.id.b5_tv_show_zhcd      );
        yqcdshow       =findViewById(R.id.b5_tv_show_yqcd      );
        yhcdshow       =findViewById(R.id.b5_tv_show_yhcd      );
        z1cmshow       =findViewById(R.id.b5_tv_show_z1cm      );
        y1cmshow       =findViewById(R.id.b5_tv_show_y1cm      );
        y2cmshow       =findViewById(R.id.b5_tv_show_y2cm      );
        y3cmshow       =findViewById(R.id.b5_tv_show_y3cm      );
        sscdshow       =findViewById(R.id.b5_tv_show_sscd      );

        qhbw = findViewById(R.id.b5_et_qhbw);
        eddy = findViewById(R.id.b5_et_eddy);
        edrl = findViewById(R.id.b5_et_edrl);
        hdzt = findViewById(R.id.b5_et_hdzt);
        dcdtlx = findViewById(R.id.b5_et_dcdtlx);
        dcdtxh = findViewById(R.id.b5_et_dcdtxh);
        dcdtedrl = findViewById(R.id.b5_et_dcdtedrl);
        dcdteddy = findViewById(R.id.b5_et_dcdteddy);
        zywp = findViewById(R.id.b5_et_zywp);
        
        Utility.ifOrnot(this,myqs      ,myqsshow      );
        Utility.ifOrnot(this,ltz1      ,ltz1show      );
        Utility.ifOrnot(this,ltz2      ,ltz2show      );
        Utility.ifOrnot(this,ltz3      ,ltz3show      );
        Utility.ifOrnot(this,lty1      ,lty1show      );
        Utility.ifOrnot(this,lty2      ,lty2show      );
        Utility.ifOrnot(this,lty3      ,lty3show      );
        Utility.ifOrnot(this,lwz1      ,lwz1show      );
        Utility.ifOrnot(this,lwz2      ,lwz2show      );
        Utility.ifOrnot(this,lwz3      ,lwz3show      );
        Utility.ifOrnot(this,lwy1      ,lwy1show      );
        Utility.ifOrnot(this,lwy2      ,lwy2show      );
        Utility.ifOrnot(this,lwy3      ,lwy3show      );
        Utility.ifOrnot(this,cmz1      ,cmz1show      );
        Utility.ifOrnot(this,cmy1      ,cmy1show      );
        Utility.ifOrnot(this,cmy2      ,cmy2show      );
        Utility.ifOrnot(this,cmy3      ,cmy3show      );
        Utility.ifOrnot(this,cwbz1     ,cwbz1show     );
        Utility.ifOrnot(this,cwbz2     ,cwbz2show     );
        Utility.ifOrnot(this,cwbz3     ,cwbz3show     );
        Utility.ifOrnot(this,cwby1     ,cwby1show     );
        Utility.ifOrnot(this,cwby2     ,cwby2show     );
        Utility.ifOrnot(this,cwby3     ,cwby3show     );
        Utility.ifOrnot(this,cdz1      ,cdz1show      );
        Utility.ifOrnot(this,cdz2      ,cdz2show      );
        Utility.ifOrnot(this,cdy1      ,cdy1show      );
        Utility.ifOrnot(this,cdy2      ,cdy2show      );
        Utility.ifOrnot(this,hsjz      ,hsjzshow      );
        Utility.ifOrnot(this,hsjy      ,hsjyshow      );
        Utility.ifOrnot(this,ccz1      ,ccz1show      );
        Utility.ifOrnot(this,ccz2      ,ccz2show      );
        Utility.ifOrnot(this,ccz3      ,ccz3show      );
        Utility.ifOrnot(this,ccz4      ,ccz4show      );
        Utility.ifOrnot(this,ccz5      ,ccz5show      );
        Utility.ifOrnot(this,ccz6      ,ccz6show      );
        Utility.ifOrnot(this,ccy1      ,ccy1show      );
        Utility.ifOrnot(this,ccy2      ,ccy2show      );
        Utility.ifOrnot(this,ccy3      ,ccy3show      );
        Utility.ifOrnot(this,ccy4      ,ccy4show      );
        Utility.ifOrnot(this,ccy5      ,ccy5show      );
        Utility.ifOrnot(this,ccy6      ,ccy6show      );
        Utility.ifOrnot(this,bxgqb     ,bxgqbshow     );
        Utility.ifOrnot(this,bxghb     ,bxghbshow     );
        Utility.ifOrnot(this,fdblqb    ,fdblqbshow    );
        Utility.ifOrnot(this,fdblhb    ,fdblhbshow    );
        Utility.ifOrnot(this,ygqqb     ,ygqqbshow     );
        Utility.ifOrnot(this,ygqhb     ,ygqhbshow     );
        Utility.ifOrnot(this,dg        ,dgshow        );
        Utility.ifOrnot(this,dbkt      ,dbktshow      );
        Utility.ifOrnot(this,dp        ,dpshow        );
        Utility.ifOrnot(this,pqg       ,pqgshow       );
        Utility.ifOrnot(this,chzhq     ,chzhqshow     );
        Utility.ifOrnot(this,wzA       ,wzAshow       );
        Utility.ifOrnot(this,dy        ,dyshow        );
        Utility.ifOrnot(this,dyxdcsscd ,dyxdcsscdshow );
        Utility.ifOrnot(this,dldccwz   ,dldccwzshow   );
        Utility.ifOrnot(this,cdkwz     ,cdkwzshow     );
        Utility.ifOrnot(this,cdqwz     ,cdqwzshow     );
        Utility.ifOrnot(this,wkcz      ,wkczshow      );
        Utility.ifOrnot(this,czfs      ,czfsshow      );
        Utility.ifOrnot(this,dldccsscd ,dldccsscdshow );
        Utility.ifOrnot(this,wzB       ,wzBshow       );
        Utility.ifOrnot(this,dcglxtsscd,dcglxtsscdshow);
        Utility.ifOrnot(this,ddj       ,ddjshow       );
        Utility.ifOrnot(this,djkzq     ,djkzqshow     );
        Utility.ifOrnot(this,jsx       ,jsxshow       );
        Utility.ifOrnot(this,dyzhq     ,dyzhqshow     );
        Utility.ifOrnot(this,gypdh     ,gypdhshow     );
        Utility.ifOrnot(this,bxh       ,bxhshow       );
        Utility.ifOrnot(this,jqqg      ,jqqgshow      );
        Utility.ifOrnot(this,pqqg      ,pqqgshow      );
        Utility.ifOrnot(this,bsqlhq    ,bsqlhqshow    );
        Utility.ifOrnot(this,zkzlqzkb  ,zkzlqzkbshow  );
        Utility.ifOrnot(this,srq       ,srqshow       );
        Utility.ifOrnot(this,lqfs      ,lqfsshow      );
        Utility.ifOrnot(this,ABSkzq    ,ABSkzqshow    );
        Utility.ifOrnot(this,zqd       ,zqdshow       );
        Utility.ifOrnot(this,yqd       ,yqdshow       );
        Utility.ifOrnot(this,fdongj    ,fdongjshow    );
        Utility.ifOrnot(this,qdj       ,qdjshow       );
        Utility.ifOrnot(this,fdianj    ,fdianjshow    );
        Utility.ifOrnot(this,ybb       ,ybbshow       );
        Utility.ifOrnot(this,jxh       ,jxhshow       );
        Utility.ifOrnot(this,zxp       ,zxpshow       );
        Utility.ifOrnot(this,dhkg      ,dhkgshow      );
        Utility.ifOrnot(this,gfj       ,gfjshow       );
        Utility.ifOrnot(this,yspbfq    ,yspbfqshow    );
        Utility.ifOrnot(this,jtq       ,jtqshow       );
        Utility.ifOrnot(this,jswzy     ,jswzyshow     );
        Utility.ifOrnot(this,fjszy     ,fjszyshow     );
        Utility.ifOrnot(this,ckzy      ,ckzyshow      );
        Utility.ifOrnot(this,qbdb      ,qbdbshow      );
        Utility.ifOrnot(this,hbdb      ,hbdbshow      );
        Utility.ifOrnot(this,zqcd      ,zqcdshow      );
        Utility.ifOrnot(this,zhcd      ,zhcdshow      );
        Utility.ifOrnot(this,yqcd      ,yqcdshow      );
        Utility.ifOrnot(this,yhcd      ,yhcdshow      );
        Utility.ifOrnot(this,z1cm      ,z1cmshow      );
        Utility.ifOrnot(this,y1cm      ,y1cmshow      );
        Utility.ifOrnot(this,y2cm      ,y2cmshow      );
        Utility.ifOrnot(this,y3cm      ,y3cmshow      );
        Utility.ifOrnot(this,sscd      ,sscdshow      );
        
    }

    public void click(View view) {
        switch (view.getId()){
            case R.id.b5_btn_next:
                SQLiteDatabase db = helper.getWritableDatabase();

                String s1  =Utility.connect(myqs      ,myqsshow      );
                String s3  =Utility.connect(ltz1      ,ltz1show      );
                String s4  =Utility.connect(ltz2      ,ltz2show      );
                String s5  =Utility.connect(ltz3      ,ltz3show      );
                String s6  =Utility.connect(lty1      ,lty1show      );
                String s7  =Utility.connect(lty2      ,lty2show      );
                String s8  =Utility.connect(lty3      ,lty3show      );
                String s9  =Utility.connect(lwz1      ,lwz1show      );
                String s10 =Utility.connect(lwz2      ,lwz2show      );
                String s11 =Utility.connect(lwz3      ,lwz3show      );
                String s12 =Utility.connect(lwy1      ,lwy1show      );
                String s13 =Utility.connect(lwy2      ,lwy2show      );
                String s14 =Utility.connect(lwy3      ,lwy3show      );
                String s15 =Utility.connect(cmz1      ,cmz1show      );
                String s16 =Utility.connect(cmy1      ,cmy1show      );
                String s17 =Utility.connect(cmy2      ,cmy2show      );
                String s18 =Utility.connect(cmy3      ,cmy3show      );
                String s19 =Utility.connect(cwbz1     ,cwbz1show     );
                String s20 =Utility.connect(cwbz2     ,cwbz2show     );
                String s21 =Utility.connect(cwbz3     ,cwbz3show     );
                String s22 =Utility.connect(cwby1     ,cwby1show     );
                String s23 =Utility.connect(cwby2     ,cwby2show     );
                String s24 =Utility.connect(cwby3     ,cwby3show     );
                String s25 =Utility.connect(cdz1      ,cdz1show      );
                String s26 =Utility.connect(cdz2      ,cdz2show      );
                String s27 =Utility.connect(cdy1      ,cdy1show      );
                String s28 =Utility.connect(cdy2      ,cdy2show      );
                String s29 =Utility.connect(hsjz      ,hsjzshow      );
                String s30 =Utility.connect(hsjy      ,hsjyshow      );
                String s31 =Utility.connect(ccz1      ,ccz1show      );
                String s32 =Utility.connect(ccz2      ,ccz2show      );
                String s33 =Utility.connect(ccz3      ,ccz3show      );
                String s34 =Utility.connect(ccz4      ,ccz4show      );
                String s35 =Utility.connect(ccz5      ,ccz5show      );
                String s36 =Utility.connect(ccz6      ,ccz6show      );
                String s37 =Utility.connect(ccy1      ,ccy1show      );
                String s38 =Utility.connect(ccy2      ,ccy2show      );
                String s39 =Utility.connect(ccy3      ,ccy3show      );
                String s40 =Utility.connect(ccy4      ,ccy4show      );
                String s41 =Utility.connect(ccy5      ,ccy5show      );
                String s42 =Utility.connect(ccy6      ,ccy6show      );
                String s43 =Utility.connect(bxgqb     ,bxgqbshow     );
                String s44 =Utility.connect(bxghb     ,bxghbshow     );
                String s45 =Utility.connect(fdblqb    ,fdblqbshow    );
                String s46 =Utility.connect(fdblhb    ,fdblhbshow    );
                String s47 =Utility.connect(ygqqb     ,ygqqbshow     );
                String s48 =Utility.connect(ygqhb     ,ygqhbshow     );
                String s49 =Utility.connect(dg        ,dgshow        );
                String s50 =Utility.connect(dbkt      ,dbktshow      );
                String s51 =Utility.connect(dp        ,dpshow        );
                String s52 =Utility.connect(pqg       ,pqgshow       );
                String s53 =Utility.connect(chzhq     ,chzhqshow     );
                String s54 =Utility.connect(wzA       ,wzAshow       );
                String s55 =Utility.connect(dy        ,dyshow        );
                String s56 =Utility.connect(dyxdcsscd ,dyxdcsscdshow );
                String s57 =Utility.connect(dldccwz   ,dldccwzshow   );
                String s58 =Utility.connect(cdkwz     ,cdkwzshow     );
                String s59 =Utility.connect(cdqwz     ,cdqwzshow     );
                String s60 =Utility.connect(wkcz      ,wkczshow      );
                String s63 =Utility.connect(czfs      ,czfsshow      );
                String s65 =Utility.connect(dldccsscd ,dldccsscdshow );
                String s70 =Utility.connect(wzB       ,wzBshow       );
                String s71 =Utility.connect(dcglxtsscd,dcglxtsscdshow);
                String s72 =Utility.connect(ddj       ,ddjshow       );
                String s73 =Utility.connect(djkzq     ,djkzqshow     );
                String s74 =Utility.connect(jsx       ,jsxshow       );
                String s75 =Utility.connect(dyzhq     ,dyzhqshow     );
                String s76 =Utility.connect(gypdh     ,gypdhshow     );
                String s77 =Utility.connect(bxh       ,bxhshow       );
                String s78 =Utility.connect(jqqg      ,jqqgshow      );
                String s79 =Utility.connect(pqqg      ,pqqgshow      );
                String s80 =Utility.connect(bsqlhq    ,bsqlhqshow    );
                String s81 =Utility.connect(zkzlqzkb  ,zkzlqzkbshow  );
                String s82 =Utility.connect(srq       ,srqshow       );
                String s83 =Utility.connect(lqfs      ,lqfsshow      );
                String s84 =Utility.connect(ABSkzq    ,ABSkzqshow    );
                String s85 =Utility.connect(zqd       ,zqdshow       );
                String s86 =Utility.connect(yqd       ,yqdshow       );
                String s87 =Utility.connect(fdongj    ,fdongjshow    );
                String s88 =Utility.connect(qdj       ,qdjshow       );
                String s89 =Utility.connect(fdianj    ,fdianjshow    );
                String s90 =Utility.connect(ybb       ,ybbshow       );
                String s91 =Utility.connect(jxh       ,jxhshow       );
                String s92 =Utility.connect(zxp       ,zxpshow       );
                String s93 =Utility.connect(dhkg      ,dhkgshow      );
                String s94 =Utility.connect(gfj       ,gfjshow       );
                String s95 =Utility.connect(yspbfq    ,yspbfqshow    );
                String s96 =Utility.connect(jtq       ,jtqshow       );
                String s97 =Utility.connect(jswzy     ,jswzyshow     );
                String s98 =Utility.connect(fjszy     ,fjszyshow     );
                String s99 =Utility.connect(ckzy      ,ckzyshow      );
                String s100 =Utility.connect(qbdb      ,qbdbshow      );
                String s101 =Utility.connect(hbdb      ,hbdbshow      );
                String s102 =Utility.connect(zqcd      ,zqcdshow      );
                String s103 =Utility.connect(zhcd      ,zhcdshow      );
                String s104 =Utility.connect(yqcd      ,yqcdshow      );
                String s105 =Utility.connect(yhcd      ,yhcdshow      );
                String s106 =Utility.connect(z1cm      ,z1cmshow      );
                String s107 =Utility.connect(y1cm      ,y1cmshow      );
                String s108 =Utility.connect(y2cm      ,y2cmshow      );
                String s109 =Utility.connect(y3cm      ,y3cmshow      );
                String s111 =Utility.connect(sscd      ,sscdshow      );

                String s2  =qhbw.getText().toString();
                String s61 =eddy.getText().toString();
                String s62 =edrl.getText().toString();
                String s64 =hdzt.getText().toString();
                String s66 =dcdtlx.getText().toString();
                String s67 =dcdtxh.getText().toString();
                String s68 =dcdtedrl.getText().toString();
                String s69 =dcdteddy.getText().toString();
                String s110 =zywp.getText().toString();

                String[] args2 = {acc_ID_time,clsbdm,s3, s4, s5, s6, s7, s8, s9, s10, s11, s12, s13, s14, s15, s16, s17, s18, s19,
                        s20, s21, s22, s23, s24, s25, s26, s27, s28, s29, s30, s31, s32, s33, s34, s35, s36, s37, s38,
                        s39, s40, s41, s42, s43, s44, s45, s46, s47, s48, s49, s50, s51, s52, s53};
                String[] args4 = {acc_ID_time,clsbdm,s54, s55, s56, s57,
                        s58, s59, s60, s61, s62, s63, s64, s65, s66, s67, s68, s69, s70, s71, s72, s73, s74, s75, s76,
                        s77, s78, s79, s80, s81, s82, s83, s84, s85, s86, s87, s88, s89, s90, s91, s92, s93, s94, s95,
                        s96, s97, s98, s99, s100, s101, s102, s103, s104, s105, s106, s107, s108, s109, s110, s111};
                String[] args20={acc_ID_time,clsbdm,s1,s2};

                Utility.insert(db,"baseinfo_bqh",args10,args20);
                Utility.insert(db, "baseinfo_b5W", args1, args2);
                Utility.insert(db, "baseinfo_b5N", args3, args4);

                /*db = helper.getWritableDatabase();
                List<InfoB5> infoB5 = query(db);
                // 写入数据到工作簿对象内
                Workbook workbook = exportData(infoB5);
                // 以文件的形式输出工作簿对象
                Utility.newExcel(workbook, "/B5.xlsx");*/
                Intent intent = new Intent(ActivityB5.this, ActivityBB.class);
                intent.putExtra("acc_ID_time",acc_ID_time);
                intent.putExtra("clsbdm",clsbdm);
                intent.putExtra("wjm",wjm);
                startActivity(intent);
                break;

                case R.id.b5_btn_photo:
                Intent intent_camera = new Intent(ActivityB5.this, CameraActivity.class);
                intent_camera.putExtra("wjm",wjm);
                startActivity(intent_camera);
                break;
        }
    }
}