package com.example.applll.activity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.applll.R;
import com.example.applll.Utility;
import com.example.applll.service.DbManger;
import com.example.applll.service.MySQLiteHelper;

public class ActivityBB extends AppCompatActivity {

    private MySQLiteHelper helper= DbManger.getIntance(this);

    private String[] args1 = {"acc_ID","CLSBDM","QFZYWT1","QFSSCD1","QFZYWT2","QFSSCD2","HFZYWT1","HFSSCD1","HFZYWT2",
            "HFSSCD2","ZCZYWT1","ZCSSCD1","ZCZYWT2","ZCSSCD2","YCZYWT1","YCSSCD1","YCZYWT2","YCSSCD2",
            "SFZYWT1","SFSSCD1","SFZYWT2","SFSSCD2","DMZYWT1","DMSSCD1","DMZYWT2","DMSSCD2"};
    private String[] args3 = {"acc_ID","CLSBDM","ZYSSBJMC1","ZYSSBJSSCD1","ZSDQXL1","FJDQXL1","ZYSSBJMC2","ZYSSBJSSCD2","ZSDQXL2","FJDQXL2","ZYKRWMC1",
            "ZYKRWSSCD1","ZYKRWMC2","ZYKRWSSCD2"};
    
    private Spinner qfzywt1,qfsscd1,qfzywt2,qfsscd2,hfzywt1,hfsscd1,hfzywt2,hfsscd2,zczywt1,zcsscd1,zczywt2,
            zcsscd2,yczywt1,ycsscd1,yczywt2,ycsscd2,sfzywt1,sfsscd1,sfzywt2,sfsscd2,dmzywt1,dmsscd1,dmzywt2,
            dmsscd2,zyssbjsscd1,zsdqxl1,fjdqxl1,zyssbjsscd2,zsdqxl2,fjdqxl2,zykrwsscd1,zykrwsscd2;
    
    private TextView qfzywt1show,qfsscd1show,qfzywt2show,qfsscd2show,hfzywt1show,hfsscd1show,hfzywt2show,
            hfsscd2show,zczywt1show,zcsscd1show,zczywt2show,zcsscd2show,yczywt1show,ycsscd1show,yczywt2show,
            ycsscd2show,sfzywt1show,sfsscd1show,sfzywt2show,sfsscd2show,dmzywt1show,dmsscd1show,dmzywt2show,
            dmsscd2show,zyssbjsscd1show,zsdqxl1show,fjdqxl1show,zyssbjsscd2show,zsdqxl2show,fjdqxl2show,
            zykrwsscd1show,zykrwsscd2show;
    
    private EditText zyssbjmc1,zyssbjmc2,zykrwmc1,zykrwmc2;
    String acc_ID_time,clsbdm,wjm;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bb);

        Intent intent0=getIntent();
        acc_ID_time=intent0.getStringExtra("acc_ID_time");
        clsbdm=intent0.getStringExtra("clsbdm");
        //Log.i("CLSBDM",clsbdm);
        wjm=intent0.getStringExtra("wjm");
        qfzywt1     = findViewById(R.id.bb_sp_qfzywt1    );
        qfsscd1     = findViewById(R.id.bb_sp_qfsscd1    );
        qfzywt2     = findViewById(R.id.bb_sp_qfzywt2    );
        qfsscd2     = findViewById(R.id.bb_sp_qfsscd2    );
        hfzywt1     = findViewById(R.id.bb_sp_hfzywt1    );
        hfsscd1     = findViewById(R.id.bb_sp_hfsscd1    );
        hfzywt2     = findViewById(R.id.bb_sp_hfzywt2    );
        hfsscd2     = findViewById(R.id.bb_sp_hfsscd2    );
        zczywt1     = findViewById(R.id.bb_sp_zczywt1    );
        zcsscd1     = findViewById(R.id.bb_sp_zcsscd1    );
        zczywt2     = findViewById(R.id.bb_sp_zczywt2    );
        zcsscd2     = findViewById(R.id.bb_sp_zcsscd2    );
        yczywt1     = findViewById(R.id.bb_sp_yczywt1    );
        ycsscd1     = findViewById(R.id.bb_sp_ycsscd1    );
        yczywt2     = findViewById(R.id.bb_sp_yczywt2    );
        ycsscd2     = findViewById(R.id.bb_sp_ycsscd2    );
        sfzywt1     = findViewById(R.id.bb_sp_sfzywt1    );
        sfsscd1     = findViewById(R.id.bb_sp_sfsscd1    );
        sfzywt2     = findViewById(R.id.bb_sp_sfzywt2    );
        sfsscd2     = findViewById(R.id.bb_sp_sfsscd2    );
        dmzywt1     = findViewById(R.id.bb_sp_dmzywt1    );
        dmsscd1     = findViewById(R.id.bb_sp_dmsscd1    );
        dmzywt2     = findViewById(R.id.bb_sp_dmzywt2    );
        dmsscd2     = findViewById(R.id.bb_sp_dmsscd2    );
        zyssbjsscd1 = findViewById(R.id.bb_sp_zyssbjsscd1);
        zsdqxl1     = findViewById(R.id.bb_sp_zsdqxl1    );
        fjdqxl1     = findViewById(R.id.bb_sp_fjdqxl1    );
        zyssbjsscd2 = findViewById(R.id.bb_sp_zyssbjsscd2);
        zsdqxl2     = findViewById(R.id.bb_sp_zsdqxl2    );
        fjdqxl2     = findViewById(R.id.bb_sp_fjdqxl2    );
        zykrwsscd1  = findViewById(R.id.bb_sp_zykrwsscd1 );
        zykrwsscd2  = findViewById(R.id.bb_sp_zykrwsscd2 );
        
        qfzywt1show     = findViewById(R.id.bb_tv_show_qfzywt1    );
        qfsscd1show     = findViewById(R.id.bb_tv_show_qfsscd1    );
        qfzywt2show     = findViewById(R.id.bb_tv_show_qfzywt2    );
        qfsscd2show     = findViewById(R.id.bb_tv_show_qfsscd2    );
        hfzywt1show     = findViewById(R.id.bb_tv_show_hfzywt1    );
        hfsscd1show     = findViewById(R.id.bb_tv_show_hfsscd1    );
        hfzywt2show     = findViewById(R.id.bb_tv_show_hfzywt2    );
        hfsscd2show     = findViewById(R.id.bb_tv_show_hfsscd2    );
        zczywt1show     = findViewById(R.id.bb_tv_show_zczywt1    );
        zcsscd1show     = findViewById(R.id.bb_tv_show_zcsscd1    );
        zczywt2show     = findViewById(R.id.bb_tv_show_zczywt2    );
        zcsscd2show     = findViewById(R.id.bb_tv_show_zcsscd2    );
        yczywt1show     = findViewById(R.id.bb_tv_show_yczywt1    );
        ycsscd1show     = findViewById(R.id.bb_tv_show_ycsscd1    );
        yczywt2show     = findViewById(R.id.bb_tv_show_yczywt2    );
        ycsscd2show     = findViewById(R.id.bb_tv_show_ycsscd2    );
        sfzywt1show     = findViewById(R.id.bb_tv_show_sfzywt1    );
        sfsscd1show     = findViewById(R.id.bb_tv_show_sfsscd1    );
        sfzywt2show     = findViewById(R.id.bb_tv_show_sfzywt2    );
        sfsscd2show     = findViewById(R.id.bb_tv_show_sfsscd2    );
        dmzywt1show     = findViewById(R.id.bb_tv_show_dmzywt1    );
        dmsscd1show     = findViewById(R.id.bb_tv_show_dmsscd1    );
        dmzywt2show     = findViewById(R.id.bb_tv_show_dmzywt2    );
        dmsscd2show     = findViewById(R.id.bb_tv_show_dmsscd2    );
        zyssbjsscd1show = findViewById(R.id.bb_tv_show_zyssbjsscd1);
        zsdqxl1show     = findViewById(R.id.bb_tv_show_zsdqxl1    );
        fjdqxl1show     = findViewById(R.id.bb_tv_show_fjdqxl1    );
        zyssbjsscd2show = findViewById(R.id.bb_tv_show_zyssbjsscd2);
        zsdqxl2show     = findViewById(R.id.bb_tv_show_zsdqxl2    );
        fjdqxl2show     = findViewById(R.id.bb_tv_show_fjdqxl2    );
        zykrwsscd1show  = findViewById(R.id.bb_tv_show_zykrwsscd1 );
        zykrwsscd2show  = findViewById(R.id.bb_tv_show_zykrwsscd2 );
        
        zyssbjmc1 = findViewById(R.id.bb_et_zyssbjmc1);
        zyssbjmc2 = findViewById(R.id.bb_et_zyssbjmc2);
        zykrwmc1 = findViewById(R.id.bb_et_zykrwmc1);
        zykrwmc2 = findViewById(R.id.bb_et_zykrwmc2);
        
        Utility.ifOrnot(this,qfzywt1    ,qfzywt1show    );
        Utility.ifOrnot(this,qfsscd1    ,qfsscd1show    );
        Utility.ifOrnot(this,qfzywt2    ,qfzywt2show    );
        Utility.ifOrnot(this,qfsscd2    ,qfsscd2show    );
        Utility.ifOrnot(this,hfzywt1    ,hfzywt1show    );
        Utility.ifOrnot(this,hfsscd1    ,hfsscd1show    );
        Utility.ifOrnot(this,hfzywt2    ,hfzywt2show    );
        Utility.ifOrnot(this,hfsscd2    ,hfsscd2show    );
        Utility.ifOrnot(this,zczywt1    ,zczywt1show    );
        Utility.ifOrnot(this,zcsscd1    ,zcsscd1show    );
        Utility.ifOrnot(this,zczywt2    ,zczywt2show    );
        Utility.ifOrnot(this,zcsscd2    ,zcsscd2show    );
        Utility.ifOrnot(this,yczywt1    ,yczywt1show    );
        Utility.ifOrnot(this,ycsscd1    ,ycsscd1show    );
        Utility.ifOrnot(this,yczywt2    ,yczywt2show    );
        Utility.ifOrnot(this,ycsscd2    ,ycsscd2show    );
        Utility.ifOrnot(this,sfzywt1    ,sfzywt1show    );
        Utility.ifOrnot(this,sfsscd1    ,sfsscd1show    );
        Utility.ifOrnot(this,sfzywt2    ,sfzywt2show    );
        Utility.ifOrnot(this,sfsscd2    ,sfsscd2show    );
        Utility.ifOrnot(this,dmzywt1    ,dmzywt1show    );
        Utility.ifOrnot(this,dmsscd1    ,dmsscd1show    );
        Utility.ifOrnot(this,dmzywt2    ,dmzywt2show    );
        Utility.ifOrnot(this,dmsscd2    ,dmsscd2show    );
        Utility.ifOrnot(this,zyssbjsscd1,zyssbjsscd1show);
        Utility.ifOrnot(this,zsdqxl1    ,zsdqxl1show    );
        Utility.ifOrnot(this,fjdqxl1    ,fjdqxl1show    );
        Utility.ifOrnot(this,zyssbjsscd2,zyssbjsscd2show);
        Utility.ifOrnot(this,zsdqxl2    ,zsdqxl2show    );
        Utility.ifOrnot(this,fjdqxl2    ,fjdqxl2show    );
        Utility.ifOrnot(this,zykrwsscd1 ,zykrwsscd1show );
        Utility.ifOrnot(this,zykrwsscd2 ,zykrwsscd2show );
    }

    public void click(View view) {
        switch (view.getId()){
            case R.id.bb_btn_next:
                SQLiteDatabase db = helper.getWritableDatabase();
                
                String s1  = Utility.connect(qfzywt1    ,qfzywt1show    );
                String s2  = Utility.connect(qfsscd1    ,qfsscd1show    );
                String s3  = Utility.connect(qfzywt2    ,qfzywt2show    );
                String s4  = Utility.connect(qfsscd2    ,qfsscd2show    );
                String s5  = Utility.connect(hfzywt1    ,hfzywt1show    );
                String s6  = Utility.connect(hfsscd1    ,hfsscd1show    );
                String s7  = Utility.connect(hfzywt2    ,hfzywt2show    );
                String s8  = Utility.connect(hfsscd2    ,hfsscd2show    );
                String s9  = Utility.connect(zczywt1    ,zczywt1show    );
                String s10 = Utility.connect(zcsscd1    ,zcsscd1show    );
                String s11 = Utility.connect(zczywt2    ,zczywt2show    );
                String s12 = Utility.connect(zcsscd2    ,zcsscd2show    );
                String s13 = Utility.connect(yczywt1    ,yczywt1show    );
                String s14 = Utility.connect(ycsscd1    ,ycsscd1show    );
                String s15 = Utility.connect(yczywt2    ,yczywt2show    );
                String s16 = Utility.connect(ycsscd2    ,ycsscd2show    );
                String s17 = Utility.connect(sfzywt1    ,sfzywt1show    );
                String s18 = Utility.connect(sfsscd1    ,sfsscd1show    );
                String s19 = Utility.connect(sfzywt2    ,sfzywt2show    );
                String s20 = Utility.connect(sfsscd2    ,sfsscd2show    );
                String s21 = Utility.connect(dmzywt1    ,dmzywt1show    );
                String s22 = Utility.connect(dmsscd1    ,dmsscd1show    );
                String s23 = Utility.connect(dmzywt2    ,dmzywt2show    );
                String s24 = Utility.connect(dmsscd2    ,dmsscd2show    );
                String s26 = Utility.connect(zyssbjsscd1,zyssbjsscd1show);
                String s27 = Utility.connect(zsdqxl1    ,zsdqxl1show    );
                String s28 = Utility.connect(fjdqxl1    ,fjdqxl1show    );
                String s30 = Utility.connect(zyssbjsscd2,zyssbjsscd2show);
                String s31 = Utility.connect(zsdqxl2    ,zsdqxl2show    );
                String s32 = Utility.connect(fjdqxl2    ,fjdqxl2show    );
                String s34 = Utility.connect(zykrwsscd1 ,zykrwsscd1show );
                String s36 = Utility.connect(zykrwsscd2 ,zykrwsscd2show );
                
                String s25 = zyssbjmc1.getText().toString(); 
                String s29 = zyssbjmc2.getText().toString();
                String s33 = zykrwmc1.getText().toString();
                String s35 = zykrwmc2.getText().toString();

                String[] args2={acc_ID_time,clsbdm,s1,s2,s3,s4,s5,s6,s7,s8,s9,s10,s11,s12,s13,s14,s15,s16,s17,s18,s19,
                        s20,s21,s22,s23,s24};
                String[] args4={acc_ID_time,clsbdm,s25,s26,s27,s28,s29,s30,s31,s32,s33,s34,s35,s36};
                Utility.insert(db,"baseinfo_bb",args1,args2);
                Utility.insert(db,"baseinfo_bbb",args3,args4);
                Intent intent = new Intent(ActivityBB.this, ActivityC.class);
                intent.putExtra("acc_ID_time",acc_ID_time);
                intent.putExtra("wjm",wjm);
                //intent.putExtra("clsbdm",clsbdm);
                startActivity(intent);
                break;

            case R.id.bb_btn_photo:
                Intent intent_camera = new Intent(ActivityBB.this, CameraActivity.class);
                intent_camera.putExtra("wjm",wjm);
                startActivity(intent_camera);
                break;
        }
    }
}