package com.example.applll.pojo;

public class InfoBQH {
    public String acc_id;
    public String clsbdm;
    public String myqs;
    public String qhbw;
}
