package com.example.applll.activity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.applll.R;
import com.example.applll.Utility;
import com.example.applll.service.DbManger;
import com.example.applll.service.MySQLiteHelper;

public class ActivityB extends AppCompatActivity {

    private MySQLiteHelper helper = DbManger.getIntance(this);

    private String[] args1 = {"acc_ID", "CLSBDM", "PPXH", "CLXZ", "CLZCSJ", "XSLC", "SFQXSJL", "SFQXSSJ", "SFQTFSJ", "SFSZT",
            "SFHTFWZ", "ZYFS", "SFJZ", "JZBJ", "JZSJ", "JZWZ", "ZJWBSJ", "WBMD", "WBNR", "GMBX", "TBXZ", "TBSJ","CLZL"};

    private Spinner sfszt, sfhtfwz, zyfs, sfjz, wbmd, gmbx;

    private TextView clzcsjshow, sfsztshow, sfhtfwzshow, zyfsshow, sfjzshow, jzsjshow, jzwzshow, zjwbsjshow,
            wbmdshow, gmbxshow, tbsjshow, tbxzshow;

    private Button clzcsj, jzsj, jzwz, zjwbsj, tbsj,tbxz;

    private EditText clsbdm, ppxh, clxz, xslc, sfqxsjl, sfqxssj, sfqtfsj, jzbj, wbnr;
    String acc_ID_time,wjm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_b);

        Intent intent = getIntent();
        acc_ID_time = intent.getStringExtra("acc_ID_time");
        wjm=intent.getStringExtra("wjm");
        sfszt = findViewById(R.id.b_sp_sfszt);
        sfhtfwz = findViewById(R.id.b_sp_sfhtfwz);
        zyfs = findViewById(R.id.b_sp_zyfs);
        sfjz = findViewById(R.id.b_sp_sfjz);
        wbmd = findViewById(R.id.b_sp_wbmd);
        gmbx = findViewById(R.id.b_sp_gmbx);
        //tbxz = findViewById(R.id.b_sp_tbxz);

        clzcsj = findViewById(R.id.b_btn_clzcsj);
        jzsj = findViewById(R.id.b_btn_jzsj);
        jzwz = findViewById(R.id.b_btn_jzwz);
        zjwbsj = findViewById(R.id.b_btn_zjwbsj);
        tbsj = findViewById(R.id.b_btn_tbsj);
        tbxz=findViewById(R.id.b_btn_tbxz);

        clzcsjshow = findViewById(R.id.b_tv_show_clzcsj);
        sfsztshow = findViewById(R.id.b_tv_show_sfszt);
        sfhtfwzshow = findViewById(R.id.b_tv_show_sfhtfwz);
        zyfsshow = findViewById(R.id.b_tv_show_zyfs);
        sfjzshow = findViewById(R.id.b_tv_show_sfjz);
        jzsjshow = findViewById(R.id.b_tv_show_jzsj);
        jzwzshow = findViewById(R.id.b_tv_show_jzwz);
        zjwbsjshow = findViewById(R.id.b_tv_show_zjwbsj);
        wbmdshow = findViewById(R.id.b_tv_show_wbmd);
        gmbxshow = findViewById(R.id.b_tv_show_gmbx);
        tbsjshow = findViewById(R.id.b_tv_show_tbsj);
        tbxzshow = findViewById(R.id.b_tv_show_tbxz);
        //myqsshow    =findViewById(R.id.b_tv_show_myqs);

        clsbdm = findViewById(R.id.b_et_clsbdm);
        ppxh = findViewById(R.id.b_et_ppxh);
        clxz = findViewById(R.id.b_et_clxz);
        xslc = findViewById(R.id.b_et_xslc);
        sfqxsjl = findViewById(R.id.b_et_sfqxsjl);
        sfqxssj = findViewById(R.id.b_et_sfqxssj);
        sfqtfsj = findViewById(R.id.b_et_sfqtfsj);
        jzbj = findViewById(R.id.b_et_jzbj);
        wbnr = findViewById(R.id.b_et_wbnr);
        //myqs = findViewById(R.id.b_sp_myqs);
        //qhbw = findViewById(R.id.b_et_qhbw);

        Utility.ifOrnot(this, sfszt, sfsztshow);
        Utility.ifOrnot(this, sfhtfwz, sfhtfwzshow);
        Utility.ifOrnot(this, zyfs, zyfsshow);
        Utility.ifOrnot(this, sfjz, sfjzshow);
        Utility.ifOrnot(this, wbmd, wbmdshow);
        Utility.ifOrnot(this, gmbx, gmbxshow);
        //Utility.ifOrnot(this, tbxz, tbxzshow);
        //Utility.ifOrnot(this,myqs,myqsshow);
    }

    public void click(View view) {
        switch (view.getId()) {
            case R.id.b_btn_clzcsj:
                clzcsjshow = findViewById(R.id.b_tv_show_clzcsj);
                Utility.datePick(this, clzcsjshow);//车辆注册时间
                break;

            case R.id.b_btn_jzsj:
                jzsjshow = findViewById(R.id.b_tv_show_jzsj);
                Utility.datePick(this, jzsjshow);//加装时间
                break;

            case R.id.b_btn_jzwz:
                jzwzshow = findViewById(R.id.b_tv_show_jzwz);
                String[] items = {"1发动机舱/动力机舱", "2驾驶室", "3后备箱/货箱", "4车轮", "5底盘", "6乘员舱", "8其他", "9未知"};
                boolean[] checkedItems = {false, false, false, false, false, false, false, false};
                Utility.multiSelect(this, jzwzshow, items, checkedItems);
                break;

            case R.id.b_btn_zjwbsj:
                zjwbsjshow = findViewById(R.id.b_tv_show_zjwbsj);
                Utility.datePick(this, zjwbsjshow);//最近维保时间
                break;

            case R.id.b_btn_tbsj:
                tbsjshow = findViewById(R.id.b_tv_show_tbsj);
                Utility.datePick(this, tbsjshow);//投保时间
                break;

            case R.id.b_btn_tbxz:
                tbxzshow = findViewById(R.id.b_tv_show_tbxz);
                String[] items2 = {"1车损险","2自燃险","3交强险","4第三者责任险","8其他","9未知"};
                boolean[] checkedItems2 = {false, false, false, false, false, false, false, false};
                Utility.multiSelect(this, tbxzshow, items2, checkedItems2);
                break;

            case R.id.b_btn_B1:
                SQLiteDatabase db = helper.getWritableDatabase();

                String s1 = clsbdm.getText().toString();
                String s2 = ppxh.getText().toString();
                String s3 = clxz.getText().toString();
                String s4 = clzcsjshow.getText().toString();
                String s5 = xslc.getText().toString();
                String s6 = sfqxsjl.getText().toString();
                String s7 = sfqxssj.getText().toString();
                String s8 = sfqtfsj.getText().toString();
                String s9 = Utility.connect(sfszt, sfsztshow);
                String s10 = Utility.connect(sfhtfwz, sfhtfwzshow);
                String s11 = Utility.connect(zyfs, zyfsshow);
                String s12 = Utility.connect(sfjz, sfjzshow);
                String s13 = jzbj.getText().toString();
                String s14 = jzsjshow.getText().toString();
                String s15 = jzwzshow.getText().toString();
                String s16 = zjwbsjshow.getText().toString();
                String s17 = Utility.connect(wbmd, wbmdshow);
                String s18 = wbnr.getText().toString();
                String s19 = Utility.connect(gmbx, gmbxshow);
                //String s20 = Utility.connect(tbxz, tbxzshow);
                String s20=tbxzshow.getText().toString();
                String s21 = tbsjshow.getText().toString();
                //String s22 = Utility.connect(myqs,myqsshow);
                //String s23 = qhbw.getText().toString();
                String s24 = "1";

                String[] args2 = {acc_ID_time, s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12, s13, s14, s15, s16, s17, s18, s19, s20, s21,s24};
                Utility.insert(db, "baseinfo_b", args1, args2);

                Intent intent1 = new Intent(ActivityB.this, ActivityB1.class);
                intent1.putExtra("acc_ID_time",acc_ID_time);
                intent1.putExtra("wjm",wjm);
                intent1.putExtra("clsbdm",s1);
                startActivity(intent1);
                break;

            case R.id.b_btn_B2:
                SQLiteDatabase db2 = helper.getWritableDatabase();

                String s1_2 = clsbdm.getText().toString();
                String s2_2 = ppxh.getText().toString();
                String s32 = clxz.getText().toString();
                String s42 = clzcsjshow.getText().toString();
                String s52 = xslc.getText().toString();
                String s62 = sfqxsjl.getText().toString();
                String s72 = sfqxssj.getText().toString();
                String s82 = sfqtfsj.getText().toString();
                String s92 = Utility.connect(sfszt, sfsztshow);
                String s102 = Utility.connect(sfhtfwz, sfhtfwzshow);
                String s112 = Utility.connect(zyfs, zyfsshow);
                String s122 = Utility.connect(sfjz, sfjzshow);
                String s132 = jzbj.getText().toString();
                String s142 = jzsjshow.getText().toString();
                String s152 = jzwzshow.getText().toString();
                String s162 = zjwbsjshow.getText().toString();
                String s172 = Utility.connect(wbmd, wbmdshow);
                String s182 = wbnr.getText().toString();
                String s192 = Utility.connect(gmbx, gmbxshow);
                //String s202 = Utility.connect(tbxz, tbxzshow);
                String s202 = tbxzshow.getText().toString();
                String s212 = tbsjshow.getText().toString();
                //String s222 = Utility.connect(myqs,myqsshow);
                //String s232 = qhbw.getText().toString();
                String s242 = "2";

                String[] args22 = {acc_ID_time, s1_2, s2_2, s32, s42, s52, s62, s72, s82, s92, s102, s112, s122, s132, s142, s152, s162, s172, s182, s192, s202, s212,s242};
                Utility.insert(db2, "baseinfo_b", args1, args22);

                Intent intent2 = new Intent(ActivityB.this, ActivityB2.class);
                intent2.putExtra("acc_ID_time",acc_ID_time);
                intent2.putExtra("clsbdm",s1_2);
                intent2.putExtra("wjm",wjm);
                startActivity(intent2);
                break;

            case R.id.b_btn_B3:
                SQLiteDatabase db3 = helper.getWritableDatabase();

                String s1_3 = clsbdm.getText().toString();
                String s2_3 = ppxh.getText().toString();
                String s33 = clxz.getText().toString();
                String s43 = clzcsjshow.getText().toString();
                String s53 = xslc.getText().toString();
                String s63 = sfqxsjl.getText().toString();
                String s73 = sfqxssj.getText().toString();
                String s83 = sfqtfsj.getText().toString();
                String s93 = Utility.connect(sfszt, sfsztshow);
                String s103 = Utility.connect(sfhtfwz, sfhtfwzshow);
                String s113 = Utility.connect(zyfs, zyfsshow);
                String s123 = Utility.connect(sfjz, sfjzshow);
                String s133 = jzbj.getText().toString();
                String s143 = jzsjshow.getText().toString();
                String s153 = jzwzshow.getText().toString();
                String s163 = zjwbsjshow.getText().toString();
                String s173 = Utility.connect(wbmd, wbmdshow);
                String s183 = wbnr.getText().toString();
                String s193 = Utility.connect(gmbx, gmbxshow);
                //String s203 = Utility.connect(tbxz, tbxzshow);
                String s203 = tbxzshow.getText().toString();
                String s213 = tbsjshow.getText().toString();
                //String s223 = Utility.connect(myqs,myqsshow);
                //String s233 = qhbw.getText().toString();
                String s243 = "3";

                String[] args23 = {acc_ID_time, s1_3, s2_3, s33, s43, s53, s63, s73, s83, s93, s103, s113, s123, s133, s143, s153, s163, s173, s183, s193, s203, s213,s243};
                Utility.insert(db3, "baseinfo_b", args1, args23);

                Intent intent3 = new Intent(ActivityB.this, ActivityB3.class);
                intent3.putExtra("acc_ID_time",acc_ID_time);
                intent3.putExtra("clsbdm",s1_3);
                intent3.putExtra("wjm",wjm);
                startActivity(intent3);
                break;

            case R.id.b_btn_B4:
                SQLiteDatabase db4 = helper.getWritableDatabase();

                String s1_4 = clsbdm.getText().toString();
                String s2_4 = ppxh.getText().toString();
                String s34 = clxz.getText().toString();
                String s44 = clzcsjshow.getText().toString();
                String s54 = xslc.getText().toString();
                String s64 = sfqxsjl.getText().toString();
                String s74 = sfqxssj.getText().toString();
                String s84 = sfqtfsj.getText().toString();
                String s94 = Utility.connect(sfszt, sfsztshow);
                String s140 = Utility.connect(sfhtfwz, sfhtfwzshow);
                String s141 = Utility.connect(zyfs, zyfsshow);
                String s124 = Utility.connect(sfjz, sfjzshow);
                String s134 = jzbj.getText().toString();
                String s144 = jzsjshow.getText().toString();
                String s154 = jzwzshow.getText().toString();
                String s164 = zjwbsjshow.getText().toString();
                String s174 = Utility.connect(wbmd, wbmdshow);
                String s184 = wbnr.getText().toString();
                String s194 = Utility.connect(gmbx, gmbxshow);
                //String s204 = Utility.connect(tbxz, tbxzshow);
                String s204 = tbxzshow.getText().toString();
                String s214 = tbsjshow.getText().toString();
                //String s224 = Utility.connect(myqs,myqsshow);
                //String s234 = qhbw.getText().toString();
                String s244 = "4";

                String[] args24 = {acc_ID_time, s1_4, s2_4, s34, s44, s54, s64, s74, s84, s94, s140, s141, s124, s134, s144, s154, s164, s174, s184, s194, s204, s214,s244};
                Utility.insert(db4, "baseinfo_b", args1, args24);

                Intent intent4 = new Intent(ActivityB.this, ActivityB4.class);
                intent4.putExtra("clsbdm",s1_4);
                intent4.putExtra("acc_ID_time",acc_ID_time);
                intent4.putExtra("wjm",wjm);
                startActivity(intent4);
                break;

            case R.id.b_btn_B5:
                SQLiteDatabase db5 = helper.getWritableDatabase();

                String s1_5 = clsbdm.getText().toString();
                String s25 = ppxh.getText().toString();
                String s35 = clxz.getText().toString();
                String s45 = clzcsjshow.getText().toString();
                String s55 = xslc.getText().toString();
                String s65 = sfqxsjl.getText().toString();
                String s75 = sfqxssj.getText().toString();
                String s85 = sfqtfsj.getText().toString();
                String s95 = Utility.connect(sfszt, sfsztshow);
                String s150 = Utility.connect(sfhtfwz, sfhtfwzshow);
                String s151 = Utility.connect(zyfs, zyfsshow);
                String s12_5 = Utility.connect(sfjz, sfjzshow);
                String s13_5 = jzbj.getText().toString();
                String s14_5 = jzsjshow.getText().toString();
                String s155 = jzwzshow.getText().toString();
                String s156 = zjwbsjshow.getText().toString();
                String s157 = Utility.connect(wbmd, wbmdshow);
                String s158 = wbnr.getText().toString();
                String s159 = Utility.connect(gmbx, gmbxshow);
                String s250 = tbxzshow.getText().toString();
                //String s250 = Utility.connect(tbxz, tbxzshow);
                String s251 = tbsjshow.getText().toString();
                //String s252 = Utility.connect(myqs,myqsshow);
                //String s253 = qhbw.getText().toString();
                String s254 = "5";

                String[] args25 = {acc_ID_time, s1_5, s25, s35, s45, s55, s65, s75, s85, s95, s150, s151, s12_5, s13_5, s14_5, s155, s156, s157, s158, s159, s250, s251,s254};
                Utility.insert(db5, "baseinfo_b", args1, args25);


                Intent intent5 = new Intent(ActivityB.this, ActivityB5.class);
                intent5.putExtra("acc_ID_time",acc_ID_time);
                intent5.putExtra("clsbdm",s1_5);
                intent5.putExtra("wjm",wjm);
                startActivity(intent5);
                break;

            case R.id.b_btn_photo:
                Intent intent_camera = new Intent(ActivityB.this, CameraActivity.class);
                intent_camera.putExtra("wjm",wjm);
                startActivity(intent_camera);
                break;
        }
    }

}