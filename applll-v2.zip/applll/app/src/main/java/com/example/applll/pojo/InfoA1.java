package com.example.applll.pojo;

public class InfoA1 {
    public String acc_id;
    public String time_find;
    public String dqp;//省
    public String dqc;//市
    public String dqs;//县
    public String jtwz;
    public String time_110;
    public String yon_119;
    public String time_119;
    public String yon_120;
    public String time_120;
    public int car_num;
    public int person_num;
    public int hurt_num;
    public String state;
    public String time_survey;
    public String caiji;
    public String luru;
}
