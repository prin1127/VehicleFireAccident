package com.example.applll.pojo;

public class InfoA2 {
    public String acc_id;
    public String sgdd;
    public String yctqs;
    public int pd;
    public String bmcz;
    public String bmzk;
    public String zwjk;
    public String weather;
    public String fx;
    public String fl;
    public int fs;
    public int wd;
    public String xcbh;
    public String clbh;
}
