package com.example.applll.activity;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.example.applll.R;
import com.example.applll.service.DbManger;
import com.example.applll.service.MySQLiteHelper;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    private MySQLiteHelper helper= DbManger.getIntance(this);
    Calendar calendar = Calendar.getInstance();
    int year = calendar.get(Calendar.YEAR);
    int month = calendar.get(Calendar.MONTH)+1;
    int day = calendar.get(Calendar.DAY_OF_MONTH);
    int hour = calendar.get(Calendar.HOUR_OF_DAY);
    int minute = calendar.get(Calendar.MINUTE);
    int second = calendar.get(Calendar.SECOND);
    //String acc_ID_time=year+"_"+month+"_"+day+"_"+hour+"_"+minute+"_"+second;
    String acc_ID_time=year+""+month+""+day+""+hour+""+minute+""+second;
    //String acc_ID_time=Integer.toString(year+month+day+hour+minute+second);
    String wjm=year+"_"+month+"_"+day+"_"+hour+"_"+minute+"_"+second;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // check Android 6 permission
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
            Log.i("TEST","Granted");
        } else {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);//1 can be another integer
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
            Log.i("TEST","Granted");
        } else {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 1);//1 can be another integer
        }
        /*if (Build.VERSION.SDK_INT >= 23) {
            int REQUEST_CODE_CONTACT = 101;
            String[] permissions = {Manifest.permission.WRITE_EXTERNAL_STORAGE};
            //验证是否许可权限
            for (String str : permissions) {
                if (this.checkSelfPermission(str) != PackageManager.PERMISSION_GRANTED) {
                    //申请权限
                    this.requestPermissions(permissions, REQUEST_CODE_CONTACT);
                    return;
                }
            }
        }*/
    }

    public void click(View view) {
        switch (view.getId()){
            case R.id.main_btn_next:
                SQLiteDatabase db = helper.getWritableDatabase();
                createTable(db);
                Intent intent = new Intent(MainActivity.this, ActivityA.class);
                Log.d("mainactivity",acc_ID_time);
                intent.putExtra("acc_ID_time",acc_ID_time);
                intent.putExtra("wjm",wjm);
                startActivity(intent);
                break;
        }
    }

    private void createTable(SQLiteDatabase db){
        String sqlaTPP = "CREATE TABLE IF NOT EXISTS [baseinfo_aTPP](\n" +
                "  [Acc_ID] VARCHAR PRIMARY KEY NOT NULL UNIQUE, \n" +
                "  [Time_Find] DATETIME, \n" +
                "  [DQP] VARCHAR, \n" +
                "  [DQC] VARCHAR, \n" +
                "  [DQS] VARCHAR, \n" +
                "  [JTWZ] VARCHAR, \n" +
                "  [Time_110] DATETIME, \n" +
                "  [YoN_119] VARCHAR, \n" +
                "  [Time_119] DATETIME, \n" +
                "  [YoN_120] VARCHAR, \n" +
                "  [Time_120] DATETIME, \n" +
                "  [Car_Num] INTEGER, \n" +
                "  [Person_Num] INTEGER, \n" +
                "  [Hurt_Num] INTEGER, \n" +
                "  [State] VARCHAR, \n" +
                "  [Time_Survey] DATETIME, \n" +
                "  [Caiji] VARCHAR, \n" +
                "  [Luru] VARCHAR);\n";
        String sqlaEnv = "CREATE TABLE IF NOT EXISTS [baseinfo_aEnv](\n" +
                "  [Acc_ID] VARCHAR PRIMARY KEY NOT NULL UNIQUE, \n" +
                "  [SGDD] VARCHAR, \n" +
                "  [YCTQS] VARCHAR, \n" +
                "  [PD] INTEGER, \n" +
                "  [BMCZ] VARCHAR, \n" +
                "  [BMZK] VARCHAR, \n" +
                "  [ZWJK] VARCHAR, \n" +
                "  [Weather] VARCHAR, \n" +
                "  [FX] VARCHAR, \n" +
                "  [FL] VARCHAR, \n" +
                "  [FS] INTEGER, \n" +
                "  [WD] INTEGER, \n" +
                "  [XCBH] VARCHAR, \n" +
                "  [CLBH] VARCHAR);";

        String sqlb = "CREATE TABLE IF NOT EXISTS [baseinfo_b](\n" +
                "  [Acc_ID] VARCHAR PRIMARY KEY NOT NULL, \n" +
                "  [CLSBDM] VARCHAR, \n" +
                "  [PPXH] VARCHAR, \n" +
                "  [CLXZ] VARCHAR, \n" +
                "  [CLZCSJ] VARCHAR, \n" +
                "  [XSLC] VARCHAR, \n" +
                "  [SFQXSJL] VARCHAR, \n" +
                "  [SFQXSSJ] VARCHAR, \n" +
                "  [SFQTFSJ] VARCHAR, \n" +
                "  [SFSZT] VARCHAR, \n" +
                "  [SFHTFWZ] VARCHAR, \n" +
                "  [ZYFS] VARCHAR, \n" +
                "  [SFJZ] VARCHAR, \n" +
                "  [JZBJ] VARCHAR, \n" +
                "  [JZSJ] VARCHAR, \n" +
                "  [JZWZ] VARCHAR, \n" +
                "  [ZJWBSJ] VARCHAR, \n" +
                "  [WBMD] VARCHAR, \n" +
                "  [WBNR] VARCHAR, \n" +
                "  [GMBX] VARCHAR, \n" +
                "  [TBXZ] VARCHAR, \n" +
                "  [TBSJ] VARCHAR, \n" +
                "  [MYQS] VARCHAR, \n" +
                "  [QHBW] VARCHAR, \n" +
                "  [CLZL] VARCHAR);\n";

        String sqlbqh = "CREATE TABLE IF NOT EXISTS [baseinfo_bqh](\n" +
                "  [Acc_ID] VARCHAR PRIMARY KEY NOT NULL, \n" +
                "  [CLSBDM] VARCHAR, \n" +
                "  [MYQS] VARCHAR, \n" +
                "  [QHBW] VARCHAR);\n";


        String sqlb1W = "CREATE TABLE IF NOT EXISTS [baseinfo_b1W](\n" +
                "  [Acc_ID] VARCHAR PRIMARY KEY NOT NULL, \n" +
                "  [CLSBDM] VARCHAR, \n" +
                //"  [MYQS] VARCHAR, \n" +
                //"  [QHBW] VARCHAR, \n" +
                "  [LTZQ] VARCHAR, \n" +
                "  [LTYQ] VARCHAR, \n" +
                "  [LTZH] VARCHAR, \n" +
                "  [LTYH] VARCHAR, \n" +
                "  [LWZQ] VARCHAR, \n" +
                "  [LWYQ] VARCHAR, \n" +
                "  [LWZH] VARCHAR, \n" +
                "  [LWYH] VARCHAR, \n" +
                "  [CMZQ] VARCHAR, \n" +
                "  [CMYQ] VARCHAR, \n" +
                "  [CMZH] VARCHAR, \n" +
                "  [CMYH] VARCHAR, \n" +
                "  [CCZQ] VARCHAR, \n" +
                "  [CCYQ] VARCHAR, \n" +
                "  [CCZH] VARCHAR, \n" +
                "  [CCYH] VARCHAR, \n" +
                "  [YZBZQ] VARCHAR, \n" +
                "  [YZBYQ] VARCHAR, \n" +
                "  [YZBZH] VARCHAR, \n" +
                "  [YZBYH] VARCHAR, \n" +
                "  [CDZQ] VARCHAR, \n" +
                "  [CDYQ] VARCHAR, \n" +
                "  [CDZH] VARCHAR, \n" +
                "  [CDYH] VARCHAR, \n" +
                "  [HSJZQ] VARCHAR, \n" +
                "  [HSJYQ] VARCHAR, \n" +
                "  [BXGQB] VARCHAR, \n" +
                "  [BXGHB] VARCHAR, \n" +
                "  [FDBLQB] VARCHAR, \n" +
                "  [FDBLHB] VARCHAR, \n" +
                "  [YGQQB] VARCHAR, \n" +
                "  [YGQHB] VARCHAR, \n" +
                "  [FDJCG] VARCHAR, \n" +
                "  [DG] VARCHAR, \n" +
                "  [TC] VARCHAR, \n" +
                "  [HBXG] VARCHAR, \n" +
                "  [DP] VARCHAR, \n" +
                "  [PQG] VARCHAR, \n" +
                "  [CHZHQ] VARCHAR);\n";
        String sqlb1N = "CREATE TABLE IF NOT EXISTS [baseinfo_b1N](\n" +
                "  [Acc_ID] VARCHAR PRIMARY KEY NOT NULL, \n" +
                "  [CLSBDM] VARCHAR, \n" +
                "  [WZ] VARCHAR, \n" +
                "  [DY] VARCHAR, \n" +
                "  [XDCSSCD] VARCHAR, \n" +
                "  [JYKWZ] VARCHAR, \n" +
                "  [CZ] VARCHAR, \n" +
                "  [YL] VARCHAR, \n" +
                "  [YXSSCD] VARCHAR, \n" +
                "  [FDONGJ] VARCHAR, \n" +
                "  [JQQG] VARCHAR, \n" +
                "  [FDIANJ] VARCHAR, \n" +
                "  [PQQG] VARCHAR, \n" +
                "  [QDJ] VARCHAR, \n" +
                "  [WLZYQ] VARCHAR, \n" +
                "  [DHXQ] VARCHAR, \n" +
                "  [LQYG] VARCHAR, \n" +
                "  [JYLQQ] VARCHAR, \n" +
                "  [QXYG] VARCHAR, \n" +
                "  [KQLQQ] VARCHAR, \n" +
                "  [ZDYG] VARCHAR, \n" +
                "  [ZKZLQ] VARCHAR, \n" +
                "  [ZLZXYG] VARCHAR, \n" +
                "  [BXH] VARCHAR, \n" +
                "  [KTYSJ] VARCHAR, \n" +
                "  [BSQLHQ] VARCHAR, \n" +
                "  [ABSKZQ] VARCHAR, \n" +
                "  [SRQ] VARCHAR, \n" +
                "  [ZQD] VARCHAR, \n" +
                "  [LNQ] VARCHAR, \n" +
                "  [YQD] VARCHAR, \n" +
                "  [LQFS] VARCHAR, \n" +
                "  [YBB] VARCHAR, \n" +
                "  [DYQ] VARCHAR, \n" +
                "  [ZXP] VARCHAR, \n" +
                "  [STX] VARCHAR, \n" +
                "  [ZYJXH] VARCHAR, \n" +
                "  [ZYFSX] VARCHAR, \n" +
                "  [DHKG] VARCHAR, \n" +
                "  [JSWZY] VARCHAR, \n" +
                "  [YSPBFQ] VARCHAR, \n" +
                "  [FJSZY] VARCHAR, \n" +
                "  [GFJ] VARCHAR, \n" +
                "  [HPZY] VARCHAR, \n" +
                "  [ZQM] VARCHAR, \n" +
                "  [YQM] VARCHAR, \n" +
                "  [ZHM] VARCHAR, \n" +
                "  [YHM] VARCHAR, \n" +
                "  [BT] VARCHAR, \n" +
                "  [ZHCD] VARCHAR, \n" +
                "  [YHCD] VARCHAR, \n" +
                "  [ZYWPA] VARCHAR, \n" +
                "  [SSCDA] VARCHAR, \n" +
                "  [ZYWPB] VARCHAR, \n" +
                "  [SSCDB] VARCHAR);";

        String sqlb2W = "CREATE TABLE IF NOT EXISTS [baseinfo_b2W](\n" +
                "  [Acc_ID] VARCHAR PRIMARY KEY NOT NULL, \n" +
                "  [CLSBDM] VARCHAR, \n" +
                //"  [MYQS] VARCHAR, \n" +
                //"  [QHBW] VARCHAR, \n" +
                "  [LTZ1] VARCHAR, \n" +
                "  [LTZ2] VARCHAR, \n" +
                "  [LTZ3] VARCHAR, \n" +
                "  [LTZ4] VARCHAR, \n" +
                "  [LTY1] VARCHAR, \n" +
                "  [LTY2] VARCHAR, \n" +
                "  [LTY3] VARCHAR, \n" +
                "  [LTY4] VARCHAR, \n" +
                "  [LWZ1] VARCHAR, \n" +
                "  [LWZ2] VARCHAR, \n" +
                "  [LWZ3] VARCHAR, \n" +
                "  [LWZ4] VARCHAR, \n" +
                "  [LWY1] VARCHAR, \n" +
                "  [LWY2] VARCHAR, \n" +
                "  [LWY3] VARCHAR, \n" +
                "  [LWY4] VARCHAR, \n" +
                "  [CMZ1] VARCHAR, \n" +
                "  [CMZ2] VARCHAR, \n" +
                "  [CMY1] VARCHAR, \n" +
                "  [CMY2] VARCHAR, \n" +
                "  [CCZ1] VARCHAR, \n" +
                "  [CCZ2] VARCHAR, \n" +
                "  [CCY1] VARCHAR, \n" +
                "  [CCY2] VARCHAR, \n" +
                "  [YZBZ] VARCHAR, \n" +
                "  [YZBY] VARCHAR, \n" +
                "  [CDZ1] VARCHAR, \n" +
                "  [CDZ2] VARCHAR, \n" +
                "  [CDZ3] VARCHAR, \n" +
                "  [CDZ4] VARCHAR, \n" +
                "  [CDY1] VARCHAR, \n" +
                "  [CDY2] VARCHAR, \n" +
                "  [CDY3] VARCHAR, \n" +
                "  [CDY4] VARCHAR, \n" +
                "  [HSJZ] VARCHAR, \n" +
                "  [HSJY] VARCHAR, \n" +
                "  [BXGQB] VARCHAR, \n" +
                "  [BXGHB] VARCHAR, \n" +
                "  [FDBLQB] VARCHAR, \n" +
                "  [FDBLHB] VARCHAR, \n" +
                "  [YGQ] VARCHAR, \n" +
                "  [PZSX] VARCHAR, \n" +
                "  [JSSDG] VARCHAR, \n" +
                "  [JSSHWB] VARCHAR, \n" +
                "  [CXQBZC] VARCHAR, \n" +
                "  [CXHBZC] VARCHAR, \n" +
                "  [CXZBBZC] VARCHAR, \n" +
                "  [CXDBZC] VARCHAR, \n" +
                "  [CXYBBZC] VARCHAR, \n" +
                "  [CDDB] VARCHAR, \n" +
                "  [DP] VARCHAR, \n" +
                "  [BT] VARCHAR, \n" +
                "  [PQG] VARCHAR, \n" +
                "  [CHZHQ] VARCHAR);\n";
        String sqlb2N = "CREATE TABLE IF NOT EXISTS [baseinfo_b2N](\n" +
                "  [Acc_ID] VARCHAR PRIMARY KEY NOT NULL, \n" +
                "  [CLSBDM] VARCHAR, \n" +
                "  [WZ] VARCHAR, \n" +
                "  [DY] VARCHAR, \n" +
                "  [XDCSSCD] VARCHAR, \n" +
                "  [JYKWZ] VARCHAR, \n" +
                "  [CZ] VARCHAR, \n" +
                "  [YL] VARCHAR, \n" +
                "  [YXSSCD] VARCHAR, \n" +
                "  [FDONGJ] VARCHAR, \n" +
                "  [FDIANJ] VARCHAR, \n" +
                "  [QDJ] VARCHAR, \n" +
                "  [CYB] VARCHAR, \n" +
                "  [DHXQ] VARCHAR, \n" +
                "  [JYLQQ] VARCHAR, \n" +
                "  [KQLQQ] VARCHAR, \n" +
                "  [ZKZLQ] VARCHAR, \n" +
                "  [BXH] VARCHAR, \n" +
                "  [BSQLHQ] VARCHAR, \n" +
                "  [SRQ] VARCHAR, \n" +
                "  [LNQ] VARCHAR, \n" +
                "  [JQQG] VARCHAR, \n" +
                "  [PQQG] VARCHAR, \n" +
                "  [WLZYQ] VARCHAR, \n" +
                "  [LQYG] VARCHAR, \n" +
                "  [QXYG] VARCHAR, \n" +
                "  [ZDYG] VARCHAR, \n" +
                "  [ZLZXYG] VARCHAR, \n" +
                "  [KTYSJ] VARCHAR, \n" +
                "  [ABSKZQ] VARCHAR, \n" +
                "  [ZQDA] VARCHAR, \n" +
                "  [YQDA] VARCHAR, \n" +
                "  [LQFS] VARCHAR, \n" +
                "  [YBB] VARCHAR, \n" +
                "  [ZXP] VARCHAR, \n" +
                "  [GFJ] VARCHAR, \n" +
                "  [YSPBFQ] VARCHAR, \n" +
                "  [DYQ] VARCHAR, \n" +
                "  [ZQDB] VARCHAR, \n" +
                "  [ZQM] VARCHAR, \n" +
                "  [ZHM] VARCHAR, \n" +
                "  [JXH] VARCHAR, \n" +
                "  [STX] VARCHAR, \n" +
                "  [JSWZY] VARCHAR, \n" +
                "  [FJSZY] VARCHAR, \n" +
                "  [HPZY] VARCHAR, \n" +
                "  [YQDB] VARCHAR, \n" +
                "  [YQM] VARCHAR, \n" +
                "  [YHM] VARCHAR, \n" +
                "  [QBZC] VARCHAR, \n" +
                "  [ZBBZC] VARCHAR, \n" +
                "  [DBZC] VARCHAR, \n" +
                "  [ZHCD] VARCHAR, \n" +
                "  [ZYWP] VARCHAR, \n" +
                "  [HBZC] VARCHAR, \n" +
                "  [YBBZC] VARCHAR, \n" +
                "  [DB] VARCHAR, \n" +
                "  [YHCD] VARCHAR, \n" +
                "  [SSCD] VARCHAR);";

        String sqlb3W = "CREATE TABLE IF NOT EXISTS [baseinfo_b3W](\n" +
                "  [Acc_ID] VARCHAR PRIMARY KEY NOT NULL, \n" +
                "  [CLSBDM] VARCHAR, \n" +
                //"  [MYQS] VARCHAR, \n" +
                //"  [QHBW] VARCHAR, \n" +
                "  [LTZ1] VARCHAR, \n" +
                "  [LTZ2] VARCHAR, \n" +
                "  [LTZ3] VARCHAR, \n" +
                "  [LTY1] VARCHAR, \n" +
                "  [LTY2] VARCHAR, \n" +
                "  [LTY3] VARCHAR, \n" +
                "  [LWZ1] VARCHAR, \n" +
                "  [LWZ2] VARCHAR, \n" +
                "  [LWZ3] VARCHAR, \n" +
                "  [LWY1] VARCHAR, \n" +
                "  [LWY2] VARCHAR, \n" +
                "  [LWY3] VARCHAR, \n" +
                "  [CMZ1] VARCHAR, \n" +
                "  [CMY1] VARCHAR, \n" +
                "  [CMY2] VARCHAR, \n" +
                "  [CMY3] VARCHAR, \n" +
                "  [CWBZ1] VARCHAR, \n" +
                "  [CWBZ2] VARCHAR, \n" +
                "  [CWBZ3] VARCHAR, \n" +
                "  [CWBY1] VARCHAR, \n" +
                "  [CWBY2] VARCHAR, \n" +
                "  [CWBY3] VARCHAR, \n" +
                "  [CDZ1] VARCHAR, \n" +
                "  [CDZ2] VARCHAR, \n" +
                "  [CDY1] VARCHAR, \n" +
                "  [CDY2] VARCHAR, \n" +
                "  [HSJZ] VARCHAR, \n" +
                "  [HSJY] VARCHAR, \n" +
                "  [CCZ1] VARCHAR, \n" +
                "  [CCZ2] VARCHAR, \n" +
                "  [CCZ3] VARCHAR, \n" +
                "  [CCZ4] VARCHAR, \n" +
                "  [CCZ5] VARCHAR, \n" +
                "  [CCZ6] VARCHAR, \n" +
                "  [CCY1] VARCHAR, \n" +
                "  [CCY2] VARCHAR, \n" +
                "  [CCY3] VARCHAR, \n" +
                "  [CCY4] VARCHAR, \n" +
                "  [CCY5] VARCHAR, \n" +
                "  [CCY6] VARCHAR, \n" +
                "  [BXGQB] VARCHAR, \n" +
                "  [BXGHB] VARCHAR, \n" +
                "  [FDBLQB] VARCHAR, \n" +
                "  [FDBLHB] VARCHAR, \n" +
                "  [YGQQB] VARCHAR, \n" +
                "  [YGQHB] VARCHAR, \n" +
                "  [DG] VARCHAR, \n" +
                "  [DBKT] VARCHAR, \n" +
                "  [DP] VARCHAR, \n" +
                "  [PQG] VARCHAR, \n" +
                "  [CHZHQ] VARCHAR);\n";
        String sqlb3N = "CREATE TABLE IF NOT EXISTS [baseinfo_b3N](\n" +
                "  [Acc_ID] VARCHAR PRIMARY KEY NOT NULL, \n" +
                "  [CLSBDM] VARCHAR, \n" +
                "  [WZ] VARCHAR, \n" +
                "  [DY] VARCHAR, \n" +
                "  [XDCSSCD] VARCHAR, \n" +
                "  [JYKWZ] VARCHAR, \n" +
                "  [CZ] VARCHAR, \n" +
                "  [YL] VARCHAR, \n" +
                "  [YXSSCD] VARCHAR, \n" +
                "  [FDONGJ] VARCHAR, \n" +
                "  [FDIANJ] VARCHAR, \n" +
                "  [QDJ] VARCHAR, \n" +
                "  [CYB] VARCHAR, \n" +
                "  [HSQ] VARCHAR, \n" +
                "  [DHXQ] VARCHAR, \n" +
                "  [KQLQQ] VARCHAR, \n" +
                "  [JYLQQ] VARCHAR, \n" +
                "  [ZKZLQ] VARCHAR, \n" +
                "  [BXH] VARCHAR, \n" +
                "  [BSQLHQ] VARCHAR, \n" +
                "  [SRQ] VARCHAR, \n" +
                "  [LNQ] VARCHAR, \n" +
                "  [JQQG] VARCHAR, \n" +
                "  [PQQG] VARCHAR, \n" +
                "  [WLZYQ] VARCHAR, \n" +
                "  [LQYG] VARCHAR, \n" +
                "  [QXYG] VARCHAR, \n" +
                "  [ZDYG] VARCHAR, \n" +
                "  [ZLZXYG] VARCHAR, \n" +
                "  [KTYSJ] VARCHAR, \n" +
                "  [ABSKZQ] VARCHAR, \n" +
                "  [KQYSJ] VARCHAR, \n" +
                "  [LQFS] VARCHAR, \n" +
                "  [DYZKG] VARCHAR, \n" +
                "  [JXHA] VARCHAR, \n" +
                "  [YBB] VARCHAR, \n" +
                "  [JXHB] VARCHAR, \n" +
                "  [ZXP] VARCHAR, \n" +
                "  [DHKG] VARCHAR, \n" +
                "  [GFJ] VARCHAR, \n" +
                "  [YSPBFQ] VARCHAR, \n" +
                "  [JTQ] VARCHAR, \n" +
                "  [JSWZY] VARCHAR, \n" +
                "  [FJSZY] VARCHAR, \n" +
                "  [CKZY] VARCHAR, \n" +
                "  [QBDB] VARCHAR, \n" +
                "  [HBDB] VARCHAR, \n" +
                "  [ZQCD] VARCHAR, \n" +
                "  [ZHCD] VARCHAR, \n" +
                "  [YQCD] VARCHAR, \n" +
                "  [YHCD] VARCHAR, \n" +
                "  [Z1CM] VARCHAR, \n" +
                "  [Y1CM] VARCHAR, \n" +
                "  [Y2CM] VARCHAR, \n" +
                "  [Y3CM] VARCHAR, \n" +
                "  [ZYWP] VARCHAR, \n" +
                "  [SSCD] VARCHAR);";

        String sqlb4W = "CREATE TABLE IF NOT EXISTS [baseinfo_b4W](\n" +
                "  [Acc_ID] VARCHAR PRIMARY KEY NOT NULL, \n" +
                "  [CLSBDM] VARCHAR, \n" +
                //"  [MYQS] VARCHAR, \n" +
               // "  [QHBW] VARCHAR, \n" +
                "  [LTZQ] VARCHAR, \n" +
                "  [LTYQ] VARCHAR, \n" +
                "  [LTZH] VARCHAR, \n" +
                "  [LTYH] VARCHAR, \n" +
                "  [LWZQ] VARCHAR, \n" +
                "  [LWYQ] VARCHAR, \n" +
                "  [LWZH] VARCHAR, \n" +
                "  [LWYH] VARCHAR, \n" +
                "  [CMZQ] VARCHAR, \n" +
                "  [CMYQ] VARCHAR, \n" +
                "  [CMZH] VARCHAR, \n" +
                "  [CMYH] VARCHAR, \n" +
                "  [CCZQ] VARCHAR, \n" +
                "  [CCYQ] VARCHAR, \n" +
                "  [CCZH] VARCHAR, \n" +
                "  [CCYH] VARCHAR, \n" +
                "  [YZBZQ] VARCHAR, \n" +
                "  [YZBYQ] VARCHAR, \n" +
                "  [YZBZH] VARCHAR, \n" +
                "  [YZBYH] VARCHAR, \n" +
                "  [CDZQ] VARCHAR, \n" +
                "  [CDYQ] VARCHAR, \n" +
                "  [CDZH] VARCHAR, \n" +
                "  [CDYH] VARCHAR, \n" +
                "  [HSJZ] VARCHAR, \n" +
                "  [HSJY] VARCHAR, \n" +
                "  [BXGQB] VARCHAR, \n" +
                "  [BXGHB] VARCHAR, \n" +
                "  [FDBLQB] VARCHAR, \n" +
                "  [FDBLHB] VARCHAR, \n" +
                "  [YGQQB] VARCHAR, \n" +
                "  [YGQHB] VARCHAR, \n" +
                "  [JCG] VARCHAR, \n" +
                "  [DG] VARCHAR, \n" +
                "  [TC] VARCHAR, \n" +
                "  [HBXG] VARCHAR, \n" +
                "  [DP] VARCHAR, \n" +
                "  [PQG] VARCHAR, \n" +
                "  [CHZHQ] VARCHAR, \n" +
                "  [WJCDXL] VARCHAR);\n";
        String sqlb4N = "CREATE TABLE IF NOT EXISTS [baseinfo_b4N](\n" +
                "  [Acc_ID] VARCHAR PRIMARY KEY NOT NULL, \n" +
                "  [CLSBDM] VARCHAR, \n" +
                "  [WZA] VARCHAR, \n" +
                "  [DY] VARCHAR, \n" +
                "  [DYXDCSSCD] VARCHAR, \n" +
                "  [DLDCCWZ] VARCHAR, \n" +
                "  [KCCDKWZ] VARCHAR, \n" +
                "  [MCCDKWZ] VARCHAR, \n" +
                "  [CDQWZ] VARCHAR, \n" +
                "  [WKCZ] VARCHAR, \n" +
                "  [EDDY] VARCHAR, \n" +
                "  [EDRL] VARCHAR, \n" +
                "  [CZFS] VARCHAR, \n" +
                "  [HDZT] VARCHAR, \n" +
                "  [SBSSCD] VARCHAR, \n" +
                "  [XBSSCD] VARCHAR, \n" +
                "  [QBSSCD] VARCHAR, \n" +
                "  [HBSSCD] VARCHAR, \n" +
                "  [ZCSSCD] VARCHAR, \n" +
                "  [YCSSCD] VARCHAR, \n" +
                "  [DCDTLX] VARCHAR, \n" +
                "  [DCDTXH] VARCHAR, \n" +
                "  [DCDTEDRL] VARCHAR, \n" +
                "  [DCDTEDDY] VARCHAR, \n" +
                "  [WZB] VARCHAR, \n" +
                "  [DCGLXTSSCD] VARCHAR, \n" +
                "  [DDJ] VARCHAR, \n" +
                "  [DJKZQ] VARCHAR, \n" +
                "  [JSX] VARCHAR, \n" +
                "  [DYZHQ] VARCHAR, \n" +
                "  [GYPDH] VARCHAR, \n" +
                "  [BXH] VARCHAR, \n" +
                "  [JQQG] VARCHAR, \n" +
                "  [PQQG] VARCHAR, \n" +
                "  [BSQLHQ] VARCHAR, \n" +
                "  [ZKZLQZKB] VARCHAR, \n" +
                "  [SRQ] VARCHAR, \n" +
                "  [LQFS] VARCHAR, \n" +
                "  [ABSKZQ] VARCHAR, \n" +
                "  [ZQD] VARCHAR, \n" +
                "  [YQD] VARCHAR, \n" +
                "  [FDONGJ] VARCHAR, \n" +
                "  [QDJ] VARCHAR, \n" +
                "  [FDIANJ] VARCHAR, \n" +
                "  [YBB] VARCHAR, \n" +
                "  [ZXP] VARCHAR, \n" +
                "  [ZYJXH] VARCHAR, \n" +
                "  [DHKG] VARCHAR, \n" +
                "  [YSPBFQ] VARCHAR, \n" +
                "  [GFJ] VARCHAR, \n" +
                "  [DYQ] VARCHAR, \n" +
                "  [STX] VARCHAR, \n" +
                "  [ZYFSX] VARCHAR, \n" +
                "  [JSWZY] VARCHAR, \n" +
                "  [FJSZY] VARCHAR, \n" +
                "  [HPZY] VARCHAR, \n" +
                "  [ZQM] VARCHAR, \n" +
                "  [YQM] VARCHAR, \n" +
                "  [ZHM] VARCHAR, \n" +
                "  [YHM] VARCHAR, \n" +
                "  [ZHCD] VARCHAR, \n" +
                "  [YHCD] VARCHAR, \n" +
                "  [ZYWP] VARCHAR, \n" +
                "  [SSCD] VARCHAR);";

        String sqlb5W = "CREATE TABLE IF NOT EXISTS [baseinfo_b5W](\n" +
                "  [Acc_ID] VARCHAR PRIMARY KEY NOT NULL, \n" +
                "  [CLSBDM] VARCHAR, \n" +
                //"  [MYQS] VARCHAR, \n" +
               // "  [QHBW] VARCHAR, \n" +
                "  [LTZ1] VARCHAR, \n" +
                "  [LTZ2] VARCHAR, \n" +
                "  [LTZ3] VARCHAR, \n" +
                "  [LTY1] VARCHAR, \n" +
                "  [LTY2] VARCHAR, \n" +
                "  [LTY3] VARCHAR, \n" +
                "  [LWZ1] VARCHAR, \n" +
                "  [LWZ2] VARCHAR, \n" +
                "  [LWZ3] VARCHAR, \n" +
                "  [LWY1] VARCHAR, \n" +
                "  [LWY2] VARCHAR, \n" +
                "  [LWY3] VARCHAR, \n" +
                "  [CMZ1] VARCHAR, \n" +
                "  [CMY1] VARCHAR, \n" +
                "  [CMY2] VARCHAR, \n" +
                "  [CMY3] VARCHAR, \n" +
                "  [CWBZ1] VARCHAR, \n" +
                "  [CWBZ2] VARCHAR, \n" +
                "  [CWBZ3] VARCHAR, \n" +
                "  [CWBY1] VARCHAR, \n" +
                "  [CWBY2] VARCHAR, \n" +
                "  [CWBY3] VARCHAR, \n" +
                "  [CDZ1] VARCHAR, \n" +
                "  [CDZ2] VARCHAR, \n" +
                "  [CDY1] VARCHAR, \n" +
                "  [CDY2] VARCHAR, \n" +
                "  [HSJZ] VARCHAR, \n" +
                "  [HSJY] VARCHAR, \n" +
                "  [CCZ1] VARCHAR, \n" +
                "  [CCZ2] VARCHAR, \n" +
                "  [CCZ3] VARCHAR, \n" +
                "  [CCZ4] VARCHAR, \n" +
                "  [CCZ5] VARCHAR, \n" +
                "  [CCZ6] VARCHAR, \n" +
                "  [CCY1] VARCHAR, \n" +
                "  [CCY2] VARCHAR, \n" +
                "  [CCY3] VARCHAR, \n" +
                "  [CCY4] VARCHAR, \n" +
                "  [CCY5] VARCHAR, \n" +
                "  [CCY6] VARCHAR, \n" +
                "  [BXGQB] VARCHAR, \n" +
                "  [BXGHB] VARCHAR, \n" +
                "  [FDBLQB] VARCHAR, \n" +
                "  [FDBLHB] VARCHAR, \n" +
                "  [YGQQB] VARCHAR, \n" +
                "  [YGQHB] VARCHAR, \n" +
                "  [DG] VARCHAR, \n" +
                "  [DBKT] VARCHAR, \n" +
                "  [DP] VARCHAR, \n" +
                "  [PQG] VARCHAR, \n" +
                "  [CHZHQ] VARCHAR);\n";
        String sqlb5N = "CREATE TABLE IF NOT EXISTS [baseinfo_b5N](\n" +
                "  [Acc_ID] VARCHAR PRIMARY KEY NOT NULL, \n" +
                "  [CLSBDM] VARCHAR, \n" +
                "  [WZA] VARCHAR, \n" +
                "  [DY] VARCHAR, \n" +
                "  [DYXDCSSCD] VARCHAR, \n" +
                "  [DLDCCWZ] VARCHAR, \n" +
                "  [CDKWZ] VARCHAR, \n" +
                "  [CDQWZ] VARCHAR, \n" +
                "  [WKCZ] VARCHAR, \n" +
                "  [EDDY] VARCHAR, \n" +
                "  [EDRL] VARCHAR, \n" +
                "  [CZFS] VARCHAR, \n" +
                "  [HDZT] VARCHAR, \n" +
                "  [DLDCCSSCD] VARCHAR, \n" +
                "  [DCDTLX] VARCHAR, \n" +
                "  [DCDTXH] VARCHAR, \n" +
                "  [DCDTEDRL] VARCHAR, \n" +
                "  [DCDTEDDY] VARCHAR, \n" +
                "  [WZB] VARCHAR, \n" +
                "  [DCGLXTSSCD] VARCHAR, \n" +
                "  [DDJ] VARCHAR, \n" +
                "  [DJKZQ] VARCHAR, \n" +
                "  [JSX] VARCHAR, \n" +
                "  [DYZHQ] VARCHAR, \n" +
                "  [GYPDH] VARCHAR, \n" +
                "  [BXH] VARCHAR, \n" +
                "  [JQQG] VARCHAR, \n" +
                "  [PQQG] VARCHAR, \n" +
                "  [BSQLHQ] VARCHAR, \n" +
                "  [ZKZLQZKB] VARCHAR, \n" +
                "  [SRQ] VARCHAR, \n" +
                "  [LQFS] VARCHAR, \n" +
                "  [ABSKZQ] VARCHAR, \n" +
                "  [ZQD] VARCHAR, \n" +
                "  [YQD] VARCHAR, \n" +
                "  [FDONGJ] VARCHAR, \n" +
                "  [QDJ] VARCHAR, \n" +
                "  [FDIANJ] VARCHAR, \n" +
                "  [YBB] VARCHAR, \n" +
                "  [JXH] VARCHAR, \n" +
                "  [ZXP] VARCHAR, \n" +
                "  [DHKG] VARCHAR, \n" +
                "  [GFJ] VARCHAR, \n" +
                "  [YSPBFQ] VARCHAR, \n" +
                "  [JTQ] VARCHAR, \n" +
                "  [JSWZY] VARCHAR, \n" +
                "  [FJSZY] VARCHAR, \n" +
                "  [CKZY] VARCHAR, \n" +
                "  [QBDB] VARCHAR, \n" +
                "  [HBDB] VARCHAR, \n" +
                "  [ZQCD] VARCHAR, \n" +
                "  [ZHCD] VARCHAR, \n" +
                "  [YQCD] VARCHAR, \n" +
                "  [YHCD] VARCHAR, \n" +
                "  [Z1CM] VARCHAR, \n" +
                "  [Y1CM] VARCHAR, \n" +
                "  [Y2CM] VARCHAR, \n" +
                "  [Y3CM] VARCHAR, \n" +
                "  [ZYWP] VARCHAR, \n" +
                "  [SSCD] VARCHAR);\n";

        String sqlbb = "CREATE TABLE IF NOT EXISTS [baseinfo_bb](\n" +
                "  [Acc_ID] VARCHAR PRIMARY KEY NOT NULL, \n" +
                "  [CLSBDM] VARCHAR, \n" +
                "  [QFZYWT1] VARCHAR, \n" +
                "  [QFSSCD1] VARCHAR, \n" +
                "  [QFZYWT2] VARCHAR, \n" +
                "  [QFSSCD2] VARCHAR, \n" +
                "  [HFZYWT1] VARCHAR, \n" +
                "  [HFSSCD1] VARCHAR, \n" +
                "  [HFZYWT2] VARCHAR, \n" +
                "  [HFSSCD2] VARCHAR, \n" +
                "  [ZCZYWT1] VARCHAR, \n" +
                "  [ZCSSCD1] VARCHAR, \n" +
                "  [ZCZYWT2] VARCHAR, \n" +
                "  [ZCSSCD2] VARCHAR, \n" +
                "  [YCZYWT1] VARCHAR, \n" +
                "  [YCSSCD1] VARCHAR, \n" +
                "  [YCZYWT2] VARCHAR, \n" +
                "  [YCSSCD2] VARCHAR, \n" +
                "  [SFZYWT1] VARCHAR, \n" +
                "  [SFSSCD1] VARCHAR, \n" +
                "  [SFZYWT2] VARCHAR, \n" +
                "  [SFSSCD2] VARCHAR, \n" +
                "  [DMZYWT1] VARCHAR, \n" +
                "  [DMSSCD1] VARCHAR, \n" +
                "  [DMZYWT2] VARCHAR, \n" +
                "  [DMSSCD2] VARCHAR);\n";
        String sqlbbb = "CREATE TABLE IF NOT EXISTS [baseinfo_bbb](\n" +
                "  [Acc_ID] VARCHAR PRIMARY KEY NOT NULL UNIQUE, \n" +
                "  [CLSBDM] VARCHAR, \n" +
                "  [ZYSSBJMC1] VARCHAR, \n" +
                "  [ZYSSBJSSCD1] VARCHAR, \n" +
                "  [ZSDQXL1] VARCHAR, \n" +
                "  [FJDQXL1] VARCHAR, \n" +
                "  [ZYSSBJMC2] VARCHAR, \n" +
                "  [ZYSSBJSSCD2] VARCHAR, \n" +
                "  [ZSDQXL2] VARCHAR, \n" +
                "  [FJDQXL2] VARCHAR, \n" +
                "  [ZYKRWMC1] VARCHAR, \n" +
                "  [ZYKRWSSCD1] VARCHAR, \n" +
                "  [ZYKRWMC2] VARCHAR, \n" +
                "  [ZYKRWSSCD2] VARCHAR);";

        String sqlc = "CREATE TABLE IF NOT EXISTS [baseinfo_c](\n" +
                "  [Acc_ID] VARCHAR PRIMARY KEY NOT NULL UNIQUE, \n" +
                "  [RYLX] VARCHAR, \n" +
                "  [XB] VARCHAR, \n" +
                "  [NL] INTEGER, \n" +
                "  [DCDD] VARCHAR, \n" +
                "  [DCFS] VARCHAR, \n" +
                "  [SFXY] VARCHAR, \n" +
                "  [SFYJ] VARCHAR, \n" +
                "  [SSQK] VARCHAR, \n" +
                "  [SSBW] VARCHAR, \n" +
                "  [CLXN] VARCHAR, \n" +
                "  [CQCSA] VARCHAR, \n" +
                "  [FXSRYWZ] VARCHAR, \n" +
                "  [XJJL] INTEGER, \n" +
                "  [BMQHZYXX] VARCHAR, \n" +
                "  [CQCSB] VARCHAR, \n" +
                "  [WZA] VARCHAR, \n" +
                "  [GDA] VARCHAR, \n" +
                "  [ZTGDA] INTEGER, \n" +
                "  [WZB] VARCHAR, \n" +
                "  [YS] VARCHAR, \n" +
                "  [GDB] VARCHAR, \n" +
                "  [ZTGDB] INTEGER);";

        db.execSQL(sqlaTPP);
        db.execSQL(sqlaEnv);
        db.execSQL(sqlb);
        db.execSQL(sqlb1W);
        db.execSQL(sqlb2W);
        db.execSQL(sqlb3W);
        db.execSQL(sqlb4W);
        db.execSQL(sqlb5W);
        db.execSQL(sqlb1N);
        db.execSQL(sqlb2N);
        db.execSQL(sqlb3N);
        db.execSQL(sqlb4N);
        db.execSQL(sqlb5N);
        db.execSQL(sqlbqh);
        db.execSQL(sqlbb);
        db.execSQL(sqlbbb);
        db.execSQL(sqlc);

        //db.close();
    }
}


