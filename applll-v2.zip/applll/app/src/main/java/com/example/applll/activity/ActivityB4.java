package com.example.applll.activity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.applll.R;
import com.example.applll.Utility;
import com.example.applll.service.DbManger;
import com.example.applll.service.MySQLiteHelper;

public class ActivityB4 extends AppCompatActivity {
    
    private MySQLiteHelper helper= DbManger.getIntance(this);

    private String[] args1={"acc_ID","CLSBDM","LTZQ","LTYQ","LTZH","LTYH","LWZQ","LWYQ","LWZH","LWYH","CMZQ",
            "CMYQ","CMZH","CMYH","CCZQ","CCYQ","CCZH","CCYH","YZBZQ","YZBYQ","YZBZH","YZBYH","CDZQ","CDYQ",
            "CDZH","CDYH","HSJZ","HSJY","BXGQB","BXGHB","FDBLQB","FDBLHB","YGQQB","YGQHB","JCG","DG","TC","HBXG",
            "DP","PQG","CHZHQ","WJCDXL"};
    private String[] args3={"acc_ID","CLSBDM","WZA","DY","DYXDCSSCD","DLDCCWZ","KCCDKWZ","MCCDKWZ","CDQWZ","WKCZ",
            "EDDY","EDRL","CZFS","HDZT","SBSSCD","XBSSCD","QBSSCD","HBSSCD","ZCSSCD","YCSSCD","DCDTLX","DCDTXH",
            "DCDTEDRL","DCDTEDDY","WZB","DCGLXTSSCD","DDJ","DJKZQ","JSX","DYZHQ","GYPDH","BXH","JQQG","PQQG",
            "BSQLHQ","ZKZLQZKB","SRQ","LQFS","ABSKZQ","ZQD","YQD","FDONGJ","QDJ","FDIANJ","YBB","ZXP","ZYJXH",
            "DHKG","YSPBFQ","GFJ","DYQ","STX","ZYFSX","JSWZY","FJSZY","HPZY","ZQM","YQM","ZHM","YHM","ZHCD",
            "YHCD","ZYWP","SSCD"};
    private String[] args10={"acc_ID","CLSBDM","MYQS","QHBW"};

    private Spinner myqs,ltzq,ltyq,ltzh,ltyh,lwzq,lwyq,lwzh,lwyh,cmzq,cmyq,cmzh,cmyh,cczq,ccyq,cczh,
            ccyh,yzbzq,yzbyq,yzbzh,yzbyh,cdzq,cdyq,cdzh,cdyh,hsjz,hsjy,bxgqb,bxghb,fdblqb,fdblhb,
            ygqqb,ygqhb,jcg,dg,tc,hbxg,dp,pqg,chzhq,wjcdxl,wzA,dy,dyxdcsscd,dldccwz,kccdkwz,mccdkwz,
            cdqwz,wkcz,czfs,sbsscd,xbsscd,qbsscd,hbsscd,zcsscd,ycsscd,wzB,dcglxtsscd,ddj,djkzq,jsx,dyzhq,
            gypdh,bxh,jqqg,pqqg,bsqlhq,zkzlqzkb,srq,lqfs,ABSkzq,zqd,yqd,fdongj,qdj,fdianj,ybb,zxp,zyjxh,
            dhkg,yspbfq,gfj,dyq,stx,zyfsx,jswzy,fjszy,hpzy,zqm,yqm,zhm,yhm,zhcd,yhcd,sscd;
    
    private TextView myqsshow,ltzqshow,ltyqshow,ltzhshow,ltyhshow,lwzqshow,lwyqshow,lwzhshow,lwyhshow,
            cmzqshow,cmyqshow,cmzhshow,cmyhshow,cczqshow,ccyqshow,cczhshow,ccyhshow,yzbzqshow,yzbyqshow,
            yzbzhshow,yzbyhshow,cdzqshow,cdyqshow,cdzhshow,cdyhshow,hsjzshow,hsjyshow,bxgqbshow,bxghbshow,
            fdblqbshow,fdblhbshow,ygqqbshow,ygqhbshow,jcgshow,dgshow,tcshow,hbxgshow,dpshow,pqgshow,
            chzhqshow,wjcdxlshow,wzAshow,dyshow,dyxdcsscdshow,dldccwzshow,kccdkwzshow,mccdkwzshow,cdqwzshow,
            wkczshow,czfsshow,sbsscdshow,xbsscdshow,qbsscdshow,hbsscdshow,zcsscdshow,ycsscdshow,wzBshow,
            dcglxtsscdshow,ddjshow,djkzqshow,jsxshow,dyzhqshow,gypdhshow,bxhshow,jqqgshow,pqqgshow,bsqlhqshow,
            zkzlqzkbshow,srqshow,lqfsshow,ABSkzqshow,zqdshow,yqdshow,fdongjshow,qdjshow,fdianjshow,ybbshow,
            zxpshow,zyjxhshow,dhkgshow,yspbfqshow,gfjshow,dyqshow,stxshow,zyfsxshow,jswzyshow,fjszyshow,
            hpzyshow,zqmshow,yqmshow,zhmshow,yhmshow,zhcdshow,yhcdshow,sscdshow;
    
    private EditText qhbw,eddy,edrl,hdzt,dcdtlx,dcdtxh,dcdtedrl,dcdteddy,zywp;
    String acc_ID_time,clsbdm,wjm ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_b4);
        Intent intent0=getIntent();
        acc_ID_time = intent0.getStringExtra("acc_ID_time");
        clsbdm = intent0.getStringExtra("clsbdm");
        wjm=intent0.getStringExtra("wjm");
        myqs       =findViewById(R.id.b4_sp_myqs      );
        ltzq       =findViewById(R.id.b4_sp_ltzq      );
        ltyq       =findViewById(R.id.b4_sp_ltyq      );
        ltzh       =findViewById(R.id.b4_sp_ltzh      );
        ltyh       =findViewById(R.id.b4_sp_ltyh      );
        lwzq       =findViewById(R.id.b4_sp_lwzq      );
        lwyq       =findViewById(R.id.b4_sp_lwyq      );
        lwzh       =findViewById(R.id.b4_sp_lwzh      );
        lwyh       =findViewById(R.id.b4_sp_lwyh      );
        cmzq       =findViewById(R.id.b4_sp_cmzq      );
        cmyq       =findViewById(R.id.b4_sp_cmyq      );
        cmzh       =findViewById(R.id.b4_sp_cmzh      );
        cmyh       =findViewById(R.id.b4_sp_cmyh      );
        cczq       =findViewById(R.id.b4_sp_cczq      );
        ccyq       =findViewById(R.id.b4_sp_ccyq      );
        cczh       =findViewById(R.id.b4_sp_cczh      );
        ccyh       =findViewById(R.id.b4_sp_ccyh      );
        yzbzq      =findViewById(R.id.b4_sp_yzbzq     );
        yzbyq      =findViewById(R.id.b4_sp_yzbyq     );
        yzbzh      =findViewById(R.id.b4_sp_yzbzh     );
        yzbyh      =findViewById(R.id.b4_sp_yzbyh     );
        cdzq       =findViewById(R.id.b4_sp_cdzq      );
        cdyq       =findViewById(R.id.b4_sp_cdyq      );
        cdzh       =findViewById(R.id.b4_sp_cdzh      );
        cdyh       =findViewById(R.id.b4_sp_cdyh      );
        hsjz       =findViewById(R.id.b4_sp_hsjz      );
        hsjy       =findViewById(R.id.b4_sp_hsjy      );
        bxgqb      =findViewById(R.id.b4_sp_bxgqb     );
        bxghb      =findViewById(R.id.b4_sp_bxghb     );
        fdblqb     =findViewById(R.id.b4_sp_fdblqb    );
        fdblhb     =findViewById(R.id.b4_sp_fdblhb    );
        ygqqb      =findViewById(R.id.b4_sp_ygqqb     );
        ygqhb      =findViewById(R.id.b4_sp_ygqhb     );
        jcg        =findViewById(R.id.b4_sp_jcg       );
        dg         =findViewById(R.id.b4_sp_dg        );
        tc         =findViewById(R.id.b4_sp_tc        );
        hbxg       =findViewById(R.id.b4_sp_hbxg      );
        dp         =findViewById(R.id.b4_sp_dp        );
        pqg        =findViewById(R.id.b4_sp_pqg       );
        chzhq      =findViewById(R.id.b4_sp_chzhq     );
        wjcdxl     =findViewById(R.id.b4_sp_wjcdxl    );
        wzA        =findViewById(R.id.b4_sp_wzA       );
        dy         =findViewById(R.id.b4_sp_dy        );
        dyxdcsscd  =findViewById(R.id.b4_sp_dyxdcsscd );
        dldccwz    =findViewById(R.id.b4_sp_dldccwz   );
        kccdkwz    =findViewById(R.id.b4_sp_kccdkwz   );
        mccdkwz    =findViewById(R.id.b4_sp_mccdkwz   );
        cdqwz      =findViewById(R.id.b4_sp_cdqwz     );
        wkcz       =findViewById(R.id.b4_sp_wkcz      );
        czfs       =findViewById(R.id.b4_sp_czfs      );
        sbsscd     =findViewById(R.id.b4_sp_sbsscd    );
        xbsscd     =findViewById(R.id.b4_sp_xbsscd    );
        qbsscd     =findViewById(R.id.b4_sp_qbsscd    );
        hbsscd     =findViewById(R.id.b4_sp_hbsscd    );
        zcsscd     =findViewById(R.id.b4_sp_zcsscd    );
        ycsscd     =findViewById(R.id.b4_sp_ycsscd    );
        wzB        =findViewById(R.id.b4_sp_wzB       );
        dcglxtsscd =findViewById(R.id.b4_sp_dcglxtsscd);
        ddj        =findViewById(R.id.b4_sp_ddj       );
        djkzq      =findViewById(R.id.b4_sp_djkzq     );
        jsx        =findViewById(R.id.b4_sp_jsx       );
        dyzhq      =findViewById(R.id.b4_sp_dyzhq     );
        gypdh      =findViewById(R.id.b4_sp_gypdh     );
        bxh        =findViewById(R.id.b4_sp_bxh       );
        jqqg       =findViewById(R.id.b4_sp_jqqg      );
        pqqg       =findViewById(R.id.b4_sp_pqqg      );
        bsqlhq     =findViewById(R.id.b4_sp_bsqlhq    );
        zkzlqzkb   =findViewById(R.id.b4_sp_zkzlqzkb  );
        srq        =findViewById(R.id.b4_sp_srq       );
        lqfs       =findViewById(R.id.b4_sp_lqfs      );
        ABSkzq     =findViewById(R.id.b4_sp_ABSkzq    );
        zqd        =findViewById(R.id.b4_sp_zqd       );
        yqd        =findViewById(R.id.b4_sp_yqd       );
        fdongj     =findViewById(R.id.b4_sp_fdongj    );
        qdj        =findViewById(R.id.b4_sp_qdj       );
        fdianj     =findViewById(R.id.b4_sp_fdianj    );
        ybb        =findViewById(R.id.b4_sp_ybb       );
        zxp        =findViewById(R.id.b4_sp_zxp       );
        zyjxh      =findViewById(R.id.b4_sp_zyjxh     );
        dhkg       =findViewById(R.id.b4_sp_dhkg      );
        yspbfq     =findViewById(R.id.b4_sp_yspbfq    );
        gfj        =findViewById(R.id.b4_sp_gfj       );
        dyq        =findViewById(R.id.b4_sp_dyq       );
        stx        =findViewById(R.id.b4_sp_stx       );
        zyfsx      =findViewById(R.id.b4_sp_zyfsx     );
        jswzy      =findViewById(R.id.b4_sp_jswzy     );
        fjszy      =findViewById(R.id.b4_sp_fjszy     );
        hpzy       =findViewById(R.id.b4_sp_hpzy      );
        zqm        =findViewById(R.id.b4_sp_zqm       );
        yqm        =findViewById(R.id.b4_sp_yqm       );
        zhm        =findViewById(R.id.b4_sp_zhm       );
        yhm        =findViewById(R.id.b4_sp_yhm       );
        zhcd       =findViewById(R.id.b4_sp_zhcd      );
        yhcd       =findViewById(R.id.b4_sp_yhcd      );
        sscd       =findViewById(R.id.b4_sp_sscd      );
        
        myqsshow      =findViewById(R.id.b4_tv_show_myqs      );
        ltzqshow      =findViewById(R.id.b4_tv_show_ltzq      );
        ltyqshow      =findViewById(R.id.b4_tv_show_ltyq      );
        ltzhshow      =findViewById(R.id.b4_tv_show_ltzh      );
        ltyhshow      =findViewById(R.id.b4_tv_show_ltyh      );
        lwzqshow      =findViewById(R.id.b4_tv_show_lwzq      );
        lwyqshow      =findViewById(R.id.b4_tv_show_lwyq      );
        lwzhshow      =findViewById(R.id.b4_tv_show_lwzh      );
        lwyhshow      =findViewById(R.id.b4_tv_show_lwyh      );
        cmzqshow      =findViewById(R.id.b4_tv_show_cmzq      );
        cmyqshow      =findViewById(R.id.b4_tv_show_cmyq      );
        cmzhshow      =findViewById(R.id.b4_tv_show_cmzh      );
        cmyhshow      =findViewById(R.id.b4_tv_show_cmyh      );
        cczqshow      =findViewById(R.id.b4_tv_show_cczq      );
        ccyqshow      =findViewById(R.id.b4_tv_show_ccyq      );
        cczhshow      =findViewById(R.id.b4_tv_show_cczh      );
        ccyhshow      =findViewById(R.id.b4_tv_show_ccyh      );
        yzbzqshow     =findViewById(R.id.b4_tv_show_yzbzq     );
        yzbyqshow     =findViewById(R.id.b4_tv_show_yzbyq     );
        yzbzhshow     =findViewById(R.id.b4_tv_show_yzbzh     );
        yzbyhshow     =findViewById(R.id.b4_tv_show_yzbyh     );
        cdzqshow      =findViewById(R.id.b4_tv_show_cdzq      );
        cdyqshow      =findViewById(R.id.b4_tv_show_cdyq      );
        cdzhshow      =findViewById(R.id.b4_tv_show_cdzh      );
        cdyhshow      =findViewById(R.id.b4_tv_show_cdyh      );
        hsjzshow      =findViewById(R.id.b4_tv_show_hsjz      );
        hsjyshow      =findViewById(R.id.b4_tv_show_hsjy      );
        bxgqbshow     =findViewById(R.id.b4_tv_show_bxgqb     );
        bxghbshow     =findViewById(R.id.b4_tv_show_bxghb     );
        fdblqbshow    =findViewById(R.id.b4_tv_show_fdblqb    );
        fdblhbshow    =findViewById(R.id.b4_tv_show_fdblhb    );
        ygqqbshow     =findViewById(R.id.b4_tv_show_ygqqb     );
        ygqhbshow     =findViewById(R.id.b4_tv_show_ygqhb     );
        jcgshow       =findViewById(R.id.b4_tv_show_jcg       );
        dgshow        =findViewById(R.id.b4_tv_show_dg        );
        tcshow        =findViewById(R.id.b4_tv_show_tc        );
        hbxgshow      =findViewById(R.id.b4_tv_show_hbxg      );
        dpshow        =findViewById(R.id.b4_tv_show_dp        );
        pqgshow       =findViewById(R.id.b4_tv_show_pqg       );
        chzhqshow     =findViewById(R.id.b4_tv_show_chzhq     );
        wjcdxlshow    =findViewById(R.id.b4_tv_show_wjcdxl    );
        wzAshow       =findViewById(R.id.b4_tv_show_wzA       );
        dyshow        =findViewById(R.id.b4_tv_show_dy        );
        dyxdcsscdshow =findViewById(R.id.b4_tv_show_dyxdcsscd );
        dldccwzshow   =findViewById(R.id.b4_tv_show_dldccwz   );
        kccdkwzshow   =findViewById(R.id.b4_tv_show_kccdkwz   );
        mccdkwzshow   =findViewById(R.id.b4_tv_show_mccdkwz   );
        cdqwzshow     =findViewById(R.id.b4_tv_show_cdqwz     );
        wkczshow      =findViewById(R.id.b4_tv_show_wkcz      );
        czfsshow      =findViewById(R.id.b4_tv_show_czfs      );
        sbsscdshow    =findViewById(R.id.b4_tv_show_sbsscd    );
        xbsscdshow    =findViewById(R.id.b4_tv_show_xbsscd    );
        qbsscdshow    =findViewById(R.id.b4_tv_show_qbsscd    );
        hbsscdshow    =findViewById(R.id.b4_tv_show_hbsscd    );
        zcsscdshow    =findViewById(R.id.b4_tv_show_zcsscd    );
        ycsscdshow    =findViewById(R.id.b4_tv_show_ycsscd    );
        wzBshow       =findViewById(R.id.b4_tv_show_wzB       );
        dcglxtsscdshow=findViewById(R.id.b4_tv_show_dcglxtsscd);
        ddjshow       =findViewById(R.id.b4_tv_show_ddj       );
        djkzqshow     =findViewById(R.id.b4_tv_show_djkzq     );
        jsxshow       =findViewById(R.id.b4_tv_show_jsx       );
        dyzhqshow     =findViewById(R.id.b4_tv_show_dyzhq     );
        gypdhshow     =findViewById(R.id.b4_tv_show_gypdh     );
        bxhshow       =findViewById(R.id.b4_tv_show_bxh       );
        jqqgshow      =findViewById(R.id.b4_tv_show_jqqg      );
        pqqgshow      =findViewById(R.id.b4_tv_show_pqqg      );
        bsqlhqshow    =findViewById(R.id.b4_tv_show_bsqlhq    );
        zkzlqzkbshow  =findViewById(R.id.b4_tv_show_zkzlqzkb  );
        srqshow       =findViewById(R.id.b4_tv_show_srq       );
        lqfsshow      =findViewById(R.id.b4_tv_show_lqfs      );
        ABSkzqshow    =findViewById(R.id.b4_tv_show_ABSkzq    );
        zqdshow       =findViewById(R.id.b4_tv_show_zqd       );
        yqdshow       =findViewById(R.id.b4_tv_show_yqd       );
        fdongjshow    =findViewById(R.id.b4_tv_show_fdongj    );
        qdjshow       =findViewById(R.id.b4_tv_show_qdj       );
        fdianjshow    =findViewById(R.id.b4_tv_show_fdianj    );
        ybbshow       =findViewById(R.id.b4_tv_show_ybb       );
        zxpshow       =findViewById(R.id.b4_tv_show_zxp       );
        zyjxhshow     =findViewById(R.id.b4_tv_show_zyjxh     );
        dhkgshow      =findViewById(R.id.b4_tv_show_dhkg      );
        yspbfqshow    =findViewById(R.id.b4_tv_show_yspbfq    );
        gfjshow       =findViewById(R.id.b4_tv_show_gfj       );
        dyqshow       =findViewById(R.id.b4_tv_show_dyq       );
        stxshow       =findViewById(R.id.b4_tv_show_stx       );
        zyfsxshow     =findViewById(R.id.b4_tv_show_zyfsx     );
        jswzyshow     =findViewById(R.id.b4_tv_show_jswzy     );
        fjszyshow     =findViewById(R.id.b4_tv_show_fjszy     );
        hpzyshow      =findViewById(R.id.b4_tv_show_hpzy      );
        zqmshow       =findViewById(R.id.b4_tv_show_zqm       );
        yqmshow       =findViewById(R.id.b4_tv_show_yqm       );
        zhmshow       =findViewById(R.id.b4_tv_show_zhm       );
        yhmshow       =findViewById(R.id.b4_tv_show_yhm       );
        zhcdshow      =findViewById(R.id.b4_tv_show_zhcd      );
        yhcdshow      =findViewById(R.id.b4_tv_show_yhcd      );
        sscdshow      =findViewById(R.id.b4_tv_show_sscd      );
        
        qhbw = findViewById(R.id.b4_et_qhbw);
        eddy = findViewById(R.id.b4_et_eddy);
        edrl = findViewById(R.id.b4_et_edrl);
        hdzt = findViewById(R.id.b4_et_hdzt);
        dcdtlx = findViewById(R.id.b4_et_dcdtlx);
        dcdtxh = findViewById(R.id.b4_et_dcdtxh);
        dcdtedrl = findViewById(R.id.b4_et_dcdtedrl);
        dcdteddy = findViewById(R.id.b4_et_dcdteddy);
        zywp = findViewById(R.id.b4_et_zywp);
        
        Utility.ifOrnot(this,myqs      ,myqsshow      );
        Utility.ifOrnot(this,ltzq      ,ltzqshow      );
        Utility.ifOrnot(this,ltyq      ,ltyqshow      );
        Utility.ifOrnot(this,ltzh      ,ltzhshow      );
        Utility.ifOrnot(this,ltyh      ,ltyhshow      );
        Utility.ifOrnot(this,lwzq      ,lwzqshow      );
        Utility.ifOrnot(this,lwyq      ,lwyqshow      );
        Utility.ifOrnot(this,lwzh      ,lwzhshow      );
        Utility.ifOrnot(this,lwyh      ,lwyhshow      );
        Utility.ifOrnot(this,cmzq      ,cmzqshow      );
        Utility.ifOrnot(this,cmyq      ,cmyqshow      );
        Utility.ifOrnot(this,cmzh      ,cmzhshow      );
        Utility.ifOrnot(this,cmyh      ,cmyhshow      );
        Utility.ifOrnot(this,cczq      ,cczqshow      );
        Utility.ifOrnot(this,ccyq      ,ccyqshow      );
        Utility.ifOrnot(this,cczh      ,cczhshow      );
        Utility.ifOrnot(this,ccyh      ,ccyhshow      );
        Utility.ifOrnot(this,yzbzq     ,yzbzqshow     );
        Utility.ifOrnot(this,yzbyq     ,yzbyqshow     );
        Utility.ifOrnot(this,yzbzh     ,yzbzhshow     );
        Utility.ifOrnot(this,yzbyh     ,yzbyhshow     );
        Utility.ifOrnot(this,cdzq      ,cdzqshow      );
        Utility.ifOrnot(this,cdyq      ,cdyqshow      );
        Utility.ifOrnot(this,cdzh      ,cdzhshow      );
        Utility.ifOrnot(this,cdyh      ,cdyhshow      );
        Utility.ifOrnot(this,hsjz      ,hsjzshow      );
        Utility.ifOrnot(this,hsjy      ,hsjyshow      );
        Utility.ifOrnot(this,bxgqb     ,bxgqbshow     );
        Utility.ifOrnot(this,bxghb     ,bxghbshow     );
        Utility.ifOrnot(this,fdblqb    ,fdblqbshow    );
        Utility.ifOrnot(this,fdblhb    ,fdblhbshow    );
        Utility.ifOrnot(this,ygqqb     ,ygqqbshow     );
        Utility.ifOrnot(this,ygqhb     ,ygqhbshow     );
        Utility.ifOrnot(this,jcg       ,jcgshow       );
        Utility.ifOrnot(this,dg        ,dgshow        );
        Utility.ifOrnot(this,tc        ,tcshow        );
        Utility.ifOrnot(this,hbxg      ,hbxgshow      );
        Utility.ifOrnot(this,dp        ,dpshow        );
        Utility.ifOrnot(this,pqg       ,pqgshow       );
        Utility.ifOrnot(this,chzhq     ,chzhqshow     );
        Utility.ifOrnot(this,wjcdxl    ,wjcdxlshow    );
        Utility.ifOrnot(this,wzA       ,wzAshow       );
        Utility.ifOrnot(this,dy        ,dyshow        );
        Utility.ifOrnot(this,dyxdcsscd ,dyxdcsscdshow );
        Utility.ifOrnot(this,dldccwz   ,dldccwzshow   );
        Utility.ifOrnot(this,kccdkwz   ,kccdkwzshow   );
        Utility.ifOrnot(this,mccdkwz   ,mccdkwzshow   );
        Utility.ifOrnot(this,cdqwz     ,cdqwzshow     );
        Utility.ifOrnot(this,wkcz      ,wkczshow      );
        Utility.ifOrnot(this,czfs      ,czfsshow      );
        Utility.ifOrnot(this,sbsscd    ,sbsscdshow    );
        Utility.ifOrnot(this,xbsscd    ,xbsscdshow    );
        Utility.ifOrnot(this,qbsscd    ,qbsscdshow    );
        Utility.ifOrnot(this,hbsscd    ,hbsscdshow    );
        Utility.ifOrnot(this,zcsscd    ,zcsscdshow    );
        Utility.ifOrnot(this,ycsscd    ,ycsscdshow    );
        Utility.ifOrnot(this,wzB       ,wzBshow       );
        Utility.ifOrnot(this,dcglxtsscd,dcglxtsscdshow);
        Utility.ifOrnot(this,ddj       ,ddjshow       );
        Utility.ifOrnot(this,djkzq     ,djkzqshow     );
        Utility.ifOrnot(this,jsx       ,jsxshow       );
        Utility.ifOrnot(this,dyzhq     ,dyzhqshow     );
        Utility.ifOrnot(this,gypdh     ,gypdhshow     );
        Utility.ifOrnot(this,bxh       ,bxhshow       );
        Utility.ifOrnot(this,jqqg      ,jqqgshow      );
        Utility.ifOrnot(this,pqqg      ,pqqgshow      );
        Utility.ifOrnot(this,bsqlhq    ,bsqlhqshow    );
        Utility.ifOrnot(this,zkzlqzkb  ,zkzlqzkbshow  );
        Utility.ifOrnot(this,srq       ,srqshow       );
        Utility.ifOrnot(this,lqfs      ,lqfsshow      );
        Utility.ifOrnot(this,ABSkzq    ,ABSkzqshow    );
        Utility.ifOrnot(this,zqd       ,zqdshow       );
        Utility.ifOrnot(this,yqd       ,yqdshow       );
        Utility.ifOrnot(this,fdongj    ,fdongjshow    );
        Utility.ifOrnot(this,qdj       ,qdjshow       );
        Utility.ifOrnot(this,fdianj    ,fdianjshow    );
        Utility.ifOrnot(this,ybb       ,ybbshow       );
        Utility.ifOrnot(this,zxp       ,zxpshow       );
        Utility.ifOrnot(this,zyjxh     ,zyjxhshow     );
        Utility.ifOrnot(this,dhkg      ,dhkgshow      );
        Utility.ifOrnot(this,yspbfq    ,yspbfqshow    );
        Utility.ifOrnot(this,gfj       ,gfjshow       );
        Utility.ifOrnot(this,dyq       ,dyqshow       );
        Utility.ifOrnot(this,stx       ,stxshow       );
        Utility.ifOrnot(this,zyfsx     ,zyfsxshow     );
        Utility.ifOrnot(this,jswzy     ,jswzyshow     );
        Utility.ifOrnot(this,fjszy     ,fjszyshow     );
        Utility.ifOrnot(this,hpzy      ,hpzyshow      );
        Utility.ifOrnot(this,zqm       ,zqmshow       );
        Utility.ifOrnot(this,yqm       ,yqmshow       );
        Utility.ifOrnot(this,zhm       ,zhmshow       );
        Utility.ifOrnot(this,yhm       ,yhmshow       );
        Utility.ifOrnot(this,zhcd      ,zhcdshow      );
        Utility.ifOrnot(this,yhcd      ,yhcdshow      );
        Utility.ifOrnot(this,sscd      ,sscdshow      );
    }

    public void click(View view) {
        switch (view.getId()){
            case R.id.b4_btn_next:
                SQLiteDatabase db = helper.getWritableDatabase();
                
                String s1   =Utility.connect(myqs      ,myqsshow      );
                String s3   =Utility.connect(ltzq      ,ltzqshow      );
                String s4   =Utility.connect(ltyq      ,ltyqshow      );
                String s5   =Utility.connect(ltzh      ,ltzhshow      );
                String s6   =Utility.connect(ltyh      ,ltyhshow      );
                String s7   =Utility.connect(lwzq      ,lwzqshow      );
                String s8   =Utility.connect(lwyq      ,lwyqshow      );
                String s9   =Utility.connect(lwzh      ,lwzhshow      );
                String s10  =Utility.connect(lwyh      ,lwyhshow      );
                String s11  =Utility.connect(cmzq      ,cmzqshow      );
                String s12  =Utility.connect(cmyq      ,cmyqshow      );
                String s13  =Utility.connect(cmzh      ,cmzhshow      );
                String s14  =Utility.connect(cmyh      ,cmyhshow      );
                String s15  =Utility.connect(cczq      ,cczqshow      );
                String s16  =Utility.connect(ccyq      ,ccyqshow      );
                String s17  =Utility.connect(cczh      ,cczhshow      );
                String s18  =Utility.connect(ccyh      ,ccyhshow      );
                String s19  =Utility.connect(yzbzq     ,yzbzqshow     );
                String s20  =Utility.connect(yzbyq     ,yzbyqshow     );
                String s21  =Utility.connect(yzbzh     ,yzbzhshow     );
                String s22  =Utility.connect(yzbyh     ,yzbyhshow     );
                String s23  =Utility.connect(cdzq      ,cdzqshow      );
                String s24  =Utility.connect(cdyq      ,cdyqshow      );
                String s25  =Utility.connect(cdzh      ,cdzhshow      );
                String s26  =Utility.connect(cdyh      ,cdyhshow      );
                String s27  =Utility.connect(hsjz      ,hsjzshow      );
                String s28  =Utility.connect(hsjy      ,hsjyshow      );
                String s29  =Utility.connect(bxgqb     ,bxgqbshow     );
                String s30  =Utility.connect(bxghb     ,bxghbshow     );
                String s31  =Utility.connect(fdblqb    ,fdblqbshow    );
                String s32  =Utility.connect(fdblhb    ,fdblhbshow    );
                String s33  =Utility.connect(ygqqb     ,ygqqbshow     );
                String s34  =Utility.connect(ygqhb     ,ygqhbshow     );
                String s35  =Utility.connect(jcg       ,jcgshow       );
                String s36  =Utility.connect(dg        ,dgshow        );
                String s37  =Utility.connect(tc        ,tcshow        );
                String s38  =Utility.connect(hbxg      ,hbxgshow      );
                String s39  =Utility.connect(dp        ,dpshow        );
                String s40  =Utility.connect(pqg       ,pqgshow       );
                String s41  =Utility.connect(chzhq     ,chzhqshow     );
                String s42  =Utility.connect(wjcdxl    ,wjcdxlshow    );
                String s43  =Utility.connect(wzA       ,wzAshow       );
                String s44  =Utility.connect(dy        ,dyshow        );
                String s45  =Utility.connect(dyxdcsscd ,dyxdcsscdshow );
                String s46  =Utility.connect(dldccwz   ,dldccwzshow   );
                String s47  =Utility.connect(kccdkwz   ,kccdkwzshow   );
                String s48  =Utility.connect(mccdkwz   ,mccdkwzshow   );
                String s49  =Utility.connect(cdqwz     ,cdqwzshow     );
                String s50  =Utility.connect(wkcz      ,wkczshow      );
                String s53  =Utility.connect(czfs      ,czfsshow      );
                String s55  =Utility.connect(sbsscd    ,sbsscdshow    );
                String s56  =Utility.connect(xbsscd    ,xbsscdshow    );
                String s57  =Utility.connect(qbsscd    ,qbsscdshow    );
                String s58  =Utility.connect(hbsscd    ,hbsscdshow    );
                String s59  =Utility.connect(zcsscd    ,zcsscdshow    );
                String s60  =Utility.connect(ycsscd    ,ycsscdshow    );
                String s65  =Utility.connect(wzB       ,wzBshow       );
                String s66  =Utility.connect(dcglxtsscd,dcglxtsscdshow);
                String s67  =Utility.connect(ddj       ,ddjshow       );
                String s68  =Utility.connect(djkzq     ,djkzqshow     );
                String s69  =Utility.connect(jsx       ,jsxshow       );
                String s70  =Utility.connect(dyzhq     ,dyzhqshow     );
                String s71  =Utility.connect(gypdh     ,gypdhshow     );
                String s72  =Utility.connect(bxh       ,bxhshow       );
                String s73  =Utility.connect(jqqg      ,jqqgshow      );
                String s74  =Utility.connect(pqqg      ,pqqgshow      );
                String s75  =Utility.connect(bsqlhq    ,bsqlhqshow    );
                String s76  =Utility.connect(zkzlqzkb  ,zkzlqzkbshow  );
                String s77  =Utility.connect(srq       ,srqshow       );
                String s78  =Utility.connect(lqfs      ,lqfsshow      );
                String s79  =Utility.connect(ABSkzq    ,ABSkzqshow    );
                String s80  =Utility.connect(zqd       ,zqdshow       );
                String s81  =Utility.connect(yqd       ,yqdshow       );
                String s82  =Utility.connect(fdongj    ,fdongjshow    );
                String s83  =Utility.connect(qdj       ,qdjshow       );
                String s84  =Utility.connect(fdianj    ,fdianjshow    );
                String s85  =Utility.connect(ybb       ,ybbshow       );
                String s86  =Utility.connect(zxp       ,zxpshow       );
                String s87  =Utility.connect(zyjxh     ,zyjxhshow     );
                String s88  =Utility.connect(dhkg      ,dhkgshow      );
                String s89  =Utility.connect(yspbfq    ,yspbfqshow    );
                String s90  =Utility.connect(gfj       ,gfjshow       );
                String s91  =Utility.connect(dyq       ,dyqshow       );
                String s92  =Utility.connect(stx       ,stxshow       );
                String s93  =Utility.connect(zyfsx     ,zyfsxshow     );
                String s94  =Utility.connect(jswzy     ,jswzyshow     );
                String s95  =Utility.connect(fjszy     ,fjszyshow     );
                String s96  =Utility.connect(hpzy      ,hpzyshow      );
                String s97  =Utility.connect(zqm       ,zqmshow       );
                String s98  =Utility.connect(yqm       ,yqmshow       );
                String s99  =Utility.connect(zhm       ,zhmshow       );
                String s100  =Utility.connect(yhm       ,yhmshow       );
                String s101  =Utility.connect(zhcd      ,zhcdshow      );
                String s102  =Utility.connect(yhcd      ,yhcdshow      );
                String s104  =Utility.connect(sscd      ,sscdshow      );
                
                String s2  =qhbw.getText().toString();
                String s51 =eddy.getText().toString();
                String s52 =edrl.getText().toString();
                String s54 =hdzt.getText().toString();
                String s61 =dcdtlx.getText().toString();
                String s62 =dcdtxh.getText().toString();
                String s63 =dcdtedrl.getText().toString();
                String s64 =dcdteddy.getText().toString();
                String s103=zywp.getText().toString();

                String[] args2 = {acc_ID_time,clsbdm, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12, s13, s14, s15, s16, s17, s18, s19,
                        s20, s21, s22, s23, s24, s25, s26, s27, s28, s29, s30, s31, s32, s33, s34, s35, s36, s37, s38,
                        s39, s40, s41, s42};
                String[] args4 = {acc_ID_time,clsbdm,s43, s44, s45, s46, s47, s48, s49, s50, s51, s52, s53, s54, s55, s56, s57,
                        s58, s59, s60, s61, s62, s63, s64, s65, s66, s67, s68, s69, s70, s71, s72, s73, s74, s75, s76,
                        s77, s78, s79, s80, s81, s82, s83, s84, s85, s86, s87, s88, s89, s90, s91, s92, s93, s94, s95,
                        s96, s97, s98, s99, s100, s101, s102, s103, s104};
                String[] args20={acc_ID_time,clsbdm,s1,s2};
                Utility.insert(db,"baseinfo_bqh",args10,args20);

                Utility.insert(db, "baseinfo_b4W", args1, args2);
                Utility.insert(db, "baseinfo_b4N", args3, args4);
                Intent intent = new Intent(ActivityB4.this, ActivityBB.class);
                intent.putExtra("acc_ID_time",acc_ID_time);
                intent.putExtra("clsbdm",clsbdm);
                intent.putExtra("wjm",wjm);
                startActivity(intent);
                break;

                case R.id.b4_btn_photo:
                Intent intent_camera = new Intent(ActivityB4.this, CameraActivity.class);
                intent_camera.putExtra("wjm",wjm);
                startActivity(intent_camera);
                break;
        }
    }
}
