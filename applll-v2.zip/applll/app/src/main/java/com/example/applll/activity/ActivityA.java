package com.example.applll.activity;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.TextureView;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.example.applll.R;
import com.example.applll.Utility;
import com.example.applll.service.DbManger;
import com.example.applll.service.MySQLiteHelper;
import com.lljjcoder.citypickerview.widget.CityPicker;

public class ActivityA extends AppCompatActivity {

    private MySQLiteHelper helper= DbManger.getIntance(this);

    private String[] args1={"Acc_ID","Time_Find","DQP","DQC","DQS","JTWZ","Time_110","YoN_119","Time_119","YoN_120","Time_120",
            "Car_Num","Person_Num","Hurt_Num","State","Time_Survey","Caiji","Luru"};
    private String[] args3={"Acc_ID","SGDD","YCTQS",
            "PD","BMCZ","BMZK","ZWJK","Weather","FX","FL","FS","WD","XCBH","CLBH"};

    private TextView stateshow,sgddshow,bmczshow,bmzkshow,zwjkshow,weathershow,xcbhshow,clbhshow,
            timeshow_find, diqushow,timeshow_110,timeshow_119,timeshow_120,timeshow_survey;
    private Spinner state,sgdd,bmcz,bmzk,zwjk,weather,xcbh,clbh,yon_119,yon_120,yctqs,fx,fl;
    private EditText jtwz,car_num,person_num,hurt_num,caiji,luru,pd,fs,wd;
    private TextureView mTextureView;
    String acc_ID_time,wjm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_a);
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            Log.i("TEST","Granted");
        } else {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, 1);//1 can be another integer
        }
        Intent intent0=getIntent();
        acc_ID_time=intent0.getStringExtra("acc_ID_time");
        wjm=intent0.getStringExtra("wjm");
        Log.d("acc_ID_time",acc_ID_time);
        timeshow_find = findViewById(R.id.a_tv_timeshow_find);
        diqushow = findViewById(R.id.a_tv_show_diqu);
        jtwz = findViewById(R.id.a_et_jutiweizhi);
        timeshow_110 = findViewById(R.id.a_tv_timeshow_110);
        yon_119 = findViewById(R.id.a_sp_119);
        timeshow_119 = findViewById(R.id.a_tv_timeshow_119);
        yon_120 =findViewById(R.id.a_sp_120);
        timeshow_120 = findViewById(R.id.a_tv_timeshow_120);
        car_num = findViewById(R.id.a_et_carnum);
        person_num = findViewById(R.id.a_et_personnum);
        hurt_num =findViewById(R.id.a_et_hurtnum);
        state = findViewById(R.id.a_sp_xcxt);
        stateshow = findViewById(R.id.a_tv_show_xcxt);
        timeshow_survey = findViewById(R.id.a_tv_timeshow_survey);
        caiji = findViewById(R.id.a_et_caiji);
        luru = findViewById(R.id.a_et_luru);
        sgdd = findViewById(R.id.a_sp_sgdd);
        sgddshow = findViewById(R.id.a_tv_show_sgdd);
        yctqs = findViewById(R.id.a_sp_yctqs);
        pd = findViewById(R.id.a_et_podu);
        bmcz = findViewById(R.id.a_sp_bmcz);
        bmczshow = findViewById(R.id.a_tv_show_bmcz);
        bmzk = findViewById(R.id.a_sp_bmzk);
        bmzkshow = findViewById(R.id.a_tv_show_bmzk);
        zwjk = findViewById(R.id.a_sp_zwjk);
        zwjkshow = findViewById(R.id.a_tv_show_zwjk);
        weather = findViewById(R.id.a_sp_weather);
        weathershow = findViewById(R.id.a_tv_show_weather);
        fx = findViewById(R.id.a_sp_fx);
        fl = findViewById(R.id.a_sp_fl);
        fs = findViewById(R.id.a_et_fs);
        wd =findViewById(R.id.a_et_wd);
        xcbh = findViewById(R.id.a_sp_xcbh);
        xcbhshow = findViewById(R.id.a_tv_show_xcbh);
        clbh = findViewById(R.id.a_sp_clbh);
        clbhshow = findViewById(R.id.a_tv_show_clbh);


        Utility.ifOrnot(this,state,stateshow);
        Utility.ifOrnot(this,sgdd,sgddshow);
        Utility.ifOrnot(this,bmcz,bmczshow);
        Utility.ifOrnot(this,bmzk,bmzkshow);
        Utility.ifOrnot(this,zwjk,zwjkshow);
        Utility.ifOrnot(this,weather,weathershow);
        Utility.ifOrnot(this,xcbh,xcbhshow);
        Utility.ifOrnot(this,clbh,clbhshow);

    }


    public void click(View view) {

        switch (view.getId()){

            case R.id.a_btn_next:

                SQLiteDatabase db = helper.getWritableDatabase();

                String s1 = timeshow_find.getText().toString();
                String tmp = diqushow.getText().toString();
                String ttmp[]=null;
                String s2 = null;
                String s2c = null;
                String s2s = null;
                if(tmp !=null && !tmp.isEmpty()){
                    ttmp = tmp.split("-");
                    s2 = ttmp[0];
                    s2c = ttmp[1];
                    s2s = ttmp[2];
                }
                String s3 = jtwz.getText().toString();
                String s4 = timeshow_110.getText().toString();
                String s5 = yon_119.getSelectedItem().toString();
                String s6 = timeshow_119.getText().toString();
                String s7 = yon_120.getSelectedItem().toString();
                String s8 = timeshow_120.getText().toString();
                String s9 = car_num.getText().toString();
                String s10 = person_num.getText().toString();
                String s11 = hurt_num.getText().toString();
                String s12a = state.getSelectedItem().toString();
                String s12b = stateshow.getText().toString();
                String s12 = s12a + s12b;
                String s13 = timeshow_survey.getText().toString();
                String s14 = caiji.getText().toString();
                String s15 = luru.getText().toString();
                String s16a = sgdd.getSelectedItem().toString();
                String s16b = sgddshow.getText().toString();
                String s16 = s16a + s16b;
                String s17 = yctqs.getSelectedItem().toString();
                String s18 = pd.getText().toString();
                String s19a = bmcz.getSelectedItem().toString();
                String s19b = bmczshow.getText().toString();
                String s19 = s19a + s19b;
                String s20a = bmzk.getSelectedItem().toString();
                String s20b = bmzkshow.getText().toString();
                String s20 = s20a + s20b;
                String s21a = zwjk.getSelectedItem().toString();
                String s21b = zwjkshow.getText().toString();
                String s21 = s21a + s21b;
                String s22a = weather.getSelectedItem().toString();
                String s22b = weathershow.getText().toString();
                String s22 = s22a + s22b;
                String s23 = fx.getSelectedItem().toString();
                String s24 = fl.getSelectedItem().toString();
                String s25 = fs.getText().toString();
                String s26 = wd.getText().toString();
                String s27a = xcbh.getSelectedItem().toString();
                String s27b = xcbhshow.getText().toString();
                String s27 = s27a + s27b;
                String s28a = clbh.getSelectedItem().toString();
                String s28b = clbhshow.getText().toString();
                String s28 = s28a + s28b;
                String[] args2={acc_ID_time,s1,s2,s2c,s2s,s3,s4,s5,s6,s7,s8,s9,s10,s11,s12,s13,s14,s15};
                String[] args4={acc_ID_time,s16,s17,s18,s19,s20,s21,s22,s23,s24,s25,s26,s27,s28};
                Utility.insert(db,"baseinfo_aTPP",args1,args2);
                Utility.insert(db,"baseinfo_aEnv",args3,args4);

                Intent intent = new Intent(ActivityA.this, ActivityB.class);
                intent.putExtra("acc_ID_time",acc_ID_time);
                intent.putExtra("wjm",wjm);
                startActivity(intent);
                break;

            case R.id.a_btn_time_find:

                timeshow_find = findViewById(R.id.a_tv_timeshow_find);
                Utility.dateTimePick(this, timeshow_find);
                break;

            case R.id.a_btn_diqu:

                diqushow = findViewById(R.id.a_tv_show_diqu);
                CityPicker cityPicker = new CityPicker.Builder(ActivityA.this)
                        .textSize(14)
                        .title("地址选择")
                        .titleBackgroundColor("#FFFFFF")
                        .confirTextColor("#696969")
                        .cancelTextColor("#696969")
                        .province("天津市")
                        .city("天津市")
                        .district("津南区")
                        .textColor(Color.parseColor("#000000"))
                        .provinceCyclic(false)
                        .cityCyclic(false)
                        .districtCyclic(false)
                        .visibleItemsCount(7)
                        .itemPadding(20)
                        .onlyShowProvinceAndCity(false)
                        .build();
                cityPicker.show();
                //监听方法，获取选择结果
                cityPicker.setOnCityItemClickListener(new CityPicker.OnCityItemClickListener() {
                    @Override
                    public void onSelected(String... citySelected) {
                        //省份
                        String province = citySelected[0];
                        //城市
                        String city = citySelected[1];
                        //区县（如果设定了两级联动，那么该项返回空）
                        String district = citySelected[2];
                        //邮编
                        String code = citySelected[3];
                        //为TextView赋值
                        diqushow.setText(province.trim() + "-" + city.trim() + "-" + district.trim());
                    }
                });
                break;

            case R.id.a_btn_time_110:

                timeshow_110 = findViewById(R.id.a_tv_timeshow_110);
                Utility.dateTimePick(this, timeshow_110);
                break;

            case R.id.a_btn_time_119:
                timeshow_119 = findViewById(R.id.a_tv_timeshow_119);
                Utility.dateTimePick(this, timeshow_119);
                break;

            case R.id.a_btn_time_120:
                timeshow_120 = findViewById(R.id.a_tv_timeshow_120);
                Utility.dateTimePick(this, timeshow_120);
                break;

            case R.id.a_btn_time_survey:
                timeshow_survey = findViewById(R.id.a_tv_timeshow_survey);
                Utility.dateTimePick(this, timeshow_survey);
                break;

            case R.id.a_btn_photo:
                Intent intent_camera = new Intent(ActivityA.this, CameraActivity.class);
                intent_camera.putExtra("wjm",wjm);
                startActivity(intent_camera);
                break;
        }
    }
}
