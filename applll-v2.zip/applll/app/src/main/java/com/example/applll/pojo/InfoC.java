package com.example.applll.pojo;

public class InfoC {
    public String acc_id;
    public String rylx;
    public String xb;
    public int nl;
    public String dcdd;
    public String dcfs;
    public String sfxy;
    public String sfyj;
    public String ssqk;
    public String ssbw;
    public String clxn;
    public String cqcsA;
    public String fxsrywz;
    public int xjjl;
    public String bmqhzyxx;
    public String cqcsB;
    public String wzA;
    public String gdA;
    public int ztgdA;
    public String wzB;
    public String ys;
    public String gdB;
    public int ztgdB;
}
