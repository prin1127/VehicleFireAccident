package com.example.applll.activity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.applll.R;
import com.example.applll.Utility;
import com.example.applll.pojo.InfoA1;
import com.example.applll.pojo.InfoA2;
import com.example.applll.pojo.InfoB;
import com.example.applll.pojo.InfoB1N;
import com.example.applll.pojo.InfoB1W;
import com.example.applll.pojo.InfoB2N;
import com.example.applll.pojo.InfoB2W;
import com.example.applll.pojo.InfoB3N;
import com.example.applll.pojo.InfoB3W;
import com.example.applll.pojo.InfoB4N;
import com.example.applll.pojo.InfoB4W;
import com.example.applll.pojo.InfoB5N;
import com.example.applll.pojo.InfoB5W;
import com.example.applll.pojo.InfoBB;
import com.example.applll.pojo.InfoBBB;
import com.example.applll.pojo.InfoBQH;
import com.example.applll.pojo.InfoC;
import com.example.applll.service.DbManger;
import com.example.applll.service.MySQLiteHelper;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRichTextString;

public class ActivityC extends AppCompatActivity {


    private MySQLiteHelper helper= DbManger.getIntance(this);

    private String[] args1={"acc_ID","RYLX","XB","NL","DCDD","DCFS","SFXY","SFYJ","SSQK","SSBW","CLXN","CQCSA",
            "FXSRYWZ","XJJL","BMQHZYXX","CQCSB","WZA","GDA","ZTGDA","WZB","YS","GDB","ZTGDB"};

    private TextView rylxshow,dcddshow,dcfsshow,sfxyshow,sfyjshow,clxnshow,cqcsAshow,fxsrywzshow,
            bmqhzyxxshow,cqcsBshow,wzAshow,wzBshow,ysshow;

    private Spinner rylx,xb,dcdd,dcfs,sfxy,sfyj,ssqk,clxn,cqcsA,fxsrywz,gdA,ys,gdB;

    private EditText nl,ssbw,xjjl,ztgdA,ztgdB;
    String acc_ID_time,clsbdm,wjm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_c);

        Intent intent0 = getIntent();
        acc_ID_time = intent0.getStringExtra("acc_ID_time");
        //clsbdm=intent0.getStringExtra("clsbdm");
        wjm=intent0.getStringExtra("wjm");
        rylx=findViewById(R.id.c_sp_rylx);
        rylxshow=findViewById(R.id.c_tv_show_rylx);
        xb=findViewById(R.id.c_sp_xb);
        nl=findViewById(R.id.c_et_nl);
        dcdd=findViewById(R.id.c_sp_dcdd);
        dcddshow=findViewById(R.id.c_tv_show_dcdd);
        dcfs=findViewById(R.id.c_sp_dcfs);
        dcfsshow=findViewById(R.id.c_tv_show_dcfs);
        sfxy=findViewById(R.id.c_sp_sfxy);
        sfxyshow=findViewById(R.id.c_tv_show_sfxy);
        sfyj=findViewById(R.id.c_sp_sfyj);
        sfyjshow=findViewById(R.id.c_tv_show_sfyj);
        ssqk=findViewById(R.id.c_sp_ssqk);
        ssbw=findViewById(R.id.c_et_ssbw);
        clxn=findViewById(R.id.c_sp_clxn);
        clxnshow=findViewById(R.id.c_tv_show_clxn);
        cqcsA=findViewById(R.id.c_sp_cqcsA);
        cqcsAshow=findViewById(R.id.c_tv_show_cqcsA);
        fxsrywz=findViewById(R.id.c_sp_fxsrywz);
        fxsrywzshow=findViewById(R.id.c_tv_show_fxsrywz);
        xjjl=findViewById(R.id.c_et_xjjl);
        gdA=findViewById(R.id.c_sp_gdA);
        ztgdA=findViewById(R.id.c_et_ztgdA);
        ys=findViewById(R.id.c_sp_ys);
        ysshow=findViewById(R.id.c_tv_show_ys);
        gdB=findViewById(R.id.c_sp_gdB);
        ztgdB=findViewById(R.id.c_et_ztgdB);
        bmqhzyxxshow = findViewById(R.id.c_tv_show_bmqhzyxx);
        cqcsBshow = findViewById(R.id.c_tv_show_cqcsB);
        wzAshow = findViewById(R.id.c_tv_show_wzA);
        wzBshow = findViewById(R.id.c_tv_show_wzB);

        Utility.ifOrnot(this,rylx,rylxshow);
        Utility.ifOrnot(this,dcdd,dcddshow);
        Utility.ifOrnot(this,dcfs,dcfsshow);
        Utility.ifOrnot(this,sfxy,sfxyshow);
        Utility.ifOrnot(this,sfyj,sfyjshow);
        Utility.ifOrnot(this,clxn,clxnshow);
        Utility.ifOrnot(this,cqcsA,cqcsAshow);
        Utility.ifOrnot(this,fxsrywz,fxsrywzshow);
        Utility.ifOrnot(this,ys,ysshow);

    }

    public void click(View view) {
        switch (view.getId()){
            case R.id.c_btn_next:
                SQLiteDatabase db = helper.getWritableDatabase();

                String s1=Utility.connect(rylx,rylxshow);
                String s2=xb.getSelectedItem().toString();
                String s3=nl.getText().toString();
                String s4a=dcdd.getSelectedItem().toString();
                String s4b=dcddshow.getText().toString();
                String s4=s4a + s4b;
                String s5a=dcfs.getSelectedItem().toString();
                String s5b=dcfsshow.getText().toString();
                String s5=s5a + s5b;
                String s6a=sfxy.getSelectedItem().toString();
                String s6b=sfxyshow.getText().toString();
                String s6=s6a + s6b;
                String s7a=sfyj.getSelectedItem().toString();
                String s7b=sfyjshow.getText().toString();
                String s7=s7a + s7b;
                String s8=ssqk.getSelectedItem().toString();
                String s9=ssbw.getText().toString();
                String s10a=clxn.getSelectedItem().toString();
                String s10b=clxnshow.getText().toString();
                String s10=s10a + s10b;
                String s11a=cqcsA.getSelectedItem().toString();
                String s11b=cqcsAshow.getText().toString();
                String s11=s11a + s11b;
                String s12a=fxsrywz.getSelectedItem().toString();
                String s12b=fxsrywzshow.getText().toString();
                String s12=s12a + s12b;
                String s13=xjjl.getText().toString();
                String s14= bmqhzyxxshow.getText().toString();
                String s15= cqcsBshow.getText().toString();
                String s16= wzAshow.getText().toString();
                String s17=gdA.getSelectedItem().toString();
                String s18=ztgdA.getText().toString();
                String s19= wzBshow.getText().toString();
                String s20a=ys.getSelectedItem().toString();
                String s20b=ysshow.getText().toString();
                String s20=s20a + s20b;
                String s21=gdB.getSelectedItem().toString();
                String s22=ztgdB.getText().toString();
                String[] args2 = {acc_ID_time, s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12, s13, s14, s15, s16, s17, s18, s19, s20, s21, s22};
                Utility.insert(db, "baseinfo_c", args1, args2);
                db.close();
                db = helper.getWritableDatabase();
                //Log.d("ActivityC_acc_ID_time", acc_ID_time);
                Log.i("testttt",acc_ID_time);
                List<InfoA1> infoA1 = Utility.queryA1(db, acc_ID_time);
                List<InfoA2> infoA2 = Utility.queryA2(db, acc_ID_time);
                List<InfoB> infoB = Utility.queryB(db, acc_ID_time);
                List<InfoC> infoC = Utility.queryC(db, acc_ID_time);
                List<InfoBB> infoBB = Utility.queryBB(db, acc_ID_time);
                List<InfoBBB> infoBBB = Utility.queryBBB(db, acc_ID_time);
                List<InfoB1W> infoB1W = Utility.queryB1W(db, acc_ID_time);
                List<InfoB1N> infoB1N = Utility.queryB1N(db, acc_ID_time);
                List<InfoB2W> infoB2W = Utility.queryB2W(db, acc_ID_time);
                List<InfoB2N> infoB2N = Utility.queryB2N(db, acc_ID_time);
                List<InfoB3W> infoB3W = Utility.queryB3W(db, acc_ID_time);
                List<InfoB3N> infoB3N = Utility.queryB3N(db, acc_ID_time);
                List<InfoB4W> infoB4W = Utility.queryB4W(db, acc_ID_time);
                List<InfoB4N> infoB4N = Utility.queryB4N(db, acc_ID_time);
                List<InfoB5W> infoB5W = Utility.queryB5W(db, acc_ID_time);
                List<InfoB5N> infoB5N = Utility.queryB5N(db, acc_ID_time);
                List<InfoBQH> infoBQH = Utility.queryBQH(db,acc_ID_time);
                String path =  Environment.getExternalStorageDirectory().getAbsolutePath() + "/火灾车辆调查/"+wjm+"/";//VehicleInvestigation
                File DirFile = new File(path);
                if (!DirFile.exists()) {
                    DirFile.mkdirs();
                }
                int sheetnums=0;
                File file = new File(path + acc_ID_time + ".xlsx");//获取excel文件对象
                XSSFWorkbook workbook = new XSSFWorkbook();
                try {
                    OutputStream out = new FileOutputStream(file);
                    //写sheetA1
                    Utility.exportExcel(workbook, sheetnums++, "表A时间地点人员", Utility.CELL_HEADSA1, Utility.convertDataToRowA1(infoA1.get(0)));
                    //写sheetA2
                    Utility.exportExcel(workbook, sheetnums++, "表A事故地点环境条件", Utility.CELL_HEADSA2, Utility.convertDataToRowA2(infoA2.get(0)));
                    //写sheetC
                    Utility.exportExcel(workbook, sheetnums++, "人员地调查信息", Utility.CELL_HEADSC, Utility.convertDataToRowC(infoC.get(0)));
                    //写sheetB
                    Utility.exportExcel(workbook, sheetnums++, "车辆基本信息", Utility.CELL_HEADSB, Utility.convertDataToRowB(infoB.get(0), infoBQH.get(0)));
                    //写sheetB1W
                    if (infoB1W != null && !infoB1W.isEmpty()) {
                        Utility.exportExcel(workbook, sheetnums++, "表B1乘用车外部烧损信息", Utility.CELL_HEADSB1W, Utility.convertDataToRowB1W(infoB1W.get(0)));
                    } else {
                        Utility.exportExcelHeader(workbook, sheetnums++, "表B1乘用车外部烧损信息", Utility.CELL_HEADSB1W);
                    }
                    //写sheetB1N
                    if (infoB1N != null && !infoB1N.isEmpty()) {
                        Utility.exportExcel(workbook, sheetnums++, "表B1乘用车内部烧损信息", Utility.CELL_HEADSB1N, Utility.convertDataToRowB1N(infoB1N.get(0)));
                    } else {
                        Utility.exportExcelHeader(workbook, sheetnums++, "表B1乘用车内部烧损信息", Utility.CELL_HEADSB1N);
                    }
                    //写sheetB2W
                    if (infoB2W != null && !infoB2W.isEmpty()) {
                        Utility.exportExcel(workbook, sheetnums++, "表B2货车外部烧损信息", Utility.CELL_HEADSB2W, Utility.convertDataToRowB2W(infoB2W.get(0)));
                    } else {
                        Utility.exportExcelHeader(workbook, sheetnums++, "表B2货车外部烧损信息", Utility.CELL_HEADSB2W);
                    }
                    //写sheetB2N
                    if (infoB2N != null && !infoB2N.isEmpty()) {
                        Utility.exportExcel(workbook, sheetnums++, "表B2货车内部烧损信息", Utility.CELL_HEADSB2N, Utility.convertDataToRowB2N(infoB2N.get(0)));
                    } else {
                        Utility.exportExcelHeader(workbook, sheetnums++, "表B2货车内部烧损信息", Utility.CELL_HEADSB2N);
                    }
                    //写sheetB3W
                    if (infoB3W != null && !infoB3W.isEmpty()) {
                        Utility.exportExcel(workbook, sheetnums++, "表B3客车外部烧损信息", Utility.CELL_HEADSB3W, Utility.convertDataToRowB3W(infoB3W.get(0)));
                    } else {
                        Utility.exportExcelHeader(workbook, sheetnums++, "表B3客车外部烧损信息", Utility.CELL_HEADSB3W);
                    }
                    //写sheetB3N
                    if (infoB3N != null && !infoB3N.isEmpty()) {
                        Utility.exportExcel(workbook, sheetnums++, "表B3客车内部烧损信息", Utility.CELL_HEADSB3N, Utility.convertDataToRowB3N(infoB3N.get(0)));
                    } else{
                        Utility.exportExcelHeader(workbook, sheetnums++, "表B3客车内部烧损信息", Utility.CELL_HEADSB3N);
                    }
                    //写sheetB4W
                    if (infoB4W != null && !infoB4W.isEmpty()) {
                        Utility.exportExcel(workbook, sheetnums++, "表B4电动汽车外部烧损信息", Utility.CELL_HEADSB4W, Utility.convertDataToRowB4W(infoB4W.get(0)));
                    }else{
                        Utility.exportExcelHeader(workbook, sheetnums++, "表B4电动汽车外部烧损信息", Utility.CELL_HEADSB4W);
                    }
                    //写sheetB4N
                    if (infoB4N != null && !infoB4N.isEmpty()) {
                        Utility.exportExcel(workbook, sheetnums++, "表B4电动汽车内部烧损信息", Utility.CELL_HEADSB4N, Utility.convertDataToRowB4N(infoB4N.get(0)));
                    }else{
                        Utility.exportExcelHeader(workbook, sheetnums++, "表B4电动汽车内部烧损信息", Utility.CELL_HEADSB4N);
                    }
                    //写sheetB5W
                    if (infoB5W != null && !infoB5W.isEmpty()) {
                        Utility.exportExcel(workbook, sheetnums++, "表B5电动客车外部烧损信息", Utility.CELL_HEADSB5W, Utility.convertDataToRowB5W(infoB5W.get(0)));
                    }else{
                        Utility.exportExcelHeader(workbook, sheetnums++, "表B5电动客车外部烧损信息", Utility.CELL_HEADSB5W);
                    }
                    //写sheetB5N
                    if (infoB5N != null && !infoB5N.isEmpty()) {
                        Utility.exportExcel(workbook, sheetnums++, "表B5电动客车内部烧损信息", Utility.CELL_HEADSB5N, Utility.convertDataToRowB5N(infoB5N.get(0)));
                    }else{
                        Utility.exportExcelHeader(workbook, sheetnums++, "表B5电动客车内部烧损信息", Utility.CELL_HEADSB5N);
                    }
                    //写sheetBB
                    Utility.exportExcel(workbook, sheetnums++, "汽车周围烧损信息", Utility.CELL_HEADSBB, Utility.convertDataToRowBB(infoBB.get(0)));
                    //写sheetBBB
                    Utility.exportExcel(workbook, sheetnums++, "起火部位信息", Utility.CELL_HEADSBBB, Utility.convertDataToRowBBB(infoBBB.get(0)));
                    workbook.write(out);
                    out.close();

                }catch (Exception e) {
                    e.printStackTrace();
                }

                Intent intent = new Intent(ActivityC.this, MainActivity.class);
                startActivity(intent);
                break;


            case R.id.c_btn_bmqhzyxx:
                bmqhzyxxshow = findViewById(R.id.c_tv_show_bmqhzyxx);
                String[] items1 = {"1见到火光","2见到火焰","3见到烟气","4闻到异味","5感觉到热量","6报警装置报警","8其他","9未知"};
                boolean[] checkedItems1 = {false,false,false,false,false,false,false,false};
                Utility.multiSelect(this,bmqhzyxxshow,items1,checkedItems1);
                break;

            case R.id.c_btn_cqcsB:
                cqcsBshow = findViewById(R.id.c_tv_show_cqcsB);
                String[] items2 = {"1报警","2用灭火器扑救","3用水扑救","8其他","9未知"};
                boolean[] checkedItems2 = {false,false,false,false,false};
                Utility.multiSelect(this,cqcsBshow,items2,checkedItems2);
                break;

            case R.id.c_btn_wzA:
                wzAshow = findViewById(R.id.c_tv_show_wzA);
                String[] items3 = {"1发动机舱/动力机舱","2驾驶室/乘员舱","3后备箱/货箱","4车轮","5底盘","6低压电池舱","7动力电池舱","8其他","9未知"};
                boolean[] checkedItems3 = {false,false,false,false,false,false,false,false,false};
                Utility.multiSelect(this,wzAshow,items3,checkedItems3);
                break;

            case R.id.c_btn_wzB:
                wzBshow = findViewById(R.id.c_tv_show_wzB);
                String[] items4 = {"1发动机舱/动力机舱","2驾驶室/乘员舱","3后备箱/货箱","4车轮","5底盘","6低压电池舱","7动力电池舱","8其他","9未知"};
                boolean[] checkedItems4 = {false,false,false,false,false,false,false,false,false};
                Utility.multiSelect(this,wzBshow,items4,checkedItems4);
                break;

            case R.id.c_btn_photo:
                Intent intent_camera = new Intent(ActivityC.this, CameraActivity.class);
                intent_camera.putExtra("acc_ID_time",acc_ID_time);
                intent_camera.putExtra("wjm",wjm);
                startActivity(intent_camera);
                break;
        }
    }

}
