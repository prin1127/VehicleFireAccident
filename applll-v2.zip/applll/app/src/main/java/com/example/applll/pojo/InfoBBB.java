package com.example.applll.pojo;

public class InfoBBB {
    public String acc_id;
    public String clsbdm;
    public String zyssbjmc1  ;
    public String zyssbjsscd1;
    public String zsdqxl1    ;
    public String fjdqxl1    ;
    public String zyssbjmc2  ;
    public String zyssbjsscd2;
    public String zsdqxl2    ;
    public String fjdqxl2    ;
    public String zykrwmc1   ;
    public String zykrwsscd1 ;
    public String zykrwmc2   ;
    public String zykrwsscd2 ;
}
