package com.example.applll.service;

import android.content.Context;

public class DbManger {

    private static MySQLiteHelper helper;
    public static MySQLiteHelper getIntance(Context context){
        if(helper == null){
            helper = new MySQLiteHelper(context);
        }
        return helper;
    }
}
