package com.example.applll.pojo;

public class InfoBB {
    public String acc_id;
    public String clsbdm;
    public String qfzywt1    ;
    public String qfsscd1    ;
    public String qfzywt2    ;
    public String qfsscd2    ;
    public String hfzywt1    ;
    public String hfsscd1    ;
    public String hfzywt2    ;
    public String hfsscd2    ;
    public String zczywt1    ;
    public String zcsscd1    ;
    public String zczywt2    ;
    public String zcsscd2    ;
    public String yczywt1    ;
    public String ycsscd1    ;
    public String yczywt2    ;
    public String ycsscd2    ;
    public String sfzywt1    ;
    public String sfsscd1    ;
    public String sfzywt2    ;
    public String sfsscd2    ;
    public String dmzywt1    ;
    public String dmsscd1    ;
    public String dmzywt2    ;
    public String dmsscd2    ;
}
