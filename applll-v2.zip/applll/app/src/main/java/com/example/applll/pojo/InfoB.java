package com.example.applll.pojo;

public class InfoB {
    public String acc_id;
    public String clsbdm ;
    public String ppxh   ;
    public String clxz   ;
    public String clzcsj ;
    public int    xslc   ;
    public int    sfqxsjl;
    public int    sfqxssj;
    public int    sfqtfsj;
    public String sfszt  ;
    public String sfhtfwz;
    public String zyfs   ;
    public String sfjz   ;
    public String jzbj   ;
    public String jzsj   ;
    public String jzwz   ;
    public String zjwbsj ;
    public String wbmd   ;
    public String wbnr   ;
    public String gmbx   ;
    public String tbxz   ;
    public String tbsj   ;
    public String myqs   ;
    public String qhbw   ;
    public String clzl   ;
}
