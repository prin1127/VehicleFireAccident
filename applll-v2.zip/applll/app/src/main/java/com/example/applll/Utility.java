package com.example.applll;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;

import com.example.applll.pojo.InfoA1;
import com.example.applll.pojo.InfoA2;
import com.example.applll.pojo.InfoB;
import com.example.applll.pojo.InfoBQH;
import com.example.applll.pojo.InfoB1N;
import com.example.applll.pojo.InfoB1W;
import com.example.applll.pojo.InfoB2N;
import com.example.applll.pojo.InfoB2W;
import com.example.applll.pojo.InfoB3N;
import com.example.applll.pojo.InfoB3W;
import com.example.applll.pojo.InfoB4N;
import com.example.applll.pojo.InfoB4W;
import com.example.applll.pojo.InfoB5N;
import com.example.applll.pojo.InfoB5W;
import com.example.applll.pojo.InfoBB;
import com.example.applll.pojo.InfoBBB;
import com.example.applll.pojo.InfoC;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.Random;

import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRichTextString;
//import jxl.write.Label;

public class Utility {

    public static void insert(SQLiteDatabase db, String tablename, String[] args1, String[] args2){
        ContentValues values = new ContentValues();
        for(int i=0;i<args1.length;i++){
            values.put(args1[i],args2[i]);
        }
        db.insert(tablename,null,values);
        //db.close();
    }

    public static void multiSelect(Activity ac, TextView tv, String[] items, boolean[] checkedItems){
        //创建一个对话框
        AlertDialog.Builder builder = new AlertDialog.Builder(ac);
        builder.setMultiChoiceItems(items, checkedItems, new DialogInterface.OnMultiChoiceClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which, boolean isChecked) {
            }
        });
        builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                StringBuffer sb = new StringBuffer();
                for (int i = 0; i < checkedItems.length; i++) {
                    //判断一下是选中的
                    if (checkedItems[i]) {
                        String sss = items[i];
                        sb.append(sss + " ");
                    }
                }
                //显示所选择的选项文本
                tv.setText(sb.toString());
                dialog.dismiss();
            }
        });
        //实现对话框的显示
        builder.show();
    }

    public static void dateTimePick(Activity ac, TextView tv){//不用精确到秒
        //DateFormat format = DateFormat.getDateTimeInstance();//获取日期格式器对象
        SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd HH:mm");//"yyyy/MM/dd HH:mm:ss"
        Calendar calendar = Calendar.getInstance(Locale.CHINA);//获取日期格式器对象//如“2020年7月1日”

        new TimePickerDialog(ac, AlertDialog.THEME_HOLO_LIGHT,new TimePickerDialog.OnTimeSetListener() {

            @Override

            public void onTimeSet(TimePicker view, int hourofday, int minute) {

                calendar.set(Calendar.HOUR_OF_DAY,hourofday);
                calendar.set(Calendar.MINUTE,minute);

                tv.setText(format.format(calendar.getTime()));

            }
        },
                calendar.get(Calendar.HOUR_OF_DAY),calendar.get(Calendar.MINUTE),true
        ).show();

        new DatePickerDialog(ac, new DatePickerDialog.OnDateSetListener() {
            @Override

            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {

                //修改日历控件的年，月，日
                // 这里的year,monthOfYear,dayOfMonth的值与DatePickerDialog控件设置的最新值一致

                calendar.set(Calendar.YEAR,year);
                calendar.set(Calendar.MONTH,month);
                calendar.set(Calendar.DAY_OF_MONTH,dayOfMonth);

                tv.setText(format.format(calendar.getTime()));

            }

        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)
        ).show();
    }

    public static void datePick(Activity ac,TextView tv){
        SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");//"yyyy/MM/dd HH:mm:ss"
        Calendar calendar = Calendar.getInstance(Locale.CHINA);//获取日期格式器对象

        new DatePickerDialog(ac, new DatePickerDialog.OnDateSetListener() {
            @Override

            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {

                //修改日历控件的年，月，日
                // 这里的year,monthOfYear,dayOfMonth的值与DatePickerDialog控件设置的最新值一致

                calendar.set(Calendar.YEAR,year);
                calendar.set(Calendar.MONTH,month);
                calendar.set(Calendar.DAY_OF_MONTH,dayOfMonth);

                tv.setText(format.format(calendar.getTime()));
                //tv.setText(year + "年" + (month+1) + "月" + dayOfMonth + "日");

            }

        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)
        ).show();
    }

    public static void ifOrnot(Activity ac, Spinner sp, TextView tv){
        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                //这个方法里可以对点击事件进行处理
                //i指的是点击的位置,通过i可以取到相应的数据源
                String info=adapterView.getItemAtPosition(i).toString();//获取i所在的文本
                if(info.equals("8其他")|| info.equals("3部件功能异常：") || info.equals("2有，具体位置") || info.equals("2非起火现场 原因：")){
                    final EditText et = new EditText(ac);
                    new AlertDialog.Builder(ac).setTitle("请输入")
                            .setIcon(android.R.drawable.sym_def_app_icon)
                            .setView(et)
                            .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    //按下确定键后的事件
                                    tv.setText(et.getText().toString());
                                }
                            }).setNegativeButton("取消",null).show();
                }
                else {
                    tv.setText("");
                }

            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });
    }

    public static String connect(Spinner sp,TextView tv){
        String info = sp.getSelectedItem().toString();
        String a=info;
        if(info.contains("8其他")|| info.contains("3部件功能异常：") || info.contains("2有，具体位置") || info.contains("2非起火现场 原因：")){
            a=info.substring(0,1);
        }
        Log.i("testttt",a);
        String b = tv.getText().toString();
        return a + b;
    }

    public static void exportExcel(XSSFWorkbook workbook, int sheetNum, String sheetTitle, List<String> headers,
                            List<String> result) throws Exception {
        XSSFSheet sheet = workbook.createSheet();// 第一步，创建一个workbook，对应一个Excel以xsl为扩展名文件
        workbook.setSheetName(sheetNum, sheetTitle);
        sheet.setDefaultColumnWidth((short) 30);//设置列宽度大小
        //XSSFCellStyle xssfCellStyleHeader = getAndSetXSSFCellStyleHeader(workbook);//第二步， 生成表格第一行的样式和字体
        XSSFRow row = sheet.createRow(0);// 产生表格标题行
        for (int i = 0; i < headers.size(); i++) {
            XSSFCell cell = row.createCell(i);// 序号
            //cell.setCellStyle(xssfCellStyleHeader);
            XSSFRichTextString text = new XSSFRichTextString(headers.get(i));
            cell.setCellValue(text.toString());
        }
        // 第三步：遍历集合数据，产生数据行，开始插入数据
        if (result != null && !result.isEmpty()) {
            row = sheet.createRow(1);
            for (int i = 0; i < result.size(); i++) {
                    XSSFCell cell = row.createCell(i);
                    cell.setCellValue(result.get(i));
                }
        }
    }

    //没有数据
    public static void exportExcelHeader(XSSFWorkbook workbook, int sheetNum, String sheetTitle, List<String> headers) throws Exception {
        XSSFSheet sheet = workbook.createSheet();// 第一步，创建一个workbook，对应一个Excel以xsl为扩展名文件
        workbook.setSheetName(sheetNum, sheetTitle);
        sheet.setDefaultColumnWidth((short) 30);//设置列宽度大小
        //XSSFCellStyle xssfCellStyleHeader = getAndSetXSSFCellStyleHeader(workbook);//第二步， 生成表格第一行的样式和字体
        XSSFRow row = sheet.createRow(0);// 产生表格标题行
        for (int i = 0; i < headers.size(); i++) {
            XSSFCell cell = row.createCell(i);// 序号
            //cell.setCellStyle(xssfCellStyleHeader);
            XSSFRichTextString text = new XSSFRichTextString(headers.get(i));
            cell.setCellValue(text.toString());
        }
    }

    public static List<InfoA1> queryA1(SQLiteDatabase db, String acc_ID_time) {
        String[] args1 = {"Acc_ID", "Time_Find", "DQP",  "JTWZ", "Time_110", "YoN_119", "Time_119", "YoN_120", "Time_120",
                "Car_Num", "Person_Num", "Hurt_Num", "State", "Time_Survey", "Caiji", "Luru","DQC", "DQS"};
        List<InfoA1> infoA1 = null;
        Cursor cursor = db.rawQuery("select * from baseinfo_aTPP where Acc_ID = ?", new String[]{acc_ID_time});
        if (cursor != null && cursor.getCount() > 0) {

            infoA1 = new ArrayList<>();

            while (cursor.moveToNext()) {
                InfoA1 infoa1 = new InfoA1();

                infoa1.acc_id = cursor.getString(cursor.getColumnIndex(args1[0]));
                infoa1.time_find = cursor.getString(cursor.getColumnIndex(args1[1]));
                infoa1.dqp = cursor.getString(cursor.getColumnIndex(args1[2]));
                infoa1.dqc = cursor.getString(cursor.getColumnIndex(args1[16]));
                infoa1.dqs = cursor.getString(cursor.getColumnIndex(args1[17]));
                infoa1.jtwz = cursor.getString(cursor.getColumnIndex(args1[3]));
                infoa1.time_110 = cursor.getString(cursor.getColumnIndex(args1[4]));
                infoa1.yon_119 = cursor.getString(cursor.getColumnIndex(args1[5]));
                infoa1.time_119 = cursor.getString(cursor.getColumnIndex(args1[6]));
                infoa1.yon_120 = cursor.getString(cursor.getColumnIndex(args1[7]));
                infoa1.time_120 = cursor.getString(cursor.getColumnIndex(args1[8]));
                infoa1.car_num = cursor.getInt(cursor.getColumnIndex(args1[9]));
                infoa1.person_num = cursor.getInt(cursor.getColumnIndex(args1[10]));
                infoa1.hurt_num = cursor.getInt(cursor.getColumnIndex(args1[11]));
                infoa1.state = cursor.getString(cursor.getColumnIndex(args1[12]));
                infoa1.time_survey = cursor.getString(cursor.getColumnIndex(args1[13]));
                infoa1.caiji = cursor.getString(cursor.getColumnIndex(args1[14]));
                infoa1.luru = cursor.getString(cursor.getColumnIndex(args1[15]));

                infoA1.add(infoa1);
            }
            cursor.close();
        }
        //db.close();
        return infoA1;
    }

    public static List<InfoA2> queryA2(SQLiteDatabase db, String acc_ID_time) {
        String[] args1 = {"Acc_ID", "SGDD", "YCTQS",
                "PD", "BMCZ", "BMZK", "ZWJK", "Weather", "FX", "FL", "FS", "WD", "XCBH", "CLBH"};
        List<InfoA2> infoA2 = null;
        Cursor cursor = db.rawQuery("select * from baseinfo_aEnv where Acc_ID = ?", new String[]{acc_ID_time});
        if (cursor != null && cursor.getCount() > 0) {

            infoA2 = new ArrayList<>();

            while (cursor.moveToNext()) {
                InfoA2 infoa2 = new InfoA2();
                infoa2.acc_id = cursor.getString(cursor.getColumnIndex(args1[0]));
                infoa2.sgdd = cursor.getString(cursor.getColumnIndex(args1[1]));
                infoa2.yctqs = cursor.getString(cursor.getColumnIndex(args1[2]));
                infoa2.pd = cursor.getInt(cursor.getColumnIndex(args1[3]));
                infoa2.bmcz = cursor.getString(cursor.getColumnIndex(args1[4]));
                infoa2.bmzk = cursor.getString(cursor.getColumnIndex(args1[5]));
                infoa2.zwjk = cursor.getString(cursor.getColumnIndex(args1[6]));
                infoa2.weather = cursor.getString(cursor.getColumnIndex(args1[7]));
                infoa2.fx = cursor.getString(cursor.getColumnIndex(args1[8]));
                infoa2.fl = cursor.getString(cursor.getColumnIndex(args1[9]));
                infoa2.fs = cursor.getInt(cursor.getColumnIndex(args1[10]));
                infoa2.wd = cursor.getInt(cursor.getColumnIndex(args1[11]));
                infoa2.xcbh = cursor.getString(cursor.getColumnIndex(args1[12]));
                infoa2.clbh = cursor.getString(cursor.getColumnIndex(args1[13]));

                infoA2.add(infoa2);
            }
            cursor.close();
        }
        //db.close();
        return infoA2;
    }

    public static List<InfoB> queryB(SQLiteDatabase db, String acc_ID_time) {
        List<InfoB> infoB = null;
        Cursor cursor = db.rawQuery("select * from baseinfo_b where Acc_ID = ?", new String[]{acc_ID_time});
        if (cursor != null && cursor.getCount() > 0) {
            infoB = new ArrayList<>();
            while (cursor.moveToNext()) {
                InfoB infob = new InfoB();
                //String tmp[]=cursor.getColumnNames();
                //Log.d("aaaaaaa",tmp[1]);
                infob.acc_id = cursor.getString(cursor.getColumnIndex("Acc_ID"));
                infob.clsbdm = cursor.getString(cursor.getColumnIndex("CLSBDM"));
                infob.ppxh = cursor.getString(cursor.getColumnIndex("PPXH"));
                infob.clxz = cursor.getString(cursor.getColumnIndex("CLXZ"));
                infob.clzcsj = cursor.getString(cursor.getColumnIndex("CLZCSJ"));
                infob.xslc = cursor.getInt(cursor.getColumnIndex("XSLC"));
                infob.sfqxsjl = cursor.getInt(cursor.getColumnIndex("SFQXSJL"));
                infob.sfqxssj = cursor.getInt(cursor.getColumnIndex("SFQXSSJ"));
                infob.sfqtfsj = cursor.getInt(cursor.getColumnIndex("SFQTFSJ"));
                infob.sfszt = cursor.getString(cursor.getColumnIndex("SFSZT"));
                infob.sfhtfwz = cursor.getString(cursor.getColumnIndex("SFHTFWZ"));
                infob.zyfs = cursor.getString(cursor.getColumnIndex("ZYFS"));
                infob.sfjz = cursor.getString(cursor.getColumnIndex("SFJZ"));
                infob.jzbj = cursor.getString(cursor.getColumnIndex("JZBJ"));
                infob.jzsj = cursor.getString(cursor.getColumnIndex("JZSJ"));
                infob.jzwz = cursor.getString(cursor.getColumnIndex("JZWZ"));
                infob.zjwbsj = cursor.getString(cursor.getColumnIndex("ZJWBSJ"));
                infob.wbmd = cursor.getString(cursor.getColumnIndex("WBMD"));
                infob.wbnr = cursor.getString(cursor.getColumnIndex("WBNR"));
                infob.gmbx = cursor.getString(cursor.getColumnIndex("GMBX"));
                infob.tbxz = cursor.getString(cursor.getColumnIndex("TBXZ"));
                infob.tbsj = cursor.getString(cursor.getColumnIndex("TBSJ"));
                //infob.myqs = cursor.getString(cursor.getColumnIndex("MYQS"));
                //infob.qhbw = cursor.getString(cursor.getColumnIndex("QHBW"));
                infob.clzl = cursor.getString(cursor.getColumnIndex("CLZL"));

                infoB.add(infob);
            }
            cursor.close();
        }
        //db.close();
        return infoB;

    }

    public static List<InfoBQH> queryBQH(SQLiteDatabase db, String acc_ID_time) {
        List<InfoBQH> infoBQH = null;
        Cursor cursor = db.rawQuery("select * from baseinfo_bqh where Acc_ID = ?", new String[]{acc_ID_time});
        if (cursor != null && cursor.getCount() > 0) {
            infoBQH = new ArrayList<>();
            while (cursor.moveToNext()) {
                InfoBQH infobqh = new InfoBQH();
                //String tmp[]=cursor.getColumnNames();
                //Log.d("aaaaaaa",tmp[1]);
                infobqh.acc_id = cursor.getString(cursor.getColumnIndex("Acc_ID"));
                infobqh.clsbdm = cursor.getString(cursor.getColumnIndex("CLSBDM"));
                infobqh.myqs = cursor.getString(cursor.getColumnIndex("MYQS"));
                infobqh.qhbw = cursor.getString(cursor.getColumnIndex("QHBW"));

                infoBQH.add(infobqh);
            }
            cursor.close();
        }
        //db.close();
        return infoBQH;

    }

    public static List<InfoC> queryC(SQLiteDatabase db, String acc_ID_time) {
        List<InfoC> infoC = null;
        Cursor cursor = db.rawQuery("select * from baseinfo_c where Acc_ID = ?", new String[]{acc_ID_time});
        if (cursor != null && cursor.getCount() > 0) {

            infoC = new ArrayList<>();

            while (cursor.moveToNext()) {
                InfoC infoc = new InfoC();

                infoc.acc_id = cursor.getString(cursor.getColumnIndex("Acc_ID"));
                Log.d("database select one", infoc.acc_id);
                infoc.rylx = cursor.getString(cursor.getColumnIndex("RYLX"));
                infoc.xb = cursor.getString(cursor.getColumnIndex("XB"));
                infoc.nl = cursor.getInt(cursor.getColumnIndex("NL"));
                infoc.dcdd = cursor.getString(cursor.getColumnIndex("DCDD"));
                infoc.dcfs = cursor.getString(cursor.getColumnIndex("DCFS"));
                infoc.sfxy = cursor.getString(cursor.getColumnIndex("SFXY"));
                infoc.sfyj = cursor.getString(cursor.getColumnIndex("SFYJ"));
                infoc.ssqk = cursor.getString(cursor.getColumnIndex("SSQK"));
                infoc.ssbw = cursor.getString(cursor.getColumnIndex("SSBW"));
                infoc.clxn = cursor.getString(cursor.getColumnIndex("CLXN"));
                infoc.cqcsA = cursor.getString(cursor.getColumnIndex("CQCSA"));
                infoc.fxsrywz = cursor.getString(cursor.getColumnIndex("FXSRYWZ"));
                infoc.xjjl = cursor.getInt(cursor.getColumnIndex("XJJL"));
                infoc.bmqhzyxx = cursor.getString(cursor.getColumnIndex("BMQHZYXX"));
                infoc.cqcsB = cursor.getString(cursor.getColumnIndex("CQCSB"));
                infoc.wzA = cursor.getString(cursor.getColumnIndex("WZA"));
                infoc.gdA = cursor.getString(cursor.getColumnIndex("GDA"));
                infoc.ztgdA = cursor.getInt(cursor.getColumnIndex("ZTGDA"));
                infoc.wzB = cursor.getString(cursor.getColumnIndex("WZB"));
                infoc.ys = cursor.getString(cursor.getColumnIndex("YS"));
                infoc.gdB = cursor.getString(cursor.getColumnIndex("GDB"));
                infoc.ztgdB = cursor.getInt(cursor.getColumnIndex("ZTGDB"));

                infoC.add(infoc);
            }
            cursor.close();
        }
        //db.close();
        return infoC;
    }

    public static List<InfoBB> queryBB(SQLiteDatabase db, String acc_ID_time) {
        List<InfoBB> infoBB = null;
        Cursor cursor = db.rawQuery("SELECT * FROM [baseinfo_bb] where Acc_ID = ?", new String[]{acc_ID_time});
        if (cursor != null && cursor.getCount() > 0) {
            infoBB = new ArrayList<>();
            while (cursor.moveToNext()) {
                InfoBB infobb = new InfoBB();
                infobb.acc_id = cursor.getString(cursor.getColumnIndex("Acc_ID"));
                infobb.clsbdm = cursor.getString(cursor.getColumnIndex("CLSBDM"));
                infobb.qfzywt1 = cursor.getString(cursor.getColumnIndex("QFZYWT1"));
                infobb.qfsscd1 = cursor.getString(cursor.getColumnIndex("QFSSCD1"));
                infobb.qfzywt2 = cursor.getString(cursor.getColumnIndex("QFZYWT2"));
                infobb.qfsscd2 = cursor.getString(cursor.getColumnIndex("QFSSCD2"));
                infobb.hfzywt1 = cursor.getString(cursor.getColumnIndex("HFZYWT1"));
                infobb.hfsscd1 = cursor.getString(cursor.getColumnIndex("HFSSCD1"));
                infobb.hfzywt2 = cursor.getString(cursor.getColumnIndex("HFZYWT2"));
                infobb.hfsscd2 = cursor.getString(cursor.getColumnIndex("HFSSCD2"));
                infobb.zczywt1 = cursor.getString(cursor.getColumnIndex("ZCZYWT1"));
                infobb.zcsscd1 = cursor.getString(cursor.getColumnIndex("ZCSSCD1"));
                infobb.zczywt2 = cursor.getString(cursor.getColumnIndex("ZCZYWT2"));
                infobb.zcsscd2 = cursor.getString(cursor.getColumnIndex("ZCSSCD2"));
                infobb.yczywt1 = cursor.getString(cursor.getColumnIndex("YCZYWT1"));
                infobb.ycsscd1 = cursor.getString(cursor.getColumnIndex("YCSSCD1"));
                infobb.yczywt2 = cursor.getString(cursor.getColumnIndex("YCZYWT2"));
                infobb.ycsscd2 = cursor.getString(cursor.getColumnIndex("YCSSCD2"));
                infobb.sfzywt1 = cursor.getString(cursor.getColumnIndex("SFZYWT1"));
                infobb.sfsscd1 = cursor.getString(cursor.getColumnIndex("SFSSCD1"));
                infobb.sfzywt2 = cursor.getString(cursor.getColumnIndex("SFZYWT2"));
                infobb.sfsscd2 = cursor.getString(cursor.getColumnIndex("SFSSCD2"));
                infobb.dmzywt1 = cursor.getString(cursor.getColumnIndex("DMZYWT1"));
                infobb.dmsscd1 = cursor.getString(cursor.getColumnIndex("DMSSCD1"));
                infobb.dmzywt2 = cursor.getString(cursor.getColumnIndex("DMZYWT2"));
                infobb.dmsscd2 = cursor.getString(cursor.getColumnIndex("DMSSCD2"));

                infoBB.add(infobb);
            }
            cursor.close();
        }
        //db.close();
        return infoBB;
    }

    public static List<InfoBBB> queryBBB(SQLiteDatabase db, String acc_ID_time) {
        List<InfoBBB> infoBBB = null;
        Cursor cursor = db.rawQuery("SELECT * FROM [baseinfo_bbb] where Acc_ID = ?", new String[]{acc_ID_time});
        if (cursor != null && cursor.getCount() > 0) {
            infoBBB = new ArrayList<>();
            while (cursor.moveToNext()) {
                InfoBBB infobbb = new InfoBBB();
                infobbb.acc_id = cursor.getString(cursor.getColumnIndex("Acc_ID"));
                infobbb.clsbdm = cursor.getString(cursor.getColumnIndex("CLSBDM"));
                infobbb.zyssbjmc1 = cursor.getString(cursor.getColumnIndex("ZYSSBJMC1"));
                infobbb.zyssbjsscd1 = cursor.getString(cursor.getColumnIndex("ZYSSBJSSCD1"));
                infobbb.zsdqxl1 = cursor.getString(cursor.getColumnIndex("ZSDQXL1"));
                infobbb.fjdqxl1 = cursor.getString(cursor.getColumnIndex("FJDQXL1"));
                infobbb.zyssbjmc2 = cursor.getString(cursor.getColumnIndex("ZYSSBJMC2"));
                infobbb.zyssbjsscd2 = cursor.getString(cursor.getColumnIndex("ZYSSBJSSCD2"));
                infobbb.zsdqxl2 = cursor.getString(cursor.getColumnIndex("ZSDQXL2"));
                infobbb.fjdqxl2 = cursor.getString(cursor.getColumnIndex("FJDQXL2"));
                infobbb.zykrwmc1 = cursor.getString(cursor.getColumnIndex("ZYKRWMC1"));
                infobbb.zykrwsscd1 = cursor.getString(cursor.getColumnIndex("ZYKRWSSCD1"));
                infobbb.zykrwmc2 = cursor.getString(cursor.getColumnIndex("ZYKRWMC2"));
                infobbb.zykrwsscd2 = cursor.getString(cursor.getColumnIndex("ZYKRWSSCD2"));

                infoBBB.add(infobbb);
            }
            cursor.close();
        }
        //db.close();
        return infoBBB;
    }

    public static List<InfoB1W> queryB1W(SQLiteDatabase db, String acc_ID_time) {
        List<InfoB1W> infoB1W = new ArrayList<>();
        Cursor cursor = db.rawQuery("SELECT * FROM [baseinfo_b1W] where Acc_ID = ?", new String[]{acc_ID_time});
        if (cursor != null && cursor.getCount() > 0) {

            while (cursor.moveToNext()) {
                InfoB1W infob1w = new InfoB1W();

                infob1w.acc_id = cursor.getString(cursor.getColumnIndex("Acc_ID"));
                infob1w.clsbdm = cursor.getString(cursor.getColumnIndex("CLSBDM"));
                //infob1w.qhbw = cursor.getString(cursor.getColumnIndex("QHBW"));
                //infob1w.myqs = cursor.getString(cursor.getColumnIndex("MYQS"));
                infob1w.ltzq = cursor.getString(cursor.getColumnIndex("LTZQ"));
                infob1w.ltyq = cursor.getString(cursor.getColumnIndex("LTYQ"));
                infob1w.ltzh = cursor.getString(cursor.getColumnIndex("LTZH"));
                infob1w.ltyh = cursor.getString(cursor.getColumnIndex("LTYH"));
                infob1w.lwzq = cursor.getString(cursor.getColumnIndex("LWZQ"));
                infob1w.lwyq = cursor.getString(cursor.getColumnIndex("LWYQ"));
                infob1w.lwzh = cursor.getString(cursor.getColumnIndex("LWZH"));
                infob1w.lwyh = cursor.getString(cursor.getColumnIndex("LWYH"));
                infob1w.cmzq = cursor.getString(cursor.getColumnIndex("CMZQ"));
                infob1w.cmyq = cursor.getString(cursor.getColumnIndex("CMYQ"));
                infob1w.cmzh = cursor.getString(cursor.getColumnIndex("CMZH"));
                infob1w.cmyh = cursor.getString(cursor.getColumnIndex("CMYH"));
                infob1w.cczq = cursor.getString(cursor.getColumnIndex("CCZQ"));
                infob1w.ccyq = cursor.getString(cursor.getColumnIndex("CCYQ"));
                infob1w.cczh = cursor.getString(cursor.getColumnIndex("CCZH"));
                infob1w.ccyh = cursor.getString(cursor.getColumnIndex("CCYH"));
                infob1w.yzbzq = cursor.getString(cursor.getColumnIndex("YZBZQ"));
                infob1w.yzbyq = cursor.getString(cursor.getColumnIndex("YZBYQ"));
                infob1w.yzbzh = cursor.getString(cursor.getColumnIndex("YZBZH"));
                infob1w.yzbyh = cursor.getString(cursor.getColumnIndex("YZBYH"));
                infob1w.cdzq = cursor.getString(cursor.getColumnIndex("CDZQ"));
                infob1w.cdyq = cursor.getString(cursor.getColumnIndex("CDYQ"));
                infob1w.cdzh = cursor.getString(cursor.getColumnIndex("CDZH"));
                infob1w.cdyh = cursor.getString(cursor.getColumnIndex("CDYH"));
                infob1w.hsjzq = cursor.getString(cursor.getColumnIndex("HSJZQ"));
                infob1w.hsjyq = cursor.getString(cursor.getColumnIndex("HSJYQ"));
                infob1w.bxgqb = cursor.getString(cursor.getColumnIndex("BXGQB"));
                infob1w.bxghb = cursor.getString(cursor.getColumnIndex("BXGHB"));
                infob1w.fdblqb = cursor.getString(cursor.getColumnIndex("FDBLQB"));
                infob1w.fdblhb = cursor.getString(cursor.getColumnIndex("FDBLHB"));
                infob1w.ygqqb = cursor.getString(cursor.getColumnIndex("YGQQB"));
                infob1w.ygqhb = cursor.getString(cursor.getColumnIndex("YGQHB"));
                infob1w.fdjcg = cursor.getString(cursor.getColumnIndex("FDJCG"));
                infob1w.dg = cursor.getString(cursor.getColumnIndex("DG"));
                infob1w.tc = cursor.getString(cursor.getColumnIndex("TC"));
                infob1w.hbxg = cursor.getString(cursor.getColumnIndex("HBXG"));
                infob1w.dp = cursor.getString(cursor.getColumnIndex("DP"));
                infob1w.pqg = cursor.getString(cursor.getColumnIndex("PQG"));
                infob1w.chzhq = cursor.getString(cursor.getColumnIndex("CHZHQ"));
                infoB1W.add(infob1w);
            }
            cursor.close();
        }
        //db.close();
        return infoB1W;
    }

    public static List<InfoB1N> queryB1N(SQLiteDatabase db, String acc_ID_time) {
        List<InfoB1N> infoB1N = new ArrayList<>();
        Cursor cursor = db.rawQuery("SELECT * FROM [baseinfo_b1N] where Acc_ID = ?", new String[]{acc_ID_time});
        if (cursor != null && cursor.getCount() > 0) {
            while (cursor.moveToNext()) {
                InfoB1N infob1n = new InfoB1N();

                infob1n.acc_id = cursor.getString(cursor.getColumnIndex("Acc_ID"));
                infob1n.clsbdm = cursor.getString(cursor.getColumnIndex("CLSBDM"));
                infob1n.wz = cursor.getString(cursor.getColumnIndex("WZ"));
                infob1n.dy = cursor.getString(cursor.getColumnIndex("DY"));
                infob1n.xdcsscd = cursor.getString(cursor.getColumnIndex("XDCSSCD"));
                infob1n.jykwz = cursor.getString(cursor.getColumnIndex("JYKWZ"));
                infob1n.cz = cursor.getString(cursor.getColumnIndex("CZ"));
                infob1n.yl = cursor.getString(cursor.getColumnIndex("YL"));
                infob1n.yxsscd = cursor.getString(cursor.getColumnIndex("YXSSCD"));
                infob1n.fdongj = cursor.getString(cursor.getColumnIndex("FDONGJ"));
                infob1n.fdianj = cursor.getString(cursor.getColumnIndex("FDIANJ"));
                infob1n.qdj = cursor.getString(cursor.getColumnIndex("QDJ"));
                infob1n.dhxq = cursor.getString(cursor.getColumnIndex("DHXQ"));
                infob1n.jylqq = cursor.getString(cursor.getColumnIndex("JYLQQ"));
                infob1n.kqlqq = cursor.getString(cursor.getColumnIndex("KQLQQ"));
                infob1n.zkzlq = cursor.getString(cursor.getColumnIndex("ZKZLQ"));
                infob1n.bxh = cursor.getString(cursor.getColumnIndex("BXH"));
                infob1n.bsqlhq = cursor.getString(cursor.getColumnIndex("BSQLHQ"));
                infob1n.srq = cursor.getString(cursor.getColumnIndex("SRQ"));
                infob1n.lnq = cursor.getString(cursor.getColumnIndex("LNQ"));
                infob1n.lqfs = cursor.getString(cursor.getColumnIndex("LQFS"));
                infob1n.jqqg = cursor.getString(cursor.getColumnIndex("JQQG"));
                infob1n.pqqg = cursor.getString(cursor.getColumnIndex("PQQG"));
                infob1n.wlzyq = cursor.getString(cursor.getColumnIndex("WLZYQ"));
                infob1n.lqyg = cursor.getString(cursor.getColumnIndex("LQYG"));
                infob1n.qxyg = cursor.getString(cursor.getColumnIndex("QXYG"));
                infob1n.zdyg = cursor.getString(cursor.getColumnIndex("ZDYG"));
                infob1n.zlzxyg = cursor.getString(cursor.getColumnIndex("ZLZXYG"));
                infob1n.ktysj = cursor.getString(cursor.getColumnIndex("KTYSJ"));
                infob1n.ABSkzq = cursor.getString(cursor.getColumnIndex("ABSKZQ"));
                infob1n.zqd = cursor.getString(cursor.getColumnIndex("ZQD"));
                infob1n.yqd = cursor.getString(cursor.getColumnIndex("YQD"));
                infob1n.ybb = cursor.getString(cursor.getColumnIndex("YBB"));
                infob1n.zxp = cursor.getString(cursor.getColumnIndex("ZXP"));
                infob1n.zyjxh = cursor.getString(cursor.getColumnIndex("ZYJXH"));
                infob1n.dhkg = cursor.getString(cursor.getColumnIndex("DHKG"));
                infob1n.yspbfq = cursor.getString(cursor.getColumnIndex("YSPBFQ"));
                infob1n.gfj = cursor.getString(cursor.getColumnIndex("GFJ"));
                infob1n.zqm = cursor.getString(cursor.getColumnIndex("ZQM"));
                infob1n.zhm = cursor.getString(cursor.getColumnIndex("ZHM"));
                infob1n.dyq = cursor.getString(cursor.getColumnIndex("DYQ"));
                infob1n.stx = cursor.getString(cursor.getColumnIndex("STX"));
                infob1n.zyfsx = cursor.getString(cursor.getColumnIndex("ZYFSX"));
                infob1n.jswzy = cursor.getString(cursor.getColumnIndex("JSWZY"));
                infob1n.fjszy = cursor.getString(cursor.getColumnIndex("FJSZY"));
                infob1n.hpzy = cursor.getString(cursor.getColumnIndex("HPZY"));
                infob1n.yqm = cursor.getString(cursor.getColumnIndex("YQM"));
                infob1n.yhm = cursor.getString(cursor.getColumnIndex("YHM"));
                infob1n.bt = cursor.getString(cursor.getColumnIndex("BT"));
                infob1n.zhcd = cursor.getString(cursor.getColumnIndex("ZHCD"));
                infob1n.yhcd = cursor.getString(cursor.getColumnIndex("YHCD"));
                infob1n.sscdA = cursor.getString(cursor.getColumnIndex("SSCDA"));
                infob1n.sscdB = cursor.getString(cursor.getColumnIndex("SSCDB"));
                infob1n.zywpA = cursor.getString(cursor.getColumnIndex("ZYWPA"));
                infob1n.zywpB = cursor.getString(cursor.getColumnIndex("ZYWPB"));
                infoB1N.add(infob1n);
            }
            cursor.close();
        }
        //db.close();
        return infoB1N;
    }

    public static List<InfoB2W> queryB2W(SQLiteDatabase db, String acc_ID_time) {
        List<InfoB2W> infoB2W = null;
        Cursor cursor = db.rawQuery("SELECT * FROM [baseinfo_b2W] where Acc_ID = ?", new String[]{acc_ID_time});
        if (cursor != null && cursor.getCount() > 0) {
            infoB2W = new ArrayList<>();
            while (cursor.moveToNext()) {
                InfoB2W infob2w = new InfoB2W();
                infob2w.acc_id = cursor.getString(cursor.getColumnIndex("Acc_ID"));
                infob2w.clsbdm = cursor.getString(cursor.getColumnIndex("CLSBDM"));
                //infob2w.myqs = cursor.getString(cursor.getColumnIndex("MYQS"));
                //infob2w.qhbw = cursor.getString(cursor.getColumnIndex("QHBW"));
                infob2w.ltz1 = cursor.getString(cursor.getColumnIndex("LTZ1"));
                infob2w.ltz2 = cursor.getString(cursor.getColumnIndex("LTZ2"));
                infob2w.ltz3 = cursor.getString(cursor.getColumnIndex("LTZ3"));
                infob2w.ltz4 = cursor.getString(cursor.getColumnIndex("LTZ4"));
                infob2w.lty1 = cursor.getString(cursor.getColumnIndex("LTY1"));
                infob2w.lty2 = cursor.getString(cursor.getColumnIndex("LTY2"));
                infob2w.lty3 = cursor.getString(cursor.getColumnIndex("LTY3"));
                infob2w.lty4 = cursor.getString(cursor.getColumnIndex("LTY4"));
                infob2w.lwz1 = cursor.getString(cursor.getColumnIndex("LWZ1"));
                infob2w.lwz2 = cursor.getString(cursor.getColumnIndex("LWZ2"));
                infob2w.lwz3 = cursor.getString(cursor.getColumnIndex("LWZ3"));
                infob2w.lwz4 = cursor.getString(cursor.getColumnIndex("LWZ4"));
                infob2w.lwy1 = cursor.getString(cursor.getColumnIndex("LWY1"));
                infob2w.lwy2 = cursor.getString(cursor.getColumnIndex("LWY2"));
                infob2w.lwy3 = cursor.getString(cursor.getColumnIndex("LWY3"));
                infob2w.lwy4 = cursor.getString(cursor.getColumnIndex("LWY4"));
                infob2w.cmz1 = cursor.getString(cursor.getColumnIndex("CMZ1"));
                infob2w.cmz2 = cursor.getString(cursor.getColumnIndex("CMZ2"));
                infob2w.cmy1 = cursor.getString(cursor.getColumnIndex("CMY1"));
                infob2w.cmy2 = cursor.getString(cursor.getColumnIndex("CMY2"));
                infob2w.ccz1 = cursor.getString(cursor.getColumnIndex("CCZ1"));
                infob2w.ccz2 = cursor.getString(cursor.getColumnIndex("CCZ2"));
                infob2w.ccy1 = cursor.getString(cursor.getColumnIndex("CCY1"));
                infob2w.ccy2 = cursor.getString(cursor.getColumnIndex("CCY2"));
                infob2w.yzbz = cursor.getString(cursor.getColumnIndex("YZBZ"));
                infob2w.yzby = cursor.getString(cursor.getColumnIndex("YZBY"));
                infob2w.cdz1 = cursor.getString(cursor.getColumnIndex("CDZ1"));
                infob2w.cdz2 = cursor.getString(cursor.getColumnIndex("CDZ2"));
                infob2w.cdz3 = cursor.getString(cursor.getColumnIndex("CDZ3"));
                infob2w.cdz4 = cursor.getString(cursor.getColumnIndex("CDZ4"));
                infob2w.cdy1 = cursor.getString(cursor.getColumnIndex("CDY1"));
                infob2w.cdy2 = cursor.getString(cursor.getColumnIndex("CDY2"));
                infob2w.cdy3 = cursor.getString(cursor.getColumnIndex("CDY3"));
                infob2w.cdy4 = cursor.getString(cursor.getColumnIndex("CDY4"));
                infob2w.hsjz = cursor.getString(cursor.getColumnIndex("HSJZ"));
                infob2w.hsjy = cursor.getString(cursor.getColumnIndex("HSJY"));
                infob2w.bxgqb = cursor.getString(cursor.getColumnIndex("BXGQB"));
                infob2w.bxghb = cursor.getString(cursor.getColumnIndex("BXGHB"));
                infob2w.fdblqb = cursor.getString(cursor.getColumnIndex("FDBLQB"));
                infob2w.fdblhb = cursor.getString(cursor.getColumnIndex("FDBLHB"));
                infob2w.ygq = cursor.getString(cursor.getColumnIndex("YGQ"));
                infob2w.pzsx = cursor.getString(cursor.getColumnIndex("PZSX"));
                infob2w.jssdg = cursor.getString(cursor.getColumnIndex("JSSDG"));
                infob2w.jsshwb = cursor.getString(cursor.getColumnIndex("JSSHWB"));
                infob2w.cxqbzc = cursor.getString(cursor.getColumnIndex("CXQBZC"));
                infob2w.cxhbzc = cursor.getString(cursor.getColumnIndex("CXHBZC"));
                infob2w.cxzbbzc = cursor.getString(cursor.getColumnIndex("CXZBBZC"));
                infob2w.cxdbzc = cursor.getString(cursor.getColumnIndex("CXDBZC"));
                infob2w.cxybbzc = cursor.getString(cursor.getColumnIndex("CXYBBZC"));
                infob2w.cxdb = cursor.getString(cursor.getColumnIndex("CDDB"));
                infob2w.dp = cursor.getString(cursor.getColumnIndex("DP"));
                infob2w.bt = cursor.getString(cursor.getColumnIndex("BT"));
                infob2w.pqg = cursor.getString(cursor.getColumnIndex("PQG"));
                infob2w.chzhq = cursor.getString(cursor.getColumnIndex("CHZHQ"));

                infoB2W.add(infob2w);
            }
            cursor.close();
        }
        //db.close();
        return infoB2W;
    }

    public static List<InfoB2N> queryB2N(SQLiteDatabase db, String acc_ID_time) {
        List<InfoB2N> infoB2N = null;
        Cursor cursor = db.rawQuery("SELECT * FROM [baseinfo_b2N] where Acc_ID = ?", new String[]{acc_ID_time});
        if (cursor != null && cursor.getCount() > 0) {

            infoB2N = new ArrayList<>();

            while (cursor.moveToNext()) {
                InfoB2N infob2n = new InfoB2N();

                infob2n.acc_id = cursor.getString(cursor.getColumnIndex("Acc_ID"));
                infob2n.clsbdm = cursor.getString(cursor.getColumnIndex("CLSBDM"));
                infob2n.wz = cursor.getString(cursor.getColumnIndex("WZ"));
                infob2n.dy = cursor.getString(cursor.getColumnIndex("DY"));
                infob2n.xdcsscd = cursor.getString(cursor.getColumnIndex("XDCSSCD"));
                infob2n.jykwz = cursor.getString(cursor.getColumnIndex("JYKWZ"));
                infob2n.cz = cursor.getString(cursor.getColumnIndex("CZ"));
                infob2n.yl = cursor.getString(cursor.getColumnIndex("YL"));
                infob2n.yxsscd = cursor.getString(cursor.getColumnIndex("YXSSCD"));
                infob2n.fdongj = cursor.getString(cursor.getColumnIndex("FDONGJ"));
                infob2n.fdianj = cursor.getString(cursor.getColumnIndex("FDIANJ"));
                infob2n.qdj = cursor.getString(cursor.getColumnIndex("QDJ"));
                infob2n.cyb = cursor.getString(cursor.getColumnIndex("CYB"));
                infob2n.dhxq = cursor.getString(cursor.getColumnIndex("DHXQ"));
                infob2n.jylqq = cursor.getString(cursor.getColumnIndex("JYLQQ"));
                infob2n.kqlqq = cursor.getString(cursor.getColumnIndex("KQLQQ"));
                infob2n.zkzlq = cursor.getString(cursor.getColumnIndex("ZKZLQ"));
                infob2n.bxh = cursor.getString(cursor.getColumnIndex("BXH"));
                infob2n.bsqlhq = cursor.getString(cursor.getColumnIndex("BSQLHQ"));
                infob2n.srq = cursor.getString(cursor.getColumnIndex("SRQ"));
                infob2n.lnq = cursor.getString(cursor.getColumnIndex("LNQ"));
                infob2n.jqqg = cursor.getString(cursor.getColumnIndex("JQQG"));
                infob2n.pqqg = cursor.getString(cursor.getColumnIndex("PQQG"));
                infob2n.wlzyq = cursor.getString(cursor.getColumnIndex("WLZYQ"));
                infob2n.lqyg = cursor.getString(cursor.getColumnIndex("LQYG"));
                infob2n.qxyg = cursor.getString(cursor.getColumnIndex("QXYG"));
                infob2n.zdyg = cursor.getString(cursor.getColumnIndex("ZDYG"));
                infob2n.zlzxyg = cursor.getString(cursor.getColumnIndex("ZLZXYG"));
                infob2n.ktysj = cursor.getString(cursor.getColumnIndex("KTYSJ"));
                infob2n.ABSkzq = cursor.getString(cursor.getColumnIndex("ABSKZQ"));
                infob2n.zqdA = cursor.getString(cursor.getColumnIndex("ZQDA"));
                infob2n.yqdA = cursor.getString(cursor.getColumnIndex("YQDA"));
                infob2n.lqfs = cursor.getString(cursor.getColumnIndex("LQFS"));
                infob2n.ybb = cursor.getString(cursor.getColumnIndex("YBB"));
                infob2n.zxp = cursor.getString(cursor.getColumnIndex("ZXP"));
                infob2n.gfj = cursor.getString(cursor.getColumnIndex("GFJ"));
                infob2n.yspbfq = cursor.getString(cursor.getColumnIndex("YSPBFQ"));
                infob2n.dyq = cursor.getString(cursor.getColumnIndex("DYQ"));
                infob2n.zqdB = cursor.getString(cursor.getColumnIndex("ZQDB"));
                infob2n.zqm = cursor.getString(cursor.getColumnIndex("ZQM"));
                infob2n.zhm = cursor.getString(cursor.getColumnIndex("ZHM"));
                infob2n.jxh = cursor.getString(cursor.getColumnIndex("JXH"));
                infob2n.stx = cursor.getString(cursor.getColumnIndex("STX"));
                infob2n.jswzy = cursor.getString(cursor.getColumnIndex("JSWZY"));
                infob2n.fjszy = cursor.getString(cursor.getColumnIndex("FJSZY"));
                infob2n.hpzy = cursor.getString(cursor.getColumnIndex("HPZY"));
                infob2n.yqdB = cursor.getString(cursor.getColumnIndex("YQDB"));
                infob2n.yqm = cursor.getString(cursor.getColumnIndex("YQM"));
                infob2n.yhm = cursor.getString(cursor.getColumnIndex("YHM"));
                infob2n.qbzc = cursor.getString(cursor.getColumnIndex("QBZC"));
                infob2n.hbzc = cursor.getString(cursor.getColumnIndex("HBZC"));
                infob2n.zbbzc = cursor.getString(cursor.getColumnIndex("ZBBZC"));
                infob2n.ybbzc = cursor.getString(cursor.getColumnIndex("YBBZC"));
                infob2n.dbzc = cursor.getString(cursor.getColumnIndex("DBZC"));
                infob2n.db = cursor.getString(cursor.getColumnIndex("DB"));
                infob2n.zhcd = cursor.getString(cursor.getColumnIndex("ZHCD"));
                infob2n.yhcd = cursor.getString(cursor.getColumnIndex("YHCD"));
                infob2n.zywp = cursor.getString(cursor.getColumnIndex("ZYWP"));
                infob2n.sscd = cursor.getString(cursor.getColumnIndex("SSCD"));

                infoB2N.add(infob2n);
            }
            cursor.close();
        }
        //db.close();
        return infoB2N;
    }

    public static List<InfoB3W> queryB3W(SQLiteDatabase db, String acc_ID_time){
        List<InfoB3W> infoB3W = null ;
        Cursor cursor = db.rawQuery("SELECT * FROM [baseinfo_b3w] where Acc_ID = ?", new String[]{acc_ID_time});
        if(cursor != null && cursor.getCount() > 0){
            infoB3W = new ArrayList<>();
            while (cursor.moveToNext()){
                InfoB3W infob3w = new InfoB3W();
                infob3w.acc_id =cursor.getString(cursor.getColumnIndex("Acc_ID"));
                infob3w.clsbdm = cursor.getString(cursor.getColumnIndex("CLSBDM"));
                //infob3w.myqs   =cursor.getString(cursor.getColumnIndex("MYQS"   ));
                //infob3w.qhbw   =cursor.getString(cursor.getColumnIndex("QHBW"   ));
                infob3w.ltz1   =cursor.getString(cursor.getColumnIndex("LTZ1"   ));
                infob3w.ltz2   =cursor.getString(cursor.getColumnIndex("LTZ2"   ));
                infob3w.ltz3   =cursor.getString(cursor.getColumnIndex("LTZ3"   ));
                infob3w.lty1   =cursor.getString(cursor.getColumnIndex("LTY1"   ));
                infob3w.lty2   =cursor.getString(cursor.getColumnIndex("LTY2"   ));
                infob3w.lty3   =cursor.getString(cursor.getColumnIndex("LTY3"   ));
                infob3w.lwz1   =cursor.getString(cursor.getColumnIndex("LWZ1"   ));
                infob3w.lwz2   =cursor.getString(cursor.getColumnIndex("LWZ2"   ));
                infob3w.lwz3   =cursor.getString(cursor.getColumnIndex("LWZ3"   ));
                infob3w.lwy1   =cursor.getString(cursor.getColumnIndex("LWY1"   ));
                infob3w.lwy2   =cursor.getString(cursor.getColumnIndex("LWY2"   ));
                infob3w.lwy3   =cursor.getString(cursor.getColumnIndex("LWY3"   ));
                infob3w.cmz1   =cursor.getString(cursor.getColumnIndex("CMZ1"   ));
                infob3w.cmy1   =cursor.getString(cursor.getColumnIndex("CMY1"   ));
                infob3w.cmy2   =cursor.getString(cursor.getColumnIndex("CMY2"   ));
                infob3w.cmy3   =cursor.getString(cursor.getColumnIndex("CMY3"   ));
                infob3w.cwbz1  =cursor.getString(cursor.getColumnIndex("CWBZ1"  ));
                infob3w.cwbz2  =cursor.getString(cursor.getColumnIndex("CWBZ2"  ));
                infob3w.cwbz3  =cursor.getString(cursor.getColumnIndex("CWBZ3"  ));
                infob3w.cwby1  =cursor.getString(cursor.getColumnIndex("CWBY1"  ));
                infob3w.cwby2  =cursor.getString(cursor.getColumnIndex("CWBY2"  ));
                infob3w.cwby3  =cursor.getString(cursor.getColumnIndex("CWBY3"  ));
                infob3w.cdz1   =cursor.getString(cursor.getColumnIndex("CDZ1"   ));
                infob3w.cdz2   =cursor.getString(cursor.getColumnIndex("CDZ2"   ));
                infob3w.cdy1   =cursor.getString(cursor.getColumnIndex("CDY1"   ));
                infob3w.cdy2   =cursor.getString(cursor.getColumnIndex("CDY2"   ));
                infob3w.hsjz   =cursor.getString(cursor.getColumnIndex("HSJZ"   ));
                infob3w.hsjy   =cursor.getString(cursor.getColumnIndex("HSJY"   ));
                infob3w.ccz1   =cursor.getString(cursor.getColumnIndex("CCZ1"   ));
                infob3w.ccz2   =cursor.getString(cursor.getColumnIndex("CCZ2"   ));
                infob3w.ccz3   =cursor.getString(cursor.getColumnIndex("CCZ3"   ));
                infob3w.ccz4   =cursor.getString(cursor.getColumnIndex("CCZ4"   ));
                infob3w.ccz5   =cursor.getString(cursor.getColumnIndex("CCZ5"   ));
                infob3w.ccz6   =cursor.getString(cursor.getColumnIndex("CCZ6"   ));
                infob3w.ccy1   =cursor.getString(cursor.getColumnIndex("CCY1"   ));
                infob3w.ccy2   =cursor.getString(cursor.getColumnIndex("CCY2"   ));
                infob3w.ccy3   =cursor.getString(cursor.getColumnIndex("CCY3"   ));
                infob3w.ccy4   =cursor.getString(cursor.getColumnIndex("CCY4"   ));
                infob3w.ccy5   =cursor.getString(cursor.getColumnIndex("CCY5"   ));
                infob3w.ccy6   =cursor.getString(cursor.getColumnIndex("CCY6"   ));
                infob3w.bxgqb  =cursor.getString(cursor.getColumnIndex("BXGQB"  ));
                infob3w.bxghb  =cursor.getString(cursor.getColumnIndex("BXGHB"  ));
                infob3w.fdblqb =cursor.getString(cursor.getColumnIndex("FDBLQB" ));
                infob3w.fdblhb =cursor.getString(cursor.getColumnIndex("FDBLHB" ));
                infob3w.ygqqb  =cursor.getString(cursor.getColumnIndex("YGQQB"  ));
                infob3w.ygqhb  =cursor.getString(cursor.getColumnIndex("YGQHB"  ));
                infob3w.dg     =cursor.getString(cursor.getColumnIndex("DG"     ));
                infob3w.dbkt   =cursor.getString(cursor.getColumnIndex("DBKT"   ));
                infob3w.dp     =cursor.getString(cursor.getColumnIndex("DP"     ));
                infob3w.pqg    =cursor.getString(cursor.getColumnIndex("PQG"    ));
                infob3w.chzhq  =cursor.getString(cursor.getColumnIndex("CHZHQ"  ));
                infoB3W.add(infob3w);
            }
            cursor.close();
        }
        //db.close();
        return infoB3W;
    }

    public static List<InfoB3N> queryB3N(SQLiteDatabase db, String acc_ID_time){
        List<InfoB3N> infoB3N = null ;
        Cursor cursor = db.rawQuery("SELECT * FROM [baseinfo_b3n] where Acc_ID = ?", new String[]{acc_ID_time});
        if(cursor != null && cursor.getCount() > 0){
            infoB3N = new ArrayList<>();
            while (cursor.moveToNext()){
                InfoB3N infob3n = new InfoB3N();
                infob3n.acc_id =cursor.getString(cursor.getColumnIndex("Acc_ID"));
                infob3n.clsbdm = cursor.getString(cursor.getColumnIndex("CLSBDM"));
                infob3n.wz     =cursor.getString(cursor.getColumnIndex("WZ"     ));
                infob3n.dy     =cursor.getString(cursor.getColumnIndex("DY"     ));
                infob3n.xdcsscd=cursor.getString(cursor.getColumnIndex("XDCSSCD"));
                infob3n.jykwz  =cursor.getString(cursor.getColumnIndex("JYKWZ"  ));
                infob3n.cz     =cursor.getString(cursor.getColumnIndex("CZ"     ));
                infob3n.yl     =cursor.getString(cursor.getColumnIndex("YL"     ));
                infob3n.yxsscd =cursor.getString(cursor.getColumnIndex("YXSSCD" ));
                infob3n.fdongj =cursor.getString(cursor.getColumnIndex("FDONGJ" ));
                infob3n.fdianj =cursor.getString(cursor.getColumnIndex("FDIANJ" ));
                infob3n.qdj    =cursor.getString(cursor.getColumnIndex("QDJ"    ));
                infob3n.cyb    =cursor.getString(cursor.getColumnIndex("CYB"    ));
                infob3n.hsq    =cursor.getString(cursor.getColumnIndex("HSQ"    ));
                infob3n.dhxq   =cursor.getString(cursor.getColumnIndex("DHXQ"   ));
                infob3n.kqlqq  =cursor.getString(cursor.getColumnIndex("KQLQQ"  ));
                infob3n.jylqq  =cursor.getString(cursor.getColumnIndex("JYLQQ"  ));
                infob3n.zkzlq  =cursor.getString(cursor.getColumnIndex("ZKZLQ"  ));
                infob3n.bxh    =cursor.getString(cursor.getColumnIndex("BXH"    ));
                infob3n.bsqlhq =cursor.getString(cursor.getColumnIndex("BSQLHQ" ));
                infob3n.srq    =cursor.getString(cursor.getColumnIndex("SRQ"    ));
                infob3n.lnq    =cursor.getString(cursor.getColumnIndex("LNQ"    ));
                infob3n.jqqg   =cursor.getString(cursor.getColumnIndex("JQQG"   ));
                infob3n.pqqg   =cursor.getString(cursor.getColumnIndex("PQQG"   ));
                infob3n.wlzyq  =cursor.getString(cursor.getColumnIndex("WLZYQ"  ));
                infob3n.lqyg   =cursor.getString(cursor.getColumnIndex("LQYG"   ));
                infob3n.qxyg   =cursor.getString(cursor.getColumnIndex("QXYG"   ));
                infob3n.zdyg   =cursor.getString(cursor.getColumnIndex("ZDYG"   ));
                infob3n.zlzxyg =cursor.getString(cursor.getColumnIndex("ZLZXYG" ));
                infob3n.ktysj  =cursor.getString(cursor.getColumnIndex("KTYSJ"  ));
                infob3n.ABSkzq =cursor.getString(cursor.getColumnIndex("ABSKZQ" ));
                infob3n.kqysj  =cursor.getString(cursor.getColumnIndex("KQYSJ"  ));
                infob3n.lqfs   =cursor.getString(cursor.getColumnIndex("LQFS"   ));
                infob3n.dyzkg  =cursor.getString(cursor.getColumnIndex("DYZKG"  ));
                infob3n.jxhA   =cursor.getString(cursor.getColumnIndex("JXHA"   ));
                infob3n.ybb    =cursor.getString(cursor.getColumnIndex("YBB"    ));
                infob3n.jxhB   =cursor.getString(cursor.getColumnIndex("JXHB"   ));
                infob3n.zxp    =cursor.getString(cursor.getColumnIndex("ZXP"    ));
                infob3n.dhkg   =cursor.getString(cursor.getColumnIndex("DHKG"   ));
                infob3n.gfj    =cursor.getString(cursor.getColumnIndex("GFJ"    ));
                infob3n.yspbfq =cursor.getString(cursor.getColumnIndex("YSPBFQ" ));
                infob3n.jsq    =cursor.getString(cursor.getColumnIndex("JTQ"    ));
                infob3n.jswzy  =cursor.getString(cursor.getColumnIndex("JSWZY"  ));
                infob3n.fjszy  =cursor.getString(cursor.getColumnIndex("FJSZY"  ));
                infob3n.ckzy   =cursor.getString(cursor.getColumnIndex("CKZY"   ));
                infob3n.qbdb   =cursor.getString(cursor.getColumnIndex("QBDB"   ));
                infob3n.hbdb   =cursor.getString(cursor.getColumnIndex("HBDB"   ));
                infob3n.zqcd   =cursor.getString(cursor.getColumnIndex("ZQCD"   ));
                infob3n.zhcd   =cursor.getString(cursor.getColumnIndex("ZHCD"   ));
                infob3n.yqcd   =cursor.getString(cursor.getColumnIndex("YQCD"   ));
                infob3n.yhcd   =cursor.getString(cursor.getColumnIndex("YHCD"   ));
                infob3n.z1cm   =cursor.getString(cursor.getColumnIndex("Z1CM"   ));
                infob3n.y1cm   =cursor.getString(cursor.getColumnIndex("Y1CM"   ));
                infob3n.y2cm   =cursor.getString(cursor.getColumnIndex("Y2CM"   ));
                infob3n.y3cm   =cursor.getString(cursor.getColumnIndex("Y3CM"   ));
                infob3n.zywp   =cursor.getString(cursor.getColumnIndex("ZYWP"   ));
                infob3n.sscd   =cursor.getString(cursor.getColumnIndex("SSCD"   ));

                infoB3N.add(infob3n);
            }
            cursor.close();
        }
        //db.close();
        return infoB3N;
    }

    public static List<InfoB4W> queryB4W(SQLiteDatabase db, String acc_ID_time){
        List<InfoB4W> infoB4W = null ;
        Cursor cursor = db.rawQuery("SELECT * FROM [baseinfo_b4w] where Acc_ID = ?", new String[]{acc_ID_time});
        if(cursor != null && cursor.getCount() > 0){

            infoB4W = new ArrayList<>();

            while (cursor.moveToNext()){
                InfoB4W infob4w = new InfoB4W();

                infob4w.acc_id =cursor.getString(cursor.getColumnIndex("Acc_ID"));
                infob4w.clsbdm =cursor.getString(cursor.getColumnIndex("CLSBDM"));
                //infob4w.myqs      =cursor.getString(cursor.getColumnIndex("MYQS"      ));
                //infob4w.qhbw      =cursor.getString(cursor.getColumnIndex("QHBW"      ));
                infob4w.ltzq      =cursor.getString(cursor.getColumnIndex("LTZQ"      ));
                infob4w.ltyq      =cursor.getString(cursor.getColumnIndex("LTYQ"      ));
                infob4w.ltzh      =cursor.getString(cursor.getColumnIndex("LTZH"      ));
                infob4w.ltyh      =cursor.getString(cursor.getColumnIndex("LTYH"      ));
                infob4w.lwzq      =cursor.getString(cursor.getColumnIndex("LWZQ"      ));
                infob4w.lwyq      =cursor.getString(cursor.getColumnIndex("LWYQ"      ));
                infob4w.lwzh      =cursor.getString(cursor.getColumnIndex("LWZH"      ));
                infob4w.lwyh      =cursor.getString(cursor.getColumnIndex("LWYH"      ));
                infob4w.cmzq      =cursor.getString(cursor.getColumnIndex("CMZQ"      ));
                infob4w.cmyq      =cursor.getString(cursor.getColumnIndex("CMYQ"      ));
                infob4w.cmzh      =cursor.getString(cursor.getColumnIndex("CMZH"      ));
                infob4w.cmyh      =cursor.getString(cursor.getColumnIndex("CMYH"      ));
                infob4w.cczq      =cursor.getString(cursor.getColumnIndex("CCZQ"      ));
                infob4w.ccyq      =cursor.getString(cursor.getColumnIndex("CCYQ"      ));
                infob4w.cczh      =cursor.getString(cursor.getColumnIndex("CCZH"      ));
                infob4w.ccyh      =cursor.getString(cursor.getColumnIndex("CCYH"      ));
                infob4w.yzbzq     =cursor.getString(cursor.getColumnIndex("YZBZQ"     ));
                infob4w.yzbyq     =cursor.getString(cursor.getColumnIndex("YZBYQ"     ));
                infob4w.yzbzh     =cursor.getString(cursor.getColumnIndex("YZBZH"     ));
                infob4w.yzbyh     =cursor.getString(cursor.getColumnIndex("YZBYH"     ));
                infob4w.cdzq      =cursor.getString(cursor.getColumnIndex("CDZQ"      ));
                infob4w.cdyq      =cursor.getString(cursor.getColumnIndex("CDYQ"      ));
                infob4w.cdzh      =cursor.getString(cursor.getColumnIndex("CDZH"      ));
                infob4w.cdyh      =cursor.getString(cursor.getColumnIndex("CDYH"      ));
                infob4w.hsjz      =cursor.getString(cursor.getColumnIndex("HSJZ"      ));
                infob4w.hsjy      =cursor.getString(cursor.getColumnIndex("HSJY"      ));
                infob4w.bxgqb     =cursor.getString(cursor.getColumnIndex("BXGQB"     ));
                infob4w.bxghb     =cursor.getString(cursor.getColumnIndex("BXGHB"     ));
                infob4w.fdblqb    =cursor.getString(cursor.getColumnIndex("FDBLQB"    ));
                infob4w.fdblhb    =cursor.getString(cursor.getColumnIndex("FDBLHB"    ));
                infob4w.ygqqb     =cursor.getString(cursor.getColumnIndex("YGQQB"     ));
                infob4w.ygqhb     =cursor.getString(cursor.getColumnIndex("YGQHB"     ));
                infob4w.jcg       =cursor.getString(cursor.getColumnIndex("JCG"       ));
                infob4w.dg        =cursor.getString(cursor.getColumnIndex("DG"        ));
                infob4w.tc        =cursor.getString(cursor.getColumnIndex("TC"        ));
                infob4w.hbxg      =cursor.getString(cursor.getColumnIndex("HBXG"      ));
                infob4w.dp        =cursor.getString(cursor.getColumnIndex("DP"        ));
                infob4w.pqg       =cursor.getString(cursor.getColumnIndex("PQG"       ));
                infob4w.chzhq     =cursor.getString(cursor.getColumnIndex("CHZHQ"     ));
                infob4w.wjcdxl    =cursor.getString(cursor.getColumnIndex("WJCDXL"    ));

                infoB4W.add(infob4w);
            }
            cursor.close();
        }
        //db.close();
        return infoB4W;
    }

    public static List<InfoB4N> queryB4N(SQLiteDatabase db, String acc_ID_time){
        List<InfoB4N> infoB4N = null ;
        Cursor cursor = db.rawQuery("SELECT * FROM [baseinfo_b4n] where Acc_ID = ?", new String[]{acc_ID_time});
        if(cursor != null && cursor.getCount() > 0){
            infoB4N = new ArrayList<>();
            while (cursor.moveToNext()){
                InfoB4N infob4n = new InfoB4N();

                infob4n.acc_id =cursor.getString(cursor.getColumnIndex("Acc_ID"));
                infob4n.clsbdm =cursor.getString(cursor.getColumnIndex("CLSBDM"));
                infob4n.wzA       =cursor.getString(cursor.getColumnIndex("WZA"       ));
                infob4n.dy        =cursor.getString(cursor.getColumnIndex("DY"        ));
                infob4n.dyxdcsscd =cursor.getString(cursor.getColumnIndex("DYXDCSSCD" ));
                infob4n.dldccwz   =cursor.getString(cursor.getColumnIndex("DLDCCWZ"   ));
                infob4n.kccdkwz   =cursor.getString(cursor.getColumnIndex("KCCDKWZ"   ));
                infob4n.mccdkwz   =cursor.getString(cursor.getColumnIndex("MCCDKWZ"   ));
                infob4n.cdqwz     =cursor.getString(cursor.getColumnIndex("CDQWZ"     ));
                infob4n.wkcz      =cursor.getString(cursor.getColumnIndex("WKCZ"      ));
                infob4n.eddy      =cursor.getString(cursor.getColumnIndex("EDDY"      ));
                infob4n.edrl      =cursor.getString(cursor.getColumnIndex("EDRL"      ));
                infob4n.czfs      =cursor.getString(cursor.getColumnIndex("CZFS"      ));
                infob4n.hdzt      =cursor.getString(cursor.getColumnIndex("HDZT"      ));
                infob4n.sbsscd    =cursor.getString(cursor.getColumnIndex("SBSSCD"    ));
                infob4n.xbsscd    =cursor.getString(cursor.getColumnIndex("XBSSCD"    ));
                infob4n.qbsscd    =cursor.getString(cursor.getColumnIndex("QBSSCD"    ));
                infob4n.hbsscd    =cursor.getString(cursor.getColumnIndex("HBSSCD"    ));
                infob4n.zcsscd    =cursor.getString(cursor.getColumnIndex("ZCSSCD"    ));
                infob4n.ycsscd    =cursor.getString(cursor.getColumnIndex("YCSSCD"    ));
                infob4n.dcdtlx    =cursor.getString(cursor.getColumnIndex("DCDTLX"    ));
                infob4n.dcdtxh    =cursor.getString(cursor.getColumnIndex("DCDTXH"    ));
                infob4n.dcdtedrl  =cursor.getString(cursor.getColumnIndex("DCDTEDRL"  ));
                infob4n.dcdteddy  =cursor.getString(cursor.getColumnIndex("DCDTEDDY"  ));
                infob4n.wzB       =cursor.getString(cursor.getColumnIndex("WZB"       ));
                infob4n.dcglxtsscd=cursor.getString(cursor.getColumnIndex("DCGLXTSSCD"));
                infob4n.ddj       =cursor.getString(cursor.getColumnIndex("DDJ"       ));
                infob4n.djkzq     =cursor.getString(cursor.getColumnIndex("DJKZQ"     ));
                infob4n.jsx       =cursor.getString(cursor.getColumnIndex("JSX"       ));
                infob4n.dyzhq     =cursor.getString(cursor.getColumnIndex("DYZHQ"     ));
                infob4n.gypdh     =cursor.getString(cursor.getColumnIndex("GYPDH"     ));
                infob4n.bxh       =cursor.getString(cursor.getColumnIndex("BXH"       ));
                infob4n.jqqg      =cursor.getString(cursor.getColumnIndex("JQQG"      ));
                infob4n.pqqg      =cursor.getString(cursor.getColumnIndex("PQQG"      ));
                infob4n.bsqlhq    =cursor.getString(cursor.getColumnIndex("BSQLHQ"    ));
                infob4n.zkzlqzkb  =cursor.getString(cursor.getColumnIndex("ZKZLQZKB"  ));
                infob4n.srq       =cursor.getString(cursor.getColumnIndex("SRQ"       ));
                infob4n.lqfs      =cursor.getString(cursor.getColumnIndex("LQFS"      ));
                infob4n.ABSkzq    =cursor.getString(cursor.getColumnIndex("ABSKZQ"    ));
                infob4n.zqd       =cursor.getString(cursor.getColumnIndex("ZQD"       ));
                infob4n.yqd       =cursor.getString(cursor.getColumnIndex("YQD"       ));
                infob4n.fdongj    =cursor.getString(cursor.getColumnIndex("FDONGJ"    ));
                infob4n.qdj       =cursor.getString(cursor.getColumnIndex("QDJ"       ));
                infob4n.fdianj    =cursor.getString(cursor.getColumnIndex("FDIANJ"    ));
                infob4n.ybb       =cursor.getString(cursor.getColumnIndex("YBB"       ));
                infob4n.zxp       =cursor.getString(cursor.getColumnIndex("ZXP"       ));
                infob4n.zyjxh     =cursor.getString(cursor.getColumnIndex("ZYJXH"     ));
                infob4n.dhkg      =cursor.getString(cursor.getColumnIndex("DHKG"      ));
                infob4n.yspbfq    =cursor.getString(cursor.getColumnIndex("YSPBFQ"    ));
                infob4n.gfj       =cursor.getString(cursor.getColumnIndex("GFJ"       ));
                infob4n.dyq       =cursor.getString(cursor.getColumnIndex("DYQ"       ));
                infob4n.stx       =cursor.getString(cursor.getColumnIndex("STX"       ));
                infob4n.zyfsx     =cursor.getString(cursor.getColumnIndex("ZYFSX"     ));
                infob4n.jswzy     =cursor.getString(cursor.getColumnIndex("JSWZY"     ));
                infob4n.fjszy     =cursor.getString(cursor.getColumnIndex("FJSZY"     ));
                infob4n.hpzy      =cursor.getString(cursor.getColumnIndex("HPZY"      ));
                infob4n.zqm       =cursor.getString(cursor.getColumnIndex("ZQM"       ));
                infob4n.yqm       =cursor.getString(cursor.getColumnIndex("YQM"       ));
                infob4n.zhm       =cursor.getString(cursor.getColumnIndex("ZHM"       ));
                infob4n.yhm       =cursor.getString(cursor.getColumnIndex("YHM"       ));
                infob4n.zhcd      =cursor.getString(cursor.getColumnIndex("ZHCD"      ));
                infob4n.yhcd      =cursor.getString(cursor.getColumnIndex("YHCD"      ));
                infob4n.zywp      =cursor.getString(cursor.getColumnIndex("ZYWP"      ));
                infob4n.sscd      =cursor.getString(cursor.getColumnIndex("SSCD"      ));

                infoB4N.add(infob4n);
            }
            cursor.close();
        }
        //db.close();
        return infoB4N;
    }

    public static List<InfoB5W> queryB5W(SQLiteDatabase db, String acc_ID_time){
        List<InfoB5W> infoB5W = null ;
        Cursor cursor = db.rawQuery("SELECT * FROM [baseinfo_b5w] where Acc_ID = ?", new String[]{acc_ID_time});
        if(cursor != null && cursor.getCount() > 0){
            infoB5W = new ArrayList<>();
            while (cursor.moveToNext()){
                InfoB5W infob5w = new InfoB5W();

                infob5w.acc_id =cursor.getString(cursor.getColumnIndex("Acc_ID"));
                infob5w.clsbdm =cursor.getString(cursor.getColumnIndex("CLSBDM"));
                //infob5w.myqs       =cursor.getString(cursor.getColumnIndex("MYQS"      ));
                //infob5w.qhbw       =cursor.getString(cursor.getColumnIndex("QHBW"      ));
                infob5w.ltz1       =cursor.getString(cursor.getColumnIndex("LTZ1"      ));
                infob5w.ltz2       =cursor.getString(cursor.getColumnIndex("LTZ2"      ));
                infob5w.ltz3       =cursor.getString(cursor.getColumnIndex("LTZ3"      ));
                infob5w.lty1       =cursor.getString(cursor.getColumnIndex("LTY1"      ));
                infob5w.lty2       =cursor.getString(cursor.getColumnIndex("LTY2"      ));
                infob5w.lty3       =cursor.getString(cursor.getColumnIndex("LTY3"      ));
                infob5w.lwz1       =cursor.getString(cursor.getColumnIndex("LWZ1"      ));
                infob5w.lwz2       =cursor.getString(cursor.getColumnIndex("LWZ2"      ));
                infob5w.lwz3       =cursor.getString(cursor.getColumnIndex("LWZ3"      ));
                infob5w.lwy1       =cursor.getString(cursor.getColumnIndex("LWY1"      ));
                infob5w.lwy2       =cursor.getString(cursor.getColumnIndex("LWY2"      ));
                infob5w.lwy3       =cursor.getString(cursor.getColumnIndex("LWY3"      ));
                infob5w.cmz1       =cursor.getString(cursor.getColumnIndex("CMZ1"      ));
                infob5w.cmy1       =cursor.getString(cursor.getColumnIndex("CMY1"      ));
                infob5w.cmy2       =cursor.getString(cursor.getColumnIndex("CMY2"      ));
                infob5w.cmy3       =cursor.getString(cursor.getColumnIndex("CMY3"      ));
                infob5w.cwbz1      =cursor.getString(cursor.getColumnIndex("CWBZ1"     ));
                infob5w.cwbz2      =cursor.getString(cursor.getColumnIndex("CWBZ2"     ));
                infob5w.cwbz3      =cursor.getString(cursor.getColumnIndex("CWBZ3"     ));
                infob5w.cwby1      =cursor.getString(cursor.getColumnIndex("CWBY1"     ));
                infob5w.cwby2      =cursor.getString(cursor.getColumnIndex("CWBY2"     ));
                infob5w.cwby3      =cursor.getString(cursor.getColumnIndex("CWBY3"     ));
                infob5w.cdz1       =cursor.getString(cursor.getColumnIndex("CDZ1"      ));
                infob5w.cdz2       =cursor.getString(cursor.getColumnIndex("CDZ2"      ));
                infob5w.cdy1       =cursor.getString(cursor.getColumnIndex("CDY1"      ));
                infob5w.cdy2       =cursor.getString(cursor.getColumnIndex("CDY2"      ));
                infob5w.hsjz       =cursor.getString(cursor.getColumnIndex("HSJZ"      ));
                infob5w.hsjy       =cursor.getString(cursor.getColumnIndex("HSJY"      ));
                infob5w.ccz1       =cursor.getString(cursor.getColumnIndex("CCZ1"      ));
                infob5w.ccz2       =cursor.getString(cursor.getColumnIndex("CCZ2"      ));
                infob5w.ccz3       =cursor.getString(cursor.getColumnIndex("CCZ3"      ));
                infob5w.ccz4       =cursor.getString(cursor.getColumnIndex("CCZ4"      ));
                infob5w.ccz5       =cursor.getString(cursor.getColumnIndex("CCZ5"      ));
                infob5w.ccz6       =cursor.getString(cursor.getColumnIndex("CCZ6"      ));
                infob5w.ccy1       =cursor.getString(cursor.getColumnIndex("CCY1"      ));
                infob5w.ccy2       =cursor.getString(cursor.getColumnIndex("CCY2"      ));
                infob5w.ccy3       =cursor.getString(cursor.getColumnIndex("CCY3"      ));
                infob5w.ccy4       =cursor.getString(cursor.getColumnIndex("CCY4"      ));
                infob5w.ccy5       =cursor.getString(cursor.getColumnIndex("CCY5"      ));
                infob5w.ccy6       =cursor.getString(cursor.getColumnIndex("CCY6"      ));
                infob5w.bxgqb      =cursor.getString(cursor.getColumnIndex("BXGQB"     ));
                infob5w.bxghb      =cursor.getString(cursor.getColumnIndex("BXGHB"     ));
                infob5w.fdblqb     =cursor.getString(cursor.getColumnIndex("FDBLQB"    ));
                infob5w.fdblhb     =cursor.getString(cursor.getColumnIndex("FDBLHB"    ));
                infob5w.ygqqb      =cursor.getString(cursor.getColumnIndex("YGQQB"     ));
                infob5w.ygqhb      =cursor.getString(cursor.getColumnIndex("YGQHB"     ));
                infob5w.dg         =cursor.getString(cursor.getColumnIndex("DG"        ));
                infob5w.dbkt       =cursor.getString(cursor.getColumnIndex("DBKT"      ));
                infob5w.dp         =cursor.getString(cursor.getColumnIndex("DP"        ));
                infob5w.pqg        =cursor.getString(cursor.getColumnIndex("PQG"       ));
                infob5w.chzhq      =cursor.getString(cursor.getColumnIndex("CHZHQ"     ));

                infoB5W.add(infob5w);
            }
            cursor.close();
        }
        //db.close();
        return infoB5W;
    }

    public static List<InfoB5N> queryB5N(SQLiteDatabase db, String acc_ID_time){
        List<InfoB5N> infoB5N = null ;
        Cursor cursor = db.rawQuery("SELECT * FROM [baseinfo_b5n] where Acc_ID = ?", new String[]{acc_ID_time});
        if(cursor != null && cursor.getCount() > 0){

            infoB5N = new ArrayList<>();

            while (cursor.moveToNext()){
                InfoB5N infob5n = new InfoB5N();

                infob5n.acc_id =cursor.getString(cursor.getColumnIndex("Acc_ID"));
                infob5n.clsbdm =cursor.getString(cursor.getColumnIndex("CLSBDM"));
                infob5n.wzA        =cursor.getString(cursor.getColumnIndex("WZA"       ));
                infob5n.dy         =cursor.getString(cursor.getColumnIndex("DY"        ));
                infob5n.dyxdcsscd  =cursor.getString(cursor.getColumnIndex("DYXDCSSCD" ));
                infob5n.dldccwz    =cursor.getString(cursor.getColumnIndex("DLDCCWZ"   ));
                infob5n.cdkwz      =cursor.getString(cursor.getColumnIndex("CDKWZ"     ));
                infob5n.cdqwz      =cursor.getString(cursor.getColumnIndex("CDQWZ"     ));
                infob5n.wkcz       =cursor.getString(cursor.getColumnIndex("WKCZ"      ));
                infob5n.eddy       =cursor.getString(cursor.getColumnIndex("EDDY"      ));
                infob5n.edrl       =cursor.getString(cursor.getColumnIndex("EDRL"      ));
                infob5n.czfs       =cursor.getString(cursor.getColumnIndex("CZFS"      ));
                infob5n.hdzt       =cursor.getString(cursor.getColumnIndex("HDZT"      ));
                infob5n.dldccsscd  =cursor.getString(cursor.getColumnIndex("DLDCCSSCD" ));
                infob5n.dcdtlx     =cursor.getString(cursor.getColumnIndex("DCDTLX"    ));
                infob5n.dcdtxh     =cursor.getString(cursor.getColumnIndex("DCDTXH"    ));
                infob5n.dcdtedrl   =cursor.getString(cursor.getColumnIndex("DCDTEDRL"  ));
                infob5n.dcdteddy   =cursor.getString(cursor.getColumnIndex("DCDTEDDY"  ));
                infob5n.wzB        =cursor.getString(cursor.getColumnIndex("WZB"       ));
                infob5n.dcglxtsscd =cursor.getString(cursor.getColumnIndex("DCGLXTSSCD"));
                infob5n.ddj        =cursor.getString(cursor.getColumnIndex("DDJ"       ));
                infob5n.djkzq      =cursor.getString(cursor.getColumnIndex("DJKZQ"     ));
                infob5n.jsx        =cursor.getString(cursor.getColumnIndex("JSX"       ));
                infob5n.dyzhq      =cursor.getString(cursor.getColumnIndex("DYZHQ"     ));
                infob5n.gypdh      =cursor.getString(cursor.getColumnIndex("GYPDH"     ));
                infob5n.bxh        =cursor.getString(cursor.getColumnIndex("BXH"       ));
                infob5n.jqqg       =cursor.getString(cursor.getColumnIndex("JQQG"      ));
                infob5n.pqqg       =cursor.getString(cursor.getColumnIndex("PQQG"      ));
                infob5n.bsqlhq     =cursor.getString(cursor.getColumnIndex("BSQLHQ"    ));
                infob5n.zkzlqzkb   =cursor.getString(cursor.getColumnIndex("ZKZLQZKB"  ));
                infob5n.srq        =cursor.getString(cursor.getColumnIndex("SRQ"       ));
                infob5n.lqfs       =cursor.getString(cursor.getColumnIndex("LQFS"      ));
                infob5n.ABSkzq     =cursor.getString(cursor.getColumnIndex("ABSKZQ"    ));
                infob5n.zqd        =cursor.getString(cursor.getColumnIndex("ZQD"       ));
                infob5n.yqd        =cursor.getString(cursor.getColumnIndex("YQD"       ));
                infob5n.fdongj     =cursor.getString(cursor.getColumnIndex("FDONGJ"    ));
                infob5n.qdj        =cursor.getString(cursor.getColumnIndex("QDJ"       ));
                infob5n.fdianj     =cursor.getString(cursor.getColumnIndex("FDIANJ"    ));
                infob5n.ybb        =cursor.getString(cursor.getColumnIndex("YBB"       ));
                infob5n.jxh        =cursor.getString(cursor.getColumnIndex("JXH"       ));
                infob5n.zxp        =cursor.getString(cursor.getColumnIndex("ZXP"       ));
                infob5n.dhkg       =cursor.getString(cursor.getColumnIndex("DHKG"      ));
                infob5n.gfj        =cursor.getString(cursor.getColumnIndex("GFJ"       ));
                infob5n.yspbfq     =cursor.getString(cursor.getColumnIndex("YSPBFQ"    ));
                infob5n.jtq        =cursor.getString(cursor.getColumnIndex("JTQ"       ));
                infob5n.jswzy      =cursor.getString(cursor.getColumnIndex("JSWZY"     ));
                infob5n.fjszy      =cursor.getString(cursor.getColumnIndex("FJSZY"     ));
                infob5n.ckzy       =cursor.getString(cursor.getColumnIndex("CKZY"      ));
                infob5n.qbdb       =cursor.getString(cursor.getColumnIndex("QBDB"      ));
                infob5n.hbdb       =cursor.getString(cursor.getColumnIndex("HBDB"      ));
                infob5n.zqcd       =cursor.getString(cursor.getColumnIndex("ZQCD"      ));
                infob5n.zhcd       =cursor.getString(cursor.getColumnIndex("ZHCD"      ));
                infob5n.yqcd       =cursor.getString(cursor.getColumnIndex("YQCD"      ));
                infob5n.yhcd       =cursor.getString(cursor.getColumnIndex("YHCD"      ));
                infob5n.z1cm       =cursor.getString(cursor.getColumnIndex("Z1CM"      ));
                infob5n.y1cm       =cursor.getString(cursor.getColumnIndex("Y1CM"      ));
                infob5n.y2cm       =cursor.getString(cursor.getColumnIndex("Y2CM"      ));
                infob5n.y3cm       =cursor.getString(cursor.getColumnIndex("Y3CM"      ));
                infob5n.zywp       =cursor.getString(cursor.getColumnIndex("ZYWP"      ));
                infob5n.sscd       =cursor.getString(cursor.getColumnIndex("SSCD"      ));

                infoB5N.add(infob5n);
            }
            cursor.close();
        }
        //db.close();
        return infoB5N;
    }

    public static List<String> convertDataToRowA1(InfoA1 data) {
        List<String> cells = new ArrayList<>();
        cells.add(data.acc_id);
        cells.add("1006");
        cells.add(data.time_find);
        cells.add(Integer.toString(data.car_num));
        cells.add(Integer.toString(data.hurt_num));
        String p=data.dqp;
        /*if(p!=null &&!p.isEmpty()) {
            if (p.contains("省") || p.contains("市")) {
                p = p.substring(0, p.length() - 1);
            }
        }
        cells.add(p);
        String c=data.dqc;
        if(c!=null &&!c.isEmpty()) {
            if(c.contains("市")){
                c=c.substring(0,c.length()-1);
            }
        }
        //cells.add(data.dqc);
        cells.add(c);
        String s=data.dqs;
        if(s!=null &&!s.isEmpty()) {
            if(s.contains("区")||s.contains("县")){
                s=s.substring(0,s.length()-1);
            }
        }
        cells.add(s);
        */
        cells.add(data.dqp);
        cells.add(data.dqc);
        cells.add(data.dqs);
        cells.add(data.jtwz);
        cells.add(Integer.toString(data.person_num));
        cells.add(data.caiji);
        cells.add(data.luru);
        cells.add(data.time_110);
        cells.add(data.time_survey);
        cells.add(data.yon_119);
        cells.add(data.time_119);
        cells.add(data.yon_120);
        cells.add(data.time_120);
        cells.add(data.state);
        cells.add("0");
        cells.add("");//cells.add(data.time_find);//插入数据库时间
        return cells;
    }

    public static List<String> convertDataToRowA2(InfoA2 data) {
        List<String> cells = new ArrayList<>();
        cells.add(data.acc_id);
        cells.add(data.sgdd);
        cells.add(data.yctqs);
        cells.add(Integer.toString(data.pd));
        cells.add(data.bmcz);
        cells.add(data.bmzk);
        cells.add(data.zwjk);
        cells.add(data.weather);
        cells.add(data.fx);
        cells.add(data.fl);
        cells.add(Integer.toString(data.fs));
        cells.add(Integer.toString(data.wd));
        cells.add(data.xcbh);
        cells.add(data.clbh);
        return cells;
    }

    public static List<String> convertDataToRowB(InfoB data, InfoBQH data2) {
        List<String> cells = new ArrayList<>();
        cells.add("0");
        cells.add(data.clsbdm);
        cells.add(data.acc_id);
        cells.add(data.ppxh);
        cells.add(data.clzcsj);
        cells.add(data.clxz);
        cells.add(Integer.toString(data.xslc));
        cells.add(Integer.toString(data.sfqxsjl));
        cells.add(Integer.toString(data.sfqxssj));
        cells.add(Integer.toString(data.sfqtfsj));
        cells.add(data.sfszt);
        cells.add(data.sfhtfwz);
        cells.add(data.zyfs);
        cells.add(data.sfjz);
        cells.add(data.jzsj);
        cells.add(data.jzbj);
        cells.add(data.jzwz);
        cells.add(data.zjwbsj);
        cells.add(data.wbmd);
        cells.add(data.wbnr);
        cells.add(data.gmbx);
        cells.add(data.tbsj);
        cells.add(data.tbxz);
        cells.add(data2.myqs);
        cells.add(data2.qhbw);
        cells.add(data.clzl);
        return cells;
    }

    public static List<String> convertDataToRowC(InfoC data) {
        List<String> cells = new ArrayList<>();
        Random random=new Random();
        StringBuilder str=new StringBuilder();
        for(int i=0;i<8;i++){
            str.append(random.nextInt(10));
        }
        //Integer rybh=Integer.parseInt(str.toString());
        cells.add(str.toString());//人员编号
        cells.add(data.acc_id);
        cells.add(data.rylx);
        cells.add(data.xb);
        cells.add(Integer.toString(data.nl));
        cells.add(data.dcdd);
        cells.add(data.dcfs);
        cells.add(data.sfxy);
        cells.add(data.sfyj);
        cells.add(data.ssqk);
        cells.add(data.ssbw);
        cells.add(data.clxn);
        cells.add(data.cqcsA);
        cells.add(data.fxsrywz);
        cells.add(Integer.toString(data.xjjl));
        cells.add(data.bmqhzyxx);
        cells.add(data.cqcsB);
        cells.add(data.wzA);
        cells.add(data.gdA);
        cells.add(Integer.toString(data.ztgdA));
        cells.add(data.wzB);
        cells.add(data.ys);
        cells.add(data.gdB);
        cells.add(Integer.toString(data.ztgdB));
        return cells;
    }

    public static List<String> convertDataToRowBB(InfoBB data) {
        List<String> cells = new ArrayList<>();
        cells.add("0");
        cells.add(data.clsbdm);//车辆
        cells.add(data.acc_id);
        cells.add(data.qfzywt1);
        cells.add(data.qfsscd1);
        cells.add(data.zczywt1);
        cells.add(data.zcsscd1);
        cells.add(data.yczywt1);
        cells.add(data.ycsscd1);
        cells.add(data.sfzywt1);
        cells.add(data.sfsscd1);
        cells.add(data.dmzywt1);
        cells.add(data.dmsscd1);
        cells.add(data.qfzywt2);
        cells.add(data.qfsscd2);
        cells.add(data.zczywt2);
        cells.add(data.zcsscd2);
        cells.add(data.yczywt2);
        cells.add(data.ycsscd2);
        cells.add(data.sfzywt2);
        cells.add(data.sfsscd2);
        cells.add(data.dmzywt2);
        cells.add(data.dmsscd2);
        cells.add(data.hfzywt1);
        cells.add(data.hfsscd1);
        cells.add(data.hfzywt2);
        cells.add(data.hfsscd2);
        return cells;
    }

    public static List<String> convertDataToRowBBB(InfoBBB data) {
        List<String> cells = new ArrayList<>();
        cells.add("0");
        cells.add(data.clsbdm);//车辆
        cells.add(data.acc_id);
        cells.add(data.zyssbjmc1);
        cells.add(data.zyssbjsscd1);
        cells.add(data.zsdqxl1);
        cells.add(data.fjdqxl1);
        cells.add(data.zyssbjmc2);
        cells.add(data.zyssbjsscd2);
        cells.add(data.zsdqxl2);
        cells.add(data.fjdqxl2);
        cells.add(data.zykrwmc1);
        cells.add(data.zykrwsscd1);
        cells.add(data.zykrwmc2);
        cells.add(data.zykrwsscd2);
        return cells;
    }

    public static List<String> convertDataToRowB1W(InfoB1W data) {
        List<String> cells = new ArrayList<>();
        cells.add("0");
        cells.add(data.acc_id);
        cells.add(data.clsbdm);//车辆
        cells.add(data.ltzq);
        cells.add(data.ltyq);
        cells.add(data.ltzh);
        cells.add(data.ltyh);
        cells.add(data.lwzq);
        cells.add(data.lwyq);
        cells.add(data.lwzh);
        cells.add(data.lwyh);
        cells.add(data.cmzq);
        cells.add(data.cmyq);
        cells.add(data.cmzh);
        cells.add(data.cmyh);
        cells.add(data.cczq);
        cells.add(data.ccyq);
        cells.add(data.cczh);
        cells.add(data.ccyh);
        cells.add(data.yzbzq);
        cells.add(data.yzbyq);
        cells.add(data.yzbzh);
        cells.add(data.yzbyh);
        cells.add(data.cdzq);
        cells.add(data.cdyq);
        cells.add(data.cdzh);
        cells.add(data.cdyh);
        cells.add(data.hsjzq);
        cells.add(data.hsjyq);
        cells.add(data.bxgqb);
        cells.add(data.bxghb);
        cells.add(data.fdblqb);
        cells.add(data.fdblhb);
        cells.add(data.ygqqb);
        cells.add(data.ygqhb);
        cells.add(data.fdjcg);
        cells.add(data.dg);
        cells.add(data.tc);
        cells.add(data.hbxg);
        cells.add(data.dp);
        cells.add(data.pqg);
        cells.add(data.chzhq);
        return cells;
    }

    public static List<String> convertDataToRowB1N(InfoB1N data) {
        List<String> cells = new ArrayList<>();
        cells.add("0");
        cells.add(data.acc_id);
        cells.add(data.clsbdm);//车辆
        cells.add(data.wz);
        cells.add(data.dy);
        cells.add(data.xdcsscd);
        cells.add(data.jykwz);
        cells.add(data.cz);
        cells.add(data.yl);
        cells.add(data.yxsscd);
        cells.add(data.fdongj);//发动机
        cells.add(data.jqqg);
        cells.add(data.fdianj);//发电机
        cells.add(data.pqqg);
        cells.add(data.qdj);//起动机
        cells.add(data.wlzyq);
        cells.add(data.dhxq);
        cells.add(data.lqyg);
        cells.add(data.jylqq);
        cells.add(data.qxyg);
        cells.add(data.kqlqq);
        cells.add(data.zdyg);
        cells.add(data.zkzlq);
        cells.add(data.zlzxyg);
        cells.add(data.bxh);
        cells.add(data.ktysj);
        cells.add(data.bsqlhq);
        cells.add(data.ABSkzq);
        cells.add(data.srq);
        cells.add(data.zqd);
        cells.add(data.lnq);
        cells.add(data.yqd);
        cells.add(data.lqfs);
        cells.add(data.ybb);
        cells.add(data.dyq);
        cells.add(data.zxp);
        cells.add(data.stx);
        cells.add(data.zyjxh);
        cells.add(data.zyfsx);
        cells.add(data.dhkg);
        cells.add(data.jswzy);
        cells.add(data.yspbfq);
        cells.add(data.fjszy);
        cells.add(data.gfj);//鼓风机
        cells.add(data.hpzy);
        cells.add(data.zqm);
        cells.add(data.yqm);
        cells.add(data.zhm);
        cells.add(data.yhm);
        cells.add(data.zhcd);
        cells.add(data.yhcd);
        cells.add(data.bt);
        cells.add(data.zywpA);
        cells.add(data.sscdA);
        cells.add(data.zywpB);
        cells.add(data.sscdB);
        return cells;
    }

    public static List<String> convertDataToRowB2W(InfoB2W data) {
        List<String> cells = new ArrayList<>();
        cells.add("0");//车辆编码
        cells.add(    data.acc_id);
        cells.add(    data.clsbdm);//车辆
        cells.add(    data.ltz1);
        cells.add(    data.ltz2);
        cells.add(    data.ltz3);
        cells.add(    data.ltz4);
        cells.add(    data.lty1);
        cells.add(    data.lty2);
        cells.add(    data.lty3);
        cells.add(    data.lty4);
        cells.add(    data.lwz1);
        cells.add(    data.lwz2);
        cells.add(    data.lwz3);
        cells.add(    data.lwz4);
        cells.add(    data.lwy1);
        cells.add(    data.lwy2);
        cells.add(    data.lwy3);
        cells.add(    data.lwy4);
        cells.add(    data.cmz1);
        cells.add(    data.cmz2);
        cells.add(    data.cmy1);
        cells.add(    data.cmy2);
        cells.add(    data.ccz1);
        cells.add(    data.ccz2);
        cells.add(    data.ccy1);
        cells.add(    data.ccy2);
        cells.add(    data.yzbz);
        cells.add(    data.yzby);
        cells.add(    data.cdz1);
        cells.add(    data.cdz2);
        cells.add(    data.cdz3);
        cells.add(    data.cdz4);
        cells.add(    data.cdy1);
        cells.add(    data.cdy2);
        cells.add(    data.cdy3);
        cells.add(    data.cdy4);
        cells.add(    data.hsjz);
        cells.add(    data.hsjy);
        cells.add(    data.bxgqb);
        cells.add(    data.bxghb);
        cells.add(    data.fdblqb);
        cells.add(    data.fdblhb);
        cells.add(    data.ygq);
        cells.add(    data.pzsx);
        cells.add(    data.jssdg);
        cells.add(    data.jsshwb);
        cells.add(    data.cxqbzc);
        cells.add(    data.cxhbzc);
        cells.add(    data.cxzbbzc);
        cells.add(    data.cxdbzc);
        cells.add(    data.cxybbzc);
        cells.add(    data.cxdb);
        cells.add(    data.dp);
        cells.add(    data.bt);
        cells.add(    data.pqg);
        cells.add(    data.chzhq);
        return cells;
    }

    public static List<String> convertDataToRowB2N(InfoB2N data) {
        List<String> cells = new ArrayList<>();
        cells.add("0");//车辆编码
        cells.add(    data.acc_id);
        cells.add(    data.clsbdm);//车辆
        cells.add(    data.wz);
        cells.add(    data.dy);
        cells.add(    data.xdcsscd);
        cells.add(    data.jykwz);
        cells.add(    data.cz);
        cells.add(    data.yl);
        cells.add(    data.yxsscd);
        cells.add(    data.fdongj);
        cells.add(    data.jqqg);
        cells.add(    data.fdianj);
        cells.add(    data.pqqg);
        cells.add(    data.qdj);//起动机
        cells.add(    data.wlzyq);
        cells.add(    data.cyb);
        cells.add(    data.lqyg);
        cells.add(    data.dhxq);
        cells.add(    data.qxyg);
        cells.add(    data.jylqq);
        cells.add(    data.zdyg);
        cells.add(    data.kqlqq);
        cells.add(    data.zlzxyg);
        cells.add(    data.zkzlq);
        cells.add(    data.ktysj);
        cells.add(    data.bxh);
        cells.add(    data.ABSkzq);
        cells.add(    data.bsqlhq);
        cells.add(    data.zqdA);
        cells.add(    data.srq);
        cells.add(    data.yqdA);
        cells.add(    data.lnq);
        cells.add(    data.lqfs);
        cells.add(    data.ybb);
        cells.add(    data.jxh);
        cells.add(    data.zxp);
        cells.add(    data.stx);
        cells.add(    data.gfj);
        cells.add(    data.jswzy);
        cells.add(    data.yspbfq);
        cells.add(    data.fjszy);
        cells.add(    data.dyq);
        cells.add(    data.hpzy);
        cells.add(    data.zqdB);
        cells.add(    data.yqdB);
        cells.add(    data.zqm);
        cells.add(    data.yqm);
        cells.add(    data.zhm);
        cells.add(    data.yhm);
        cells.add(    data.qbzc);
        cells.add(    data.hbzc);
        cells.add(    data.zbbzc);
        cells.add(    data.ybbzc);
        cells.add(    data.dbzc);
        cells.add(    data.db);
        cells.add(    data.zhcd);
        cells.add(    data.yhcd);
        cells.add(    data.zywp);
        cells.add(    data.sscd);
        return cells;
    }

    public static List<String> convertDataToRowB3W(InfoB3W data) {
        List<String> cells = new ArrayList<>();
        cells.add("0");//车辆编码
        cells.add(    data.acc_id);
        cells.add(    data.clsbdm);//车辆
        cells.add(        data.ltz1   );
        cells.add(    data.ltz2   );
        cells.add(    data.ltz3   );
        cells.add(    data.lty1   );
        cells.add(    data.lty2   );
        cells.add(    data.lty3   );
        cells.add(    data.lwz1   );
        cells.add(    data.lwz2   );
        cells.add(    data.lwz3   );
        cells.add(    data.lwy1   );
        cells.add(    data.lwy2   );
        cells.add(    data.lwy3   );
        cells.add(    data.cmz1   );
        cells.add(    data.cmy1   );
        cells.add(    data.cmy2   );
        cells.add(    data.cmy3   );
        cells.add(    data.cwbz1 );
        cells.add(    data.cwbz2  );
        cells.add(    data.cwbz3  );
        cells.add(    data.cwby1  );
        cells.add(    data.cwby2  );
        cells.add(    data.cwby3  );
        cells.add(    data.cdz1   );
        cells.add(    data.cdz2   );
        cells.add(    data.cdy1   );
        cells.add(    data.cdy2   );
        cells.add(    data.hsjz   );
        cells.add(    data.hsjy   );
        cells.add(    data.ccz1   );
        cells.add(    data.ccz2   );
        cells.add(    data.ccz3   );
        cells.add(    data.ccz4   );
        cells.add(    data.ccz5   );
        cells.add(    data.ccz6   );
        cells.add(    data.ccy1   );
        cells.add(    data.ccy2   );
        cells.add(    data.ccy3   );
        cells.add(    data.ccy4   );
        cells.add(    data.ccy5   );
        cells.add(    data.ccy6   );
        cells.add(    data.bxgqb  );
        cells.add(    data.bxghb  );
        cells.add(    data.fdblqb );
        cells.add(    data.fdblhb );
        cells.add(    data.ygqqb  );
        cells.add(    data.ygqhb  );
        cells.add(    data.dg     );
        cells.add(    data.dbkt   );
        cells.add(    data.dp     );
        cells.add(    data.pqg    );
        cells.add(    data.chzhq  );
        return cells;
    }
    public static List<String> convertDataToRowB3N(InfoB3N data) {
        List<String> cells = new ArrayList<>();
        cells.add("0");//车辆编码
        cells.add(    data.acc_id);
        cells.add(    data.clsbdm);//车辆
        cells.add(    data.wz     );
        cells.add(    data.dy     );
        cells.add(    data.xdcsscd);
        cells.add(    data.jykwz  );
        cells.add(    data.cz     );
        cells.add(    data.yl     );
        cells.add(    data.yxsscd );
        cells.add(   data.fdongj );
        cells.add(    data.jqqg   );
        cells.add(    data.fdianj );
        cells.add(    data.pqqg   );
        cells.add(    data.qdj    );
        cells.add(    data.wlzyq    );
        cells.add(    data.cyb    );
        cells.add(    data.lqyg   );
        cells.add(    data.hsq  );
        cells.add(    data.qxyg  );
        cells.add(    data.dhxq  );
        cells.add(    data.zdyg    );
        cells.add(    data.kqlqq );
        cells.add(    data.zlzxyg    );
        cells.add(    data.jylqq    );
        cells.add(    data.ktysj  );
        cells.add(    data.zkzlq  );
        cells.add(    data.ABSkzq  );
        cells.add(    data.bxh   );
        cells.add(    data.ktysj );
        cells.add(    data.bsqlhq  );
        cells.add(    data.lqfs   );
        cells.add(    data.srq  );
        cells.add(    data.dyzkg   );
        cells.add(    data.lnq );
        cells.add(    data.jxhA  );//jiexianhe
        cells.add(    data.ybb   );
        cells.add(    data.yspbfq   );//bofangqi
        cells.add(    data.jxhB   );
        cells.add(    data.jsq   );
        cells.add(    data.zxp    );
        cells.add(    data.jswzy  );
        cells.add(    data.dhkg  );
        cells.add(    data.fjszy  );
        cells.add(    data.gfj    );
        cells.add(    data.ckzy   );
        cells.add(    data.qbdb  );
        cells.add(    data.hbdb   );
        cells.add(    data.zqcd   );
        cells.add(    data.yqcd   );
        cells.add(    data.zhcd   );
        cells.add(    data.yhcd   );
        cells.add(    data.z1cm   );
        cells.add(    data.y1cm   );
        cells.add(    data.y2cm   );
        cells.add(    data.y3cm   );
        cells.add(    data.zywp   );
        cells.add(    data.sscd   );
        return cells;
    }

    public static List<String> convertDataToRowB4W(InfoB4W data) {
        List<String> cells = new ArrayList<>();
        cells.add("0");//车辆编码
        cells.add(    data.acc_id);
        cells.add(    data.clsbdm);//车辆
        cells.add(    data.ltzq);
        cells.add(    data.ltyq);
        cells.add(    data.ltzh);
        cells.add(    data.ltyh);
        cells.add(    data.lwzq);
        cells.add(    data.lwyq);
        cells.add(    data.lwzh);
        cells.add(    data.lwyh);
        cells.add(    data.cmzq);
        cells.add(    data.cmyq);
        cells.add(    data.cmzh);
        cells.add(    data.cmyh);
        cells.add(    data.cczq);
        cells.add(    data.ccyq);
        cells.add(    data.cczh);
        cells.add(    data.ccyh);
        cells.add(    data.yzbzq);
        cells.add(    data.yzbyq);
        cells.add(    data.yzbzh);
        cells.add(    data.yzbyh);
        cells.add(    data.cdzq);
        cells.add(    data.cdyq);
        cells.add(    data.cdzh);
        cells.add(    data.cdyh);
        cells.add(    data.hsjz);
        cells.add(    data.hsjy);
        cells.add(    data.bxgqb);
        cells.add(    data.bxghb);
        cells.add(    data.fdblqb);
        cells.add(    data.fdblhb);
        cells.add(    data.ygqqb);
        cells.add(    data.ygqhb);
        cells.add(    data.jcg);
        cells.add(    data.dg);
        cells.add(    data.tc);
        cells.add(    data.hbxg);
        cells.add(    data.dp);
        cells.add(    data.pqg);
        cells.add(    data.chzhq);
        cells.add(    data.wjcdxl);
        return cells;
    }


    public static List<String> convertDataToRowB4N(InfoB4N data) {

        List<String> cells = new ArrayList<>();
        cells.add("0");//车辆编码
        cells.add(    data.acc_id);
        cells.add(    data.clsbdm);//车辆
        cells.add(    data.wzA);
        cells.add(    data.dy);
        cells.add(    data.dyxdcsscd);
        cells.add(    data.dldccwz);
        cells.add(    data.kccdkwz);
        cells.add(    data.mccdkwz);
        cells.add(    data.cdqwz);
        cells.add(    data.wkcz);
        cells.add(    data.eddy);
        cells.add(    data.czfs);
        cells.add(    data.edrl);
        cells.add(    data.hdzt);
        cells.add(    data.sbsscd);
        cells.add(    data.xbsscd);
        cells.add(    data.zcsscd);
        cells.add(    data.ycsscd);
        cells.add(    data.qbsscd);
        cells.add(    data.hbsscd);
        cells.add(    data.dcdtlx);
        cells.add(    data.dcdtxh);
        cells.add(    data.dcdtedrl);
        cells.add(    data.dcdteddy);
        cells.add(    data.wzB);
        cells.add(    data.dcglxtsscd);
        cells.add(    data.ddj);
        cells.add(    data.zkzlqzkb);
        cells.add(    data.djkzq);
        cells.add(    data.srq);
        cells.add(    data.jsx);
        cells.add(    data.lqfs);
        cells.add(    data.dyzhq);
        cells.add(    data.ABSkzq);
        cells.add(    data.gypdh);
        cells.add(    data.zqd);
        cells.add(    data.bxh);
        cells.add(    data.yqd);
        cells.add(    data.jqqg);
        cells.add(    data.fdongj);
        cells.add(    data.pqqg);
        cells.add(    data.qdj);
        cells.add(    data.bsqlhq);
        cells.add(    data.fdianj);
        cells.add(    data.ybb);
        cells.add(    data.dyq);
        cells.add(    data.zxp);
        cells.add(    data.stx);
        cells.add(    data.zyjxh);
        cells.add(    data.zyfsx);
        cells.add(    data.dhkg);
        cells.add(    data.jswzy);
        cells.add(    data.yspbfq);
        cells.add(    data.fjszy);
        cells.add(    data.gfj);
        cells.add(    data.hpzy);
        cells.add(    data.zqm);
        cells.add(    data.yqm);
        cells.add(    data.zhm);
        cells.add(    data.yhm);
        cells.add(    data.zhcd);
        cells.add(    data.yhcd);
        cells.add(    data.zywp);
        cells.add(    data.sscd);
        return cells;
    }

    public static List<String> convertDataToRowB5W(InfoB5W data) {
        List<String> cells = new ArrayList<>();
        cells.add( "0");//车辆编码
        cells.add(    data.acc_id);
        cells.add(    data.clsbdm);//车辆
        cells.add(    data.ltz1      );
        cells.add(    data.ltz2      );
        cells.add(    data.ltz3      );
        cells.add(    data.lty1      );
        cells.add(    data.lty2      );
        cells.add(    data.lty3      );
        cells.add(    data.lwz1      );
        cells.add(    data.lwz2      );
        cells.add(    data.lwz3      );
        cells.add(    data.lwy1      );
        cells.add(    data.lwy2      );
        cells.add(    data.lwy3      );
        cells.add(    data.cmz1      );
        cells.add(    data.cmy1      );
        cells.add(    data.cmy2      );
        cells.add(    data.cmy3      );
        cells.add(    data.cwbz1     );
        cells.add(    data.cwbz2     );
        cells.add(    data.cwbz3     );
        cells.add(    data.cwby1     );
        cells.add(    data.cwby2     );
        cells.add(    data.cwby3     );
        cells.add(    data.cdz1      );
        cells.add(    data.cdz2      );
        cells.add(    data.cdy1      );
        cells.add(    data.cdy2      );
        cells.add(    data.hsjz     );
        cells.add(    data.hsjy      );
        cells.add(    data.ccz1      );
        cells.add(    data.ccz2      );
        cells.add(    data.ccz3      );
        cells.add(    data.ccz4      );
        cells.add(    data.ccz5      );
        cells.add(    data.ccz6      );
        cells.add(    data.ccy1      );
        cells.add(    data.ccy2      );
        cells.add(    data.ccy3      );
        cells.add(    data.ccy4      );
        cells.add(    data.ccy5      );
        cells.add(    data.ccy6      );
        cells.add(    data.bxgqb     );
        cells.add(    data.bxghb     );
        cells.add(    data.fdblqb    );
        cells.add(    data.fdblhb    );
        cells.add(    data.ygqqb     );
        cells.add(    data.ygqhb     );
        cells.add(    data.dg        );
        cells.add(    data.dbkt      );
        cells.add(    data.dp        );
        cells.add(    data.pqg       );
        cells.add(    data.chzhq     );
        return cells;
    }

    public static List<String> convertDataToRowB5N(InfoB5N data) {
        List<String> cells = new ArrayList<>();
        cells.add( "0");//车辆编码
        cells.add(    data.acc_id);
        cells.add(    data.clsbdm);//车辆
        cells.add(    data.wzA       );
        cells.add(    data.dy        );
        cells.add(    data.dyxdcsscd );
        cells.add(    data.dldccwz   );
        cells.add(    data.cdkwz     );
        cells.add(    data.cdqwz     );
        cells.add(    data.wkcz      );
        cells.add(    data.eddy      );
        cells.add(    data.czfs     );
        cells.add(    data.edrl      );
        cells.add(    data.hdzt      );
        cells.add(    data.dldccsscd );
        cells.add(    data.dcdtlx    );
        cells.add(    data.dcdtxh    );
        cells.add(    data.dcdtedrl  );
        cells.add(    data.dcdteddy  );
        cells.add(    data.wzB       );
        cells.add(    data.dcglxtsscd);
        cells.add(    data.ddj       );
        cells.add(    data.zkzlqzkb  );
        cells.add(    data.djkzq     );
        cells.add(    data.srq       );
        cells.add(    data.jsx       );
        cells.add(    data.lqfs      );
        cells.add(    data.dyzhq    );
        cells.add(    data.ABSkzq    );
        cells.add(    data.gypdh     );
        cells.add(    data.zqd       );
        cells.add(    data.bxh       );
        cells.add(    data.yqd       );
        cells.add(    data.jqqg      );
        cells.add(    data.fdongj    );
        cells.add(    data.pqqg      );
        cells.add(    data.qdj       );
        cells.add(    data.bsqlhq    );
        cells.add(    data.fdianj    );
        cells.add(    data.ybb       );
        cells.add(    data.yspbfq    );
        cells.add(    data.jxh       );
        cells.add(    data.jtq       );
        cells.add(    data.zxp       );
        cells.add(    data.jswzy     );
        cells.add(    data.dhkg      );
        cells.add(    data.fjszy     );
        cells.add(    data.gfj       );
        cells.add(    data.ckzy      );
        cells.add(    data.qbdb      );
        cells.add(    data.hbdb      );
        cells.add(    data.zqcd      );
        cells.add(    data.yqcd      );
        cells.add(    data.zhcd      );
        cells.add(    data.yhcd      );
        cells.add(    data.z1cm      );
        cells.add(    data.y1cm      );
        cells.add(    data.y2cm      );
        cells.add(    data.y3cm      );
        cells.add(    data.zywp      );
        cells.add(    data.sscd      );
        return cells;
    }



        public static List<String> CELL_HEADSA1;
    static {
        CELL_HEADSA1 = new ArrayList<>();
        CELL_HEADSA1.add("事故编号");
        CELL_HEADSA1.add("填报人ID");
        CELL_HEADSA1.add("发现时间");
        CELL_HEADSA1.add("涉及车辆数");
        CELL_HEADSA1.add("伤亡人数");
        CELL_HEADSA1.add("省");
        CELL_HEADSA1.add("市");
        CELL_HEADSA1.add("县");
        CELL_HEADSA1.add("详细地址");
        CELL_HEADSA1.add("涉及人员数");
        CELL_HEADSA1.add("采集人");
        CELL_HEADSA1.add("信息录入人");
        CELL_HEADSA1.add("警方到场时间");
        CELL_HEADSA1.add("调查时间");
        CELL_HEADSA1.add("是否有消防车到场");
        CELL_HEADSA1.add("消防车到场时间");
        CELL_HEADSA1.add("是否有救护车到场");
        CELL_HEADSA1.add("救护车到场时间");
        CELL_HEADSA1.add("现场形态");
        CELL_HEADSA1.add("状态");
        CELL_HEADSA1.add("插入数据库时间");
    }

    public static List<String> CELL_HEADSA2;
    static {
        CELL_HEADSA2 = new ArrayList<>();
        CELL_HEADSA2.add("事故编码");
        CELL_HEADSA2.add("事故地点");
        CELL_HEADSA2.add("沿车头趋势");
        CELL_HEADSA2.add("坡度");
        CELL_HEADSA2.add("表面材质");
        CELL_HEADSA2.add("表面状况");
        CELL_HEADSA2.add("周围监控");
        CELL_HEADSA2.add("天气");
        CELL_HEADSA2.add("风向");
        CELL_HEADSA2.add("风力");
        CELL_HEADSA2.add("风速");
        CELL_HEADSA2.add("温度");
        CELL_HEADSA2.add("现场保护");
        CELL_HEADSA2.add("车辆保护");
    }

    public static List<String> CELL_HEADSB;
    static {
        CELL_HEADSB = new ArrayList<>();
        CELL_HEADSB.add("车辆编码");
        CELL_HEADSB.add("车辆识别代码");
        CELL_HEADSB.add("事故编码");
        CELL_HEADSB.add("品牌型号");
        CELL_HEADSB.add("车辆注册时间");
        CELL_HEADSB.add("车辆性质");
        CELL_HEADSB.add("行驶里程");
        CELL_HEADSB.add("事发前行驶距离");
        CELL_HEADSB.add("事发前行驶时间");
        CELL_HEADSB.add("事发前停放时间");
        CELL_HEADSB.add("事发时状态");
        CELL_HEADSB.add("事发后停放位置");
        CELL_HEADSB.add("转移方式");
        CELL_HEADSB.add("是否加装");
        CELL_HEADSB.add("加装时间");
        CELL_HEADSB.add("加装部件");
        CELL_HEADSB.add("加装位置");
        CELL_HEADSB.add("最近维保时间");
        CELL_HEADSB.add("维保目的");
        CELL_HEADSB.add("维保内容");
        CELL_HEADSB.add("购买保险");
        CELL_HEADSB.add("投保时间");
        CELL_HEADSB.add("投保险种");
        CELL_HEADSB.add("蔓延趋势");
        CELL_HEADSB.add("起火部位");
        CELL_HEADSB.add("车辆种类");
    }

    public static List<String> CELL_HEADSC;
    static {
        CELL_HEADSC = new ArrayList<>();
        CELL_HEADSC.add("人员编号");
        CELL_HEADSC.add("事故编号");
        CELL_HEADSC.add("人员类型");
        CELL_HEADSC.add("性别");
        CELL_HEADSC.add("年龄");
        CELL_HEADSC.add("调查地点");
        CELL_HEADSC.add("调查方式");
        CELL_HEADSC.add("是否抽烟");
        CELL_HEADSC.add("是否喝酒");
        CELL_HEADSC.add("是否受伤");
        CELL_HEADSC.add("受伤位置");
        CELL_HEADSC.add("车辆性能");
        CELL_HEADSC.add("采取措施一");
        CELL_HEADSC.add("人员位置");
        CELL_HEADSC.add("距离");
        CELL_HEADSC.add("现象");
        CELL_HEADSC.add("采取措施二");
        CELL_HEADSC.add("火焰位置");
        CELL_HEADSC.add("火焰高度");
        CELL_HEADSC.add("火焰整体高度");
        CELL_HEADSC.add("烟气位置");
        CELL_HEADSC.add("烟气颜色");
        CELL_HEADSC.add("烟气高度");
        CELL_HEADSC.add("烟气整体高度");
    }

    public static List<String> CELL_HEADSBB;
    static {
        CELL_HEADSBB = new ArrayList<>();
        CELL_HEADSBB.add("车辆编码");
        CELL_HEADSBB.add("车辆识别代码");
        CELL_HEADSBB.add("事故编码");
        CELL_HEADSBB.add("前方物体一");
        CELL_HEADSBB.add("前方物体一烧损程度");
        CELL_HEADSBB.add("左侧物体一");
        CELL_HEADSBB.add("左侧物体一烧损程度");
        CELL_HEADSBB.add("右侧物体一");
        CELL_HEADSBB.add("右侧物体一烧损程度");
        CELL_HEADSBB.add("上方物体一");
        CELL_HEADSBB.add("上方物体一烧损程度");
        CELL_HEADSBB.add("地面物体一");
        CELL_HEADSBB.add("地面物体一烧损程度");
        CELL_HEADSBB.add("前方物体二");
        CELL_HEADSBB.add("前方物体二烧损程度");
        CELL_HEADSBB.add("左侧物体二");
        CELL_HEADSBB.add("左侧物体二烧损程度");
        CELL_HEADSBB.add("右侧物体二");
        CELL_HEADSBB.add("右侧物体二烧损程度");
        CELL_HEADSBB.add("上方物体二");
        CELL_HEADSBB.add("上方物体二烧损程度");
        CELL_HEADSBB.add("地面物体二");
        CELL_HEADSBB.add("地面物体二烧损程度");
        CELL_HEADSBB.add("后方物体一");
        CELL_HEADSBB.add("后方物体一烧损程度");
        CELL_HEADSBB.add("后方物体二");
        CELL_HEADSBB.add("后方物体二烧损程度");

    }

    public static List<String> CELL_HEADSBBB;
    static {
        CELL_HEADSBBB = new ArrayList<>();
        CELL_HEADSBBB.add("车辆编码");
        CELL_HEADSBBB.add("车辆识别代码");
        CELL_HEADSBBB.add("事故编码");
        CELL_HEADSBBB.add("主要烧损部件一");
        CELL_HEADSBBB.add("主要烧损部件一烧损程度");
        CELL_HEADSBBB.add("烧损部件一自身电路");
        CELL_HEADSBBB.add("烧损部件一附近电路");
        CELL_HEADSBBB.add("主要烧损部件二");
        CELL_HEADSBBB.add("主要烧损部件二烧损程度");
        CELL_HEADSBBB.add("烧损部件二自身电路");
        CELL_HEADSBBB.add("烧损部件二附近电路");
        CELL_HEADSBBB.add("主要可燃物一名称");
        CELL_HEADSBBB.add("主要可燃物一烧损程度");
        CELL_HEADSBBB.add("主要可燃物二名称");
        CELL_HEADSBBB.add("主要可燃物二烧损程度");
    }

    public static List<String> CELL_HEADSB1W;
    static {
        CELL_HEADSB1W = new ArrayList<>();
        CELL_HEADSB1W.add("车辆编码");
        CELL_HEADSB1W.add("事故编码");
        CELL_HEADSB1W.add("车辆识别代码");
        //CELL_HEADSB1W.add("蔓延趋势");
        //CELL_HEADSB1W.add("起火部位");
        CELL_HEADSB1W.add("轮胎左前");
        CELL_HEADSB1W.add("轮胎右前");
        CELL_HEADSB1W.add("轮胎左后");
        CELL_HEADSB1W.add("轮胎右后");
        CELL_HEADSB1W.add("轮辋左前");
        CELL_HEADSB1W.add("轮辋右前");
        CELL_HEADSB1W.add("轮辋左后");
        CELL_HEADSB1W.add("轮辋右后");
        CELL_HEADSB1W.add("车门左前");
        CELL_HEADSB1W.add("车门右前");
        CELL_HEADSB1W.add("车门左后");
        CELL_HEADSB1W.add("车门右后");
        CELL_HEADSB1W.add("车窗左前");
        CELL_HEADSB1W.add("车窗右前");
        CELL_HEADSB1W.add("车窗左后");
        CELL_HEADSB1W.add("车窗右后");
        CELL_HEADSB1W.add("翼子板左前");
        CELL_HEADSB1W.add("翼子板右前");
        CELL_HEADSB1W.add("翼子板左后");
        CELL_HEADSB1W.add("翼子板右后");
        CELL_HEADSB1W.add("车灯左前");
        CELL_HEADSB1W.add("车灯右前");
        CELL_HEADSB1W.add("车灯左后");
        CELL_HEADSB1W.add("车灯右后");
        CELL_HEADSB1W.add("后视镜左前");
        CELL_HEADSB1W.add("后视镜右前");
        CELL_HEADSB1W.add("保险杠前部");
        CELL_HEADSB1W.add("保险杠后部");
        CELL_HEADSB1W.add("风挡玻璃前部");
        CELL_HEADSB1W.add("风挡玻璃后部");
        CELL_HEADSB1W.add("雨刮器前部");
        CELL_HEADSB1W.add("雨刮器后部");
        CELL_HEADSB1W.add("发动机舱盖");
        CELL_HEADSB1W.add("顶盖");
        CELL_HEADSB1W.add("天窗");
        CELL_HEADSB1W.add("后备箱盖");
        CELL_HEADSB1W.add("底盘");
        CELL_HEADSB1W.add("排气管");
        CELL_HEADSB1W.add("催化转换器");
    }

    public static List<String> CELL_HEADSB1N;
    static {
        CELL_HEADSB1N = new ArrayList<>();

        CELL_HEADSB1N.add("车辆编码");
        CELL_HEADSB1N.add("事故编码");
        CELL_HEADSB1N.add("车辆识别代码");
        CELL_HEADSB1N.add("蓄电池位置");
        CELL_HEADSB1N.add("蓄电池电压");
        CELL_HEADSB1N.add("蓄电池烧损程度");
        CELL_HEADSB1N.add("油箱加油口位置");
        CELL_HEADSB1N.add("油箱材质");
        CELL_HEADSB1N.add("油箱油量");
        CELL_HEADSB1N.add("油箱烧损程度");
        CELL_HEADSB1N.add("发动机舱发动机");
        CELL_HEADSB1N.add("发动机舱进气歧管");
        CELL_HEADSB1N.add("发动机舱发电机");
        CELL_HEADSB1N.add("发动机舱排气歧管");
        CELL_HEADSB1N.add("发动机舱起动机");
        CELL_HEADSB1N.add("发动机舱涡轮增压器");
        CELL_HEADSB1N.add("发动机舱点火线圈");
        CELL_HEADSB1N.add("发动机舱冷却液罐");
        CELL_HEADSB1N.add("发动机舱机油滤清器");
        CELL_HEADSB1N.add("发动机舱清洗液罐");
        CELL_HEADSB1N.add("发动机舱空气滤清器");
        CELL_HEADSB1N.add("发动机舱制动液罐");
        CELL_HEADSB1N.add("发动机舱真空助力器");
        CELL_HEADSB1N.add("发动机舱助力转向液罐");
        CELL_HEADSB1N.add("发动机舱保险盒");
        CELL_HEADSB1N.add("发动机舱空调压缩机");
        CELL_HEADSB1N.add("发动机舱变速器离合器");
        CELL_HEADSB1N.add("发动机舱ABS控制器");
        CELL_HEADSB1N.add("发动机舱散热器");
        CELL_HEADSB1N.add("发动机舱左前灯");
        CELL_HEADSB1N.add("发动机舱冷凝器");
        CELL_HEADSB1N.add("发动机舱右前灯");
        CELL_HEADSB1N.add("发动机舱冷却风扇");
        CELL_HEADSB1N.add("驾驶室仪表板");
        CELL_HEADSB1N.add("驾驶室点烟器");
        CELL_HEADSB1N.add("驾驶室转向盘");
        CELL_HEADSB1N.add("驾驶室手套箱");
        CELL_HEADSB1N.add("驾驶室中央接线盒");
        CELL_HEADSB1N.add("驾驶室中央扶手箱");
        CELL_HEADSB1N.add("驾驶室点火开关");
        CELL_HEADSB1N.add("驾驶室驾驶位座椅");
        CELL_HEADSB1N.add("驾驶室音频播放器");
        CELL_HEADSB1N.add("驾驶室副驾驶座椅");
        CELL_HEADSB1N.add("驾驶室鼓风机");
        CELL_HEADSB1N.add("驾驶室后排座椅");
        CELL_HEADSB1N.add("驾驶室左前门");
        CELL_HEADSB1N.add("驾驶室右前门");
        CELL_HEADSB1N.add("驾驶室左后门");
        CELL_HEADSB1N.add("驾驶室右后门");
        CELL_HEADSB1N.add("后备箱左后车灯");
        CELL_HEADSB1N.add("后备箱右后车灯");
        CELL_HEADSB1N.add("后备箱备胎");
        CELL_HEADSB1N.add("后备箱主要物品一");
        CELL_HEADSB1N.add("后备箱物品一烧损程度");
        CELL_HEADSB1N.add("后备箱主要物品二");
        CELL_HEADSB1N.add("后备箱物品二烧损程度");
    }

    public static List<String> CELL_HEADSB2W;
    static {
        CELL_HEADSB2W = new ArrayList<>();
        CELL_HEADSB2W.add("车辆编码");
        CELL_HEADSB2W.add("事故编码");
        CELL_HEADSB2W.add("车辆识别代码");
        //CELL_HEADSB2W.add("蔓延趋势");
        //CELL_HEADSB2W.add("起火部位");
        CELL_HEADSB2W.add("轮胎左1");
        CELL_HEADSB2W.add("轮胎左2");
        CELL_HEADSB2W.add("轮胎左3");
        CELL_HEADSB2W.add("轮胎左4");
        CELL_HEADSB2W.add("轮胎右1");
        CELL_HEADSB2W.add("轮胎右2");
        CELL_HEADSB2W.add("轮胎右3");
        CELL_HEADSB2W.add("轮胎右4");
        CELL_HEADSB2W.add("轮辋左1");
        CELL_HEADSB2W.add("轮辋左2");
        CELL_HEADSB2W.add("轮辋左3");
        CELL_HEADSB2W.add("轮辋左4");
        CELL_HEADSB2W.add("轮辋右1");
        CELL_HEADSB2W.add("轮辋右2");
        CELL_HEADSB2W.add("轮辋右3");
        CELL_HEADSB2W.add("轮辋右4");
        CELL_HEADSB2W.add("车门左1");
        CELL_HEADSB2W.add("车门左2");
        CELL_HEADSB2W.add("车门右1");
        CELL_HEADSB2W.add("车门右2");
        CELL_HEADSB2W.add("车窗左1");
        CELL_HEADSB2W.add("车窗左2");
        CELL_HEADSB2W.add("车窗右1");
        CELL_HEADSB2W.add("车窗右2");
        CELL_HEADSB2W.add("翼子板左");
        CELL_HEADSB2W.add("翼子板右");
        CELL_HEADSB2W.add("车灯左1");
        CELL_HEADSB2W.add("车灯左2");
        CELL_HEADSB2W.add("车灯左3");
        CELL_HEADSB2W.add("车灯左4");
        CELL_HEADSB2W.add("车灯右1");
        CELL_HEADSB2W.add("车灯右2");
        CELL_HEADSB2W.add("车灯右3");
        CELL_HEADSB2W.add("车灯右4");
        CELL_HEADSB2W.add("后视镜左");
        CELL_HEADSB2W.add("后视镜右");
        CELL_HEADSB2W.add("保险杠前部");
        CELL_HEADSB2W.add("保险杠后部");
        CELL_HEADSB2W.add("风挡玻璃前部");
        CELL_HEADSB2W.add("风挡玻璃后部");
        CELL_HEADSB2W.add("雨刮器");
        CELL_HEADSB2W.add("膨胀水箱");
        CELL_HEADSB2W.add("驾驶室顶盖");
        CELL_HEADSB2W.add("驾驶室后围板");
        CELL_HEADSB2W.add("前板总成");
        CELL_HEADSB2W.add("后板总成");
        CELL_HEADSB2W.add("左边板总成");
        CELL_HEADSB2W.add("地板总成");
        CELL_HEADSB2W.add("右边板总成");
        CELL_HEADSB2W.add("顶板");
        CELL_HEADSB2W.add("底盘");
        CELL_HEADSB2W.add("备胎");
        CELL_HEADSB2W.add("排气管");
        CELL_HEADSB2W.add("催化转换器");
    }

    public static List<String> CELL_HEADSB2N;
    static {
        CELL_HEADSB2N = new ArrayList<>();
        CELL_HEADSB2N.add("车辆编码");
        CELL_HEADSB2N.add("事故编码");
        CELL_HEADSB2N.add("车辆识别代码");
        CELL_HEADSB2N.add("蓄电池位置");
        CELL_HEADSB2N.add("蓄电池电压");
        CELL_HEADSB2N.add("蓄电池烧损程度");
        CELL_HEADSB2N.add("油箱加油口位置");
        CELL_HEADSB2N.add("油箱材质");
        CELL_HEADSB2N.add("油箱油量");
        CELL_HEADSB2N.add("油箱烧损程度");
        CELL_HEADSB2N.add("发动机舱发动机");
        CELL_HEADSB2N.add("发动机舱进气歧管");
        CELL_HEADSB2N.add("发动机舱发电机");
        CELL_HEADSB2N.add("发动机舱排气歧管");
        CELL_HEADSB2N.add("发动机舱起动机");
        CELL_HEADSB2N.add("发动机舱涡轮增压器");
        CELL_HEADSB2N.add("发动机舱柴油泵");
        CELL_HEADSB2N.add("发动机舱冷却液罐");
        CELL_HEADSB2N.add("发动机舱点火线圈");
        CELL_HEADSB2N.add("发动机舱清洗液罐");
        CELL_HEADSB2N.add("发动机舱机油滤清器");
        CELL_HEADSB2N.add("发动机舱制动液罐");
        CELL_HEADSB2N.add("发动机舱空气滤清器");
        CELL_HEADSB2N.add("发动机舱助力转向液罐");
        CELL_HEADSB2N.add("发动机舱真空助力器");
        CELL_HEADSB2N.add("发动机舱空调压缩机");
        CELL_HEADSB2N.add("发动机舱保险盒");
        CELL_HEADSB2N.add("发动机舱ABS控制器");
        CELL_HEADSB2N.add("发动机舱变速器-离合器");
        CELL_HEADSB2N.add("发动机舱左前灯");
        CELL_HEADSB2N.add("发动机舱散热器");
        CELL_HEADSB2N.add("发动机舱右前灯");
        CELL_HEADSB2N.add("发动机舱冷凝器");
        CELL_HEADSB2N.add("发动机舱冷却风扇");
        CELL_HEADSB2N.add("驾驶室仪表板");
        CELL_HEADSB2N.add("驾驶室接线盒");
        CELL_HEADSB2N.add("驾驶室转向盘");
        CELL_HEADSB2N.add("驾驶室手套箱");
        CELL_HEADSB2N.add("驾驶室鼓风机");
        CELL_HEADSB2N.add("驾驶室驾驶位座椅");
        CELL_HEADSB2N.add("驾驶室音频播放器");
        CELL_HEADSB2N.add("驾驶室副驾驶座椅");
        CELL_HEADSB2N.add("驾驶室点烟器");
        CELL_HEADSB2N.add("驾驶室后排座椅");
        CELL_HEADSB2N.add("驾驶室驾驶室左前灯");
        CELL_HEADSB2N.add("驾驶室驾驶室右前灯");
        CELL_HEADSB2N.add("驾驶室左前门");
        CELL_HEADSB2N.add("驾驶室右前门");
        CELL_HEADSB2N.add("驾驶室左后门");
        CELL_HEADSB2N.add("驾驶室右后门");
        CELL_HEADSB2N.add("车厢前板总成");
        CELL_HEADSB2N.add("车厢后板总成");
        CELL_HEADSB2N.add("车厢左边板总成");
        CELL_HEADSB2N.add("车厢右边板总成");
        CELL_HEADSB2N.add("车厢地板总成");
        CELL_HEADSB2N.add("车厢顶板");
        CELL_HEADSB2N.add("车厢左后车灯");
        CELL_HEADSB2N.add("车厢右后车灯");
        CELL_HEADSB2N.add("车厢主要物品");
        CELL_HEADSB2N.add("车厢烧损程度");
    }

    public static List<String> CELL_HEADSB3W;
    static {
        CELL_HEADSB3W = new ArrayList<>();
        CELL_HEADSB3W.add("车辆编码");
        CELL_HEADSB3W.add("事故编码");
        CELL_HEADSB3W.add("车辆识别代码");
        //CELL_HEADSB3W.add("蔓延趋势");
        //CELL_HEADSB3W.add("起火部位");
        CELL_HEADSB3W.add("轮胎左1");
        CELL_HEADSB3W.add("轮胎左2");
        CELL_HEADSB3W.add("轮胎左3");
        CELL_HEADSB3W.add("轮胎右1");
        CELL_HEADSB3W.add("轮胎右2");
        CELL_HEADSB3W.add("轮胎右3");
        CELL_HEADSB3W.add("轮辋左1");
        CELL_HEADSB3W.add("轮辋左2");
        CELL_HEADSB3W.add("轮辋左3");
        CELL_HEADSB3W.add("轮辋右1");
        CELL_HEADSB3W.add("轮辋右2");
        CELL_HEADSB3W.add("轮辋右3");
        CELL_HEADSB3W.add("车门左1");
        CELL_HEADSB3W.add("车门右1");
        CELL_HEADSB3W.add("车门右2");
        CELL_HEADSB3W.add("车门右3");
        CELL_HEADSB3W.add("侧围板左1");
        CELL_HEADSB3W.add("侧围板左2");
        CELL_HEADSB3W.add("侧围板左3");
        CELL_HEADSB3W.add("侧围板右1");
        CELL_HEADSB3W.add("侧围板右2");
        CELL_HEADSB3W.add("侧围板右3");
        CELL_HEADSB3W.add("车灯左1");
        CELL_HEADSB3W.add("车灯左2");
        CELL_HEADSB3W.add("车灯右1");
        CELL_HEADSB3W.add("车灯右2");
        CELL_HEADSB3W.add("后视镜左");
        CELL_HEADSB3W.add("后视镜右");
        CELL_HEADSB3W.add("车窗左1");
        CELL_HEADSB3W.add("车窗左2");
        CELL_HEADSB3W.add("车窗左3");
        CELL_HEADSB3W.add("车窗左4");
        CELL_HEADSB3W.add("车窗左5");
        CELL_HEADSB3W.add("车窗左6");
        CELL_HEADSB3W.add("车窗右1");
        CELL_HEADSB3W.add("车窗右2");
        CELL_HEADSB3W.add("车窗右3");
        CELL_HEADSB3W.add("车窗右4");
        CELL_HEADSB3W.add("车窗右5");
        CELL_HEADSB3W.add("车窗右6");
        CELL_HEADSB3W.add("保险杠前部");
        CELL_HEADSB3W.add("保险杠后部");
        CELL_HEADSB3W.add("风挡玻璃前部");
        CELL_HEADSB3W.add("风挡玻璃后部");
        CELL_HEADSB3W.add("雨刮器前部");
        CELL_HEADSB3W.add("雨刮器后部");
        CELL_HEADSB3W.add("顶盖");
        CELL_HEADSB3W.add("顶部空调");
        CELL_HEADSB3W.add("底盘");
        CELL_HEADSB3W.add("排气管");
        CELL_HEADSB3W.add("催化转换器");
    }

    public static List<String> CELL_HEADSB3N;
    static {
        CELL_HEADSB3N = new ArrayList<>();
        CELL_HEADSB3N.add("车辆编码");
        CELL_HEADSB3N.add("事故编码");
        CELL_HEADSB3N.add("车辆识别代码");
        CELL_HEADSB3N.add("蓄电池位置");
        CELL_HEADSB3N.add("蓄电池电压");
        CELL_HEADSB3N.add("蓄电池烧损程度");
        CELL_HEADSB3N.add("油箱加油口位置");
        CELL_HEADSB3N.add("油箱材质");
        CELL_HEADSB3N.add("油箱油量");
        CELL_HEADSB3N.add("油箱烧损程度");
        CELL_HEADSB3N.add("发动机舱发动机");
        CELL_HEADSB3N.add("发动机舱进气歧管");
        CELL_HEADSB3N.add("发动机舱发电机");
        CELL_HEADSB3N.add("发动机舱排气歧管");
        CELL_HEADSB3N.add("发动机舱起动机");
        CELL_HEADSB3N.add("发动机舱涡轮增压器");
        CELL_HEADSB3N.add("发动机舱柴油泵");
        CELL_HEADSB3N.add("发动机舱冷却液罐");
        CELL_HEADSB3N.add("缓速器");
        CELL_HEADSB3N.add("发动机舱清洗液罐");
        CELL_HEADSB3N.add("发动机舱点火线圈");
        CELL_HEADSB3N.add("发动机舱制动液罐");
        CELL_HEADSB3N.add("发动机舱空气滤清器");
        CELL_HEADSB3N.add("发动机舱助力转向液罐");
        CELL_HEADSB3N.add("发动机舱机油滤清器");
        CELL_HEADSB3N.add("发动机舱空调压缩机");//
        CELL_HEADSB3N.add("发动机舱真空助力器");
        CELL_HEADSB3N.add("发动机舱ABS控制器");
        CELL_HEADSB3N.add("发动机舱保险盒");
        CELL_HEADSB3N.add("发动机舱空调压缩机");//
        CELL_HEADSB3N.add("发动机舱变速器-离合器");
        CELL_HEADSB3N.add("发动机舱冷却风扇");
        CELL_HEADSB3N.add("发动机舱散热器");
        CELL_HEADSB3N.add("电源总开关");
        CELL_HEADSB3N.add("发动机舱冷凝器");
        CELL_HEADSB3N.add("发动机舱接线盒");
        CELL_HEADSB3N.add("乘员舱仪表板");
        CELL_HEADSB3N.add("乘员舱播放器");
        CELL_HEADSB3N.add("乘员舱接线盒");
        CELL_HEADSB3N.add("乘员舱监视器");
        CELL_HEADSB3N.add("乘员舱转向器");
        CELL_HEADSB3N.add("乘员舱驾驶位座椅");
        CELL_HEADSB3N.add("乘员舱点火开关");
        CELL_HEADSB3N.add("乘员舱副驾驶座椅");
        CELL_HEADSB3N.add("乘员舱鼓风机");
        CELL_HEADSB3N.add("乘员舱乘客座椅");
        CELL_HEADSB3N.add("乘员舱前部地板");
        CELL_HEADSB3N.add("乘员舱后部地板");
        CELL_HEADSB3N.add("乘员舱左前车灯");
        CELL_HEADSB3N.add("乘员舱右前车灯");
        CELL_HEADSB3N.add("乘员舱左后车灯");
        CELL_HEADSB3N.add("乘员舱右后车灯");
        CELL_HEADSB3N.add("乘员舱左一车门");
        CELL_HEADSB3N.add("乘员舱右一车门");
        CELL_HEADSB3N.add("乘员舱右二车门");
        CELL_HEADSB3N.add("乘员舱右三车门");
        CELL_HEADSB3N.add("乘员舱主要物品");
        CELL_HEADSB3N.add("乘员舱烧损程度");
    }

    public static List<String> CELL_HEADSB4W;
    static {
        CELL_HEADSB4W = new ArrayList<>();
        CELL_HEADSB4W.add("车辆编码");
        CELL_HEADSB4W.add("事故编码");
        CELL_HEADSB4W.add("车辆识别代码");
        //CELL_HEADSB4W.add("蔓延趋势");
        //CELL_HEADSB4W.add("起火部位");
        CELL_HEADSB4W.add("轮胎左前");
        CELL_HEADSB4W.add("轮胎右前");
        CELL_HEADSB4W.add("轮胎左后");
        CELL_HEADSB4W.add("轮胎右后");
        CELL_HEADSB4W.add("轮辋左前");
        CELL_HEADSB4W.add("轮辋右前");
        CELL_HEADSB4W.add("轮辋左后");
        CELL_HEADSB4W.add("轮辋右后");
        CELL_HEADSB4W.add("车门左前");
        CELL_HEADSB4W.add("车门右前");
        CELL_HEADSB4W.add("车门左后");
        CELL_HEADSB4W.add("车门右后");
        CELL_HEADSB4W.add("车窗左前");
        CELL_HEADSB4W.add("车窗右前");
        CELL_HEADSB4W.add("车窗左后");
        CELL_HEADSB4W.add("车窗右后");
        CELL_HEADSB4W.add("翼子板左前");
        CELL_HEADSB4W.add("翼子板右前");
        CELL_HEADSB4W.add("翼子板左后");
        CELL_HEADSB4W.add("翼子板右后");
        CELL_HEADSB4W.add("车灯左前");
        CELL_HEADSB4W.add("车灯右前");
        CELL_HEADSB4W.add("车灯左后");
        CELL_HEADSB4W.add("车灯右后");
        CELL_HEADSB4W.add("后视镜左前");
        CELL_HEADSB4W.add("后视镜右前");
        CELL_HEADSB4W.add("保险杠前部");
        CELL_HEADSB4W.add("保险杠后部");
        CELL_HEADSB4W.add("风挡玻璃前部");
        CELL_HEADSB4W.add("风挡玻璃后部");
        CELL_HEADSB4W.add("雨刮器前部");
        CELL_HEADSB4W.add("雨刮器后部");
        CELL_HEADSB4W.add("发动机舱盖");
        CELL_HEADSB4W.add("顶盖");
        CELL_HEADSB4W.add("天窗");
        CELL_HEADSB4W.add("后备箱盖");
        CELL_HEADSB4W.add("底盘");
        CELL_HEADSB4W.add("排气管");
        CELL_HEADSB4W.add("催化转换器");
        CELL_HEADSB4W.add("外接充电线路");
    }

    public static List<String> CELL_HEADSB4N;
    static {
        CELL_HEADSB4N = new ArrayList<>();
        CELL_HEADSB4N.add("车辆编码");
        CELL_HEADSB4N.add("事故编码");
        CELL_HEADSB4N.add("车辆识别代码");
        CELL_HEADSB4N.add("蓄电池位置");
        CELL_HEADSB4N.add("蓄电池电压");
        CELL_HEADSB4N.add("蓄电池烧损程度");
        CELL_HEADSB4N.add("电池舱电池舱位置");
        CELL_HEADSB4N.add("电池舱快充电口位置");
        CELL_HEADSB4N.add("电池舱慢充电口位置");
        CELL_HEADSB4N.add("电池舱充电器位置");
        CELL_HEADSB4N.add("电池舱外壳材质");
        CELL_HEADSB4N.add("电池舱额定电压");
        CELL_HEADSB4N.add("电池舱成组方式");
        CELL_HEADSB4N.add("电池舱额定容量");
        CELL_HEADSB4N.add("电池舱荷电状态");
        CELL_HEADSB4N.add("电池舱上烧损程度");
        CELL_HEADSB4N.add("电池舱下烧损程度");
        CELL_HEADSB4N.add("电池舱左烧损程度");
        CELL_HEADSB4N.add("电池舱右烧损程度");
        CELL_HEADSB4N.add("电池舱前烧损程度");
        CELL_HEADSB4N.add("电池舱后烧损程度");
        CELL_HEADSB4N.add("电池舱电池类型");
        CELL_HEADSB4N.add("电池舱电池型号");
        CELL_HEADSB4N.add("电池单体额定容量");
        CELL_HEADSB4N.add("电池单体额定电压");
        CELL_HEADSB4N.add("电池管理系统位置");
        CELL_HEADSB4N.add("电池管理系统烧损程度");
        CELL_HEADSB4N.add("发动机舱电动机");
        CELL_HEADSB4N.add("发动机舱真空泵");
        CELL_HEADSB4N.add("发动机舱电机控制器");
        CELL_HEADSB4N.add("发动机舱散热器");
        CELL_HEADSB4N.add("发动机舱减速箱");
        CELL_HEADSB4N.add("发动机舱冷却风扇");
        CELL_HEADSB4N.add("发动机舱电压转换器");
        CELL_HEADSB4N.add("发动机舱ABS");
        CELL_HEADSB4N.add("发动机舱配电盒");
        CELL_HEADSB4N.add("发动机舱左前灯");
        CELL_HEADSB4N.add("发动机舱保险盒");
        CELL_HEADSB4N.add("发动机舱右前灯");
        CELL_HEADSB4N.add("发动机舱进气歧管");
        CELL_HEADSB4N.add("发动机舱发动机");
        CELL_HEADSB4N.add("发动机舱排气歧管");
        CELL_HEADSB4N.add("发动机舱起动机");
        CELL_HEADSB4N.add("发动机舱变速器离合器");
        CELL_HEADSB4N.add("发动机舱发电机");
        CELL_HEADSB4N.add("驾驶室仪表板");
        CELL_HEADSB4N.add("驾驶室点烟器");
        CELL_HEADSB4N.add("驾驶室转向盘");
        CELL_HEADSB4N.add("驾驶室手套箱");
        CELL_HEADSB4N.add("驾驶室中央接线盒");
        CELL_HEADSB4N.add("驾驶室中央扶手箱");
        CELL_HEADSB4N.add("驾驶室点火开关");
        CELL_HEADSB4N.add("驾驶室驾驶位座椅");
        CELL_HEADSB4N.add("驾驶室音频播放器");
        CELL_HEADSB4N.add("驾驶室副驾驶座椅");
        CELL_HEADSB4N.add("驾驶室鼓风机");
        CELL_HEADSB4N.add("驾驶室后排座椅");
        CELL_HEADSB4N.add("驾驶室左前门");
        CELL_HEADSB4N.add("驾驶室右前门");
        CELL_HEADSB4N.add("驾驶室左后门");
        CELL_HEADSB4N.add("驾驶室右后门");
        CELL_HEADSB4N.add("后备箱左后车灯");
        CELL_HEADSB4N.add("后备箱右后车灯");
        CELL_HEADSB4N.add("后备箱主要物品");
        CELL_HEADSB4N.add("后备箱烧损程度");
    }

    public static List<String> CELL_HEADSB5W;
    static {
        CELL_HEADSB5W = new ArrayList<>();
        CELL_HEADSB5W.add("车辆编码");
        CELL_HEADSB5W.add("事故编码");
        CELL_HEADSB5W.add("车辆识别代码");
        //CELL_HEADSB5W.add("蔓延趋势");
        //CELL_HEADSB5W.add("起火部位");
        CELL_HEADSB5W.add("轮胎左1");
        CELL_HEADSB5W.add("轮胎左2");
        CELL_HEADSB5W.add("轮胎左3");
        CELL_HEADSB5W.add("轮胎右1");
        CELL_HEADSB5W.add("轮胎右2");
        CELL_HEADSB5W.add("轮胎右3");
        CELL_HEADSB5W.add("轮辋左1");
        CELL_HEADSB5W.add("轮辋左2");
        CELL_HEADSB5W.add("轮辋左3");
        CELL_HEADSB5W.add("轮辋右1");
        CELL_HEADSB5W.add("轮辋右2");
        CELL_HEADSB5W.add("轮辋右3");
        CELL_HEADSB5W.add("车门左1");
        CELL_HEADSB5W.add("车门右1");
        CELL_HEADSB5W.add("车门右2");
        CELL_HEADSB5W.add("车门右3");
        CELL_HEADSB5W.add("侧围板左1");
        CELL_HEADSB5W.add("侧围板左2");
        CELL_HEADSB5W.add("侧围板左3");
        CELL_HEADSB5W.add("侧围板右1");
        CELL_HEADSB5W.add("侧围板右2");
        CELL_HEADSB5W.add("侧围板右3");
        CELL_HEADSB5W.add("车灯左1");
        CELL_HEADSB5W.add("车灯左2");
        CELL_HEADSB5W.add("车灯右1");
        CELL_HEADSB5W.add("车灯右2");
        CELL_HEADSB5W.add("后视镜左");
        CELL_HEADSB5W.add("后视镜右");
        CELL_HEADSB5W.add("车窗左1");
        CELL_HEADSB5W.add("车窗左2");
        CELL_HEADSB5W.add("车窗左3");
        CELL_HEADSB5W.add("车窗左4");
        CELL_HEADSB5W.add("车窗左5");
        CELL_HEADSB5W.add("车窗左6");
        CELL_HEADSB5W.add("车窗右1");
        CELL_HEADSB5W.add("车窗右2");
        CELL_HEADSB5W.add("车窗右3");
        CELL_HEADSB5W.add("车窗右4");
        CELL_HEADSB5W.add("车窗右5");
        CELL_HEADSB5W.add("车窗右6");
        CELL_HEADSB5W.add("保险杠前部");
        CELL_HEADSB5W.add("保险杠后部");
        CELL_HEADSB5W.add("风挡玻璃前部");
        CELL_HEADSB5W.add("风挡玻璃后部");
        CELL_HEADSB5W.add("雨刮器前部");
        CELL_HEADSB5W.add("雨刮器后部");
        CELL_HEADSB5W.add("顶盖");
        CELL_HEADSB5W.add("顶部空调");
        CELL_HEADSB5W.add("底盘");
        CELL_HEADSB5W.add("排气管");
        CELL_HEADSB5W.add("催化转换器");
    }

    public static List<String> CELL_HEADSB5N;
    static {
        CELL_HEADSB5N = new ArrayList<>();
        CELL_HEADSB5N.add("车辆编码");
        CELL_HEADSB5N.add("事故编码");
        CELL_HEADSB5N.add("车辆识别代码");
        CELL_HEADSB5N.add("蓄电池位置");
        CELL_HEADSB5N.add("蓄电池电压");
        CELL_HEADSB5N.add("蓄电池烧损程度");
        CELL_HEADSB5N.add("电池舱位置");
        CELL_HEADSB5N.add("电池舱充电口位置");
        CELL_HEADSB5N.add("电池舱充电器位置");
        CELL_HEADSB5N.add("电池舱外壳材质");
        CELL_HEADSB5N.add("电池舱额定电压");
        CELL_HEADSB5N.add("电池舱成组方式");
        CELL_HEADSB5N.add("电池舱额定容量");
        CELL_HEADSB5N.add("电池舱荷电状态");
        CELL_HEADSB5N.add("电池舱烧损程度");
        CELL_HEADSB5N.add("电池舱电池类型");
        CELL_HEADSB5N.add("电池舱电池型号");
        CELL_HEADSB5N.add("电池舱电池单体额定容量");
        CELL_HEADSB5N.add("电池舱电池单体额定电压");
        CELL_HEADSB5N.add("电池管理系统位置");
        CELL_HEADSB5N.add("电池管理系统烧损程度");
        CELL_HEADSB5N.add("发动机舱电动机");
        CELL_HEADSB5N.add("发动机舱真空泵");
        CELL_HEADSB5N.add("发动机舱电机控制器");
        CELL_HEADSB5N.add("发动机舱散热器");
        CELL_HEADSB5N.add("发动机舱减速箱");
        CELL_HEADSB5N.add("发动机舱冷却风扇");
        CELL_HEADSB5N.add("发动机舱电压转换器");
        CELL_HEADSB5N.add("发动机舱ABS");
        CELL_HEADSB5N.add("发动机舱配电盒");
        CELL_HEADSB5N.add("发动机舱左前灯");
        CELL_HEADSB5N.add("发动机舱保险盒");
        CELL_HEADSB5N.add("发动机舱右前灯");
        CELL_HEADSB5N.add("发动机舱进气歧管");
        CELL_HEADSB5N.add("发动机舱发动机");
        CELL_HEADSB5N.add("发动机舱排气歧管");
        CELL_HEADSB5N.add("发动机舱起动机");
        CELL_HEADSB5N.add("发动机舱变速器离合器");
        CELL_HEADSB5N.add("发动机舱发电机");
        CELL_HEADSB5N.add("乘员舱仪表板");
        CELL_HEADSB5N.add("乘员舱播放器");
        CELL_HEADSB5N.add("乘员舱接线盒");
        CELL_HEADSB5N.add("乘员舱监视器");
        CELL_HEADSB5N.add("乘员舱转向盘");
        CELL_HEADSB5N.add("乘员舱驾驶位座椅");
        CELL_HEADSB5N.add("乘员舱点火开关");
        CELL_HEADSB5N.add("乘员舱副驾驶座椅");
        CELL_HEADSB5N.add("乘员舱鼓风机");
        CELL_HEADSB5N.add("乘员舱乘客座椅");
        CELL_HEADSB5N.add("乘员舱前部地板");
        CELL_HEADSB5N.add("乘员舱后部地板");
        CELL_HEADSB5N.add("乘员舱左前车灯");
        CELL_HEADSB5N.add("乘员舱右前车灯");
        CELL_HEADSB5N.add("乘员舱左后车灯");
        CELL_HEADSB5N.add("乘员舱右后车灯");
        CELL_HEADSB5N.add("乘员舱车门左1");
        CELL_HEADSB5N.add("乘员舱车门右1");
        CELL_HEADSB5N.add("乘员舱车门右2");
        CELL_HEADSB5N.add("乘员舱车门右3");
        CELL_HEADSB5N.add("乘员舱主要物品");
        CELL_HEADSB5N.add("乘员舱烧损程度");
    }

}
