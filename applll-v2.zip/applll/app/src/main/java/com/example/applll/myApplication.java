package com.example.applll;

import android.app.Application;

import androidx.multidex.MultiDex;

public class myApplication extends Application {

    @Override
    public void onCreate(){
        super.onCreate();
        MultiDex.install(this);
    }

}
