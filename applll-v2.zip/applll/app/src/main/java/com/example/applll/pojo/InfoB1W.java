package com.example.applll.pojo;

public class InfoB1W {
    public String acc_id;
    public String clsbdm;
    //public String myqs;
    //public String qhbw;
    public String ltzq;
    public String ltyq;
    public String ltzh;
    public String ltyh;
    public String lwzq;
    public String lwyq;
    public String lwzh;
    public String lwyh;
    public String cmzq;
    public String cmyq;
    public String cmzh;
    public String cmyh;
    public String cczq;
    public String ccyq;
    public String cczh;
    public String ccyh;
    public String yzbzq;
    public String yzbyq;
    public String yzbzh;
    public String yzbyh;
    public String cdzq;
    public String cdyq;
    public String cdzh;
    public String cdyh;
    public String hsjzq;
    public String hsjyq;
    public String bxgqb;
    public String bxghb;
    public String fdblqb;
    public String fdblhb;
    public String ygqqb;
    public String ygqhb;
    public String fdjcg;
    public String dg;
    public String tc;
    public String hbxg;
    public String dp;
    public String pqg;
    public String chzhq;

}
