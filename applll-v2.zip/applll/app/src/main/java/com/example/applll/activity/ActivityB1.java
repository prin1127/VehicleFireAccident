package com.example.applll.activity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.applll.R;
import com.example.applll.Utility;
import com.example.applll.service.DbManger;
import com.example.applll.service.MySQLiteHelper;

public class ActivityB1 extends AppCompatActivity {

    private MySQLiteHelper helper= DbManger.getIntance(this);

    private String[] args1={"acc_ID","CLSBDM","LTZQ","LTYQ","LTZH","LTYH","LWZQ","LWYQ","LWZH","LWYH","CMZQ",
            "CMYQ","CMZH","CMYH","CCZQ","CCYQ","CCZH","CCYH","YZBZQ","YZBYQ","YZBZH","YZBYH","CDZQ","CDYQ",
            "CDZH","CDYH","HSJZQ","HSJYQ","BXGQB","BXGHB","FDBLQB","FDBLHB","YGQQB","YGQHB","FDJCG","DG","TC","HBXG",
            "DP","PQG","CHZHQ"};
    private String[] args3={"acc_ID","CLSBDM","WZ","DY","XDCSSCD","JYKWZ","CZ","YL","YXSSCD","FDONGJ","FDIANJ","QDJ","DHXQ",
            "JYLQQ","KQLQQ","ZKZLQ","BXH","BSQLHQ","SRQ","LNQ","LQFS","JQQG","PQQG","WLZYQ","LQYG","QXYG","ZDYG",
            "ZLZXYG","KTYSJ","ABSKZQ","ZQD","YQD","YBB","ZXP","ZYJXH","DHKG","YSPBFQ","GFJ","ZQM","ZHM","DYQ",
            "STX","ZYFSX","JSWZY","FJSZY","HPZY","YQM","YHM","BT","ZHCD","YHCD","ZYWPA","SSCDA","ZYWPB","SSCDB"};
    private String[] args10={"acc_ID","CLSBDM","MYQS","QHBW"};

    private TextView myqsshow,qhbwshow,ltzqshow,ltyqshow,ltzhshow,ltyhshow,lwzqshow,lwyqshow,lwzhshow,
            lwyhshow,cmzqshow,cmyqshow,cmzhshow,cmyhshow,cczqshow,ccyqshow,cczhshow,ccyhshow,
            yzbzqshow,yzbyqshow,yzbzhshow,yzbyhshow,cdzqshow,cdyqshow,cdzhshow,cdyhshow,hsjzqshow,
            hsjyqshow,bxgqbshow,bxghbshow,fdblqbshow,fdblhbshow,ygqqbshow,ygqhbshow,fdjcgshow,
            dgshow,tcshow,hbxgshow,dpshow,pqgshow,chzhqshow,wzshow,dyshow,xdcsscdshow,jykwzshow,
            czshow,ylshow,yxsscdshow,fdongjshow,fdianjshow,qdjshow,dhxqshow,jylqqshow,kqlqqshow,
            zkzlqshow,bxhshow,bsqlhqshow,srqshow,lnqshow,lqfsshow,jqqgshow,pqqgshow,wlzyqshow,
            lqygshow,qxygshow,zdygshow,zlzxygshow,ktysjshow,ABSkzqshow,zqdshow,yqdshow,ybbshow,
            zxpshow,zyjxhshow,dhkgshow,yspbfqshow,gfjshow,zqmshow,zhmshow,dyqshow,stxshow,zyfsxshow,
            jswzyshow,fjszyshow,hpzyshow,yqmshow,yhmshow,btshow,zhcdshow,yhcdshow,sscdAshow,sscdBshow;

    private Spinner myqs,qhbw,ltzq,ltyq,ltzh,ltyh,lwzq,lwyq,lwzh,lwyh,cmzq,cmyq,cmzh,cmyh,cczq,ccyq,cczh,
            ccyh,yzbzq,yzbyq,yzbzh,yzbyh,cdzq,cdyq,cdzh,cdyh,hsjzq,hsjyq,bxgqb,bxghb,fdblqb,fdblhb,
            ygqqb,ygqhb,fdjcg,dg,tc,hbxg,dp,pqg,chzhq,wz,dy,xdcsscd,jykwz,cz,yl,yxsscd,fdongj,fdianj,
            qdj,dhxq,jylqq,kqlqq,zkzlq,bxh,bsqlhq,srq,lnq,lqfs,jqqg,pqqg,wlzyq,lqyg,qxyg,zdyg,zlzxyg,
            ktysj,ABSkzq,zqd,yqd,ybb,zxp,zyjxh,dhkg,yspbfq,gfj,zqm,zhm,dyq,stx,zyfsx,jswzy,fjszy,hpzy,
            yqm,yhm,bt,zhcd,yhcd,sscdA,sscdB;

    private EditText zywpA,zywpB;
    String acc_ID_time,clsbdm,wjm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_b1);

        Intent intent0=getIntent();
        acc_ID_time=intent0.getStringExtra("acc_ID_time");
        wjm=intent0.getStringExtra("wjm");
        clsbdm=intent0.getStringExtra("clsbdm");
        myqsshow    =findViewById(R.id.b1_tv_show_myqs);
        qhbwshow = findViewById(R.id.b1_tv_show_qhbw);
        ltzqshow    =findViewById(R.id.b1_tv_show_ltzq);
        ltyqshow    =findViewById(R.id.b1_tv_show_ltyq);
        ltzhshow    =findViewById(R.id.b1_tv_show_ltzh);
        ltyhshow    =findViewById(R.id.b1_tv_show_ltyh);
        lwzqshow    =findViewById(R.id.b1_tv_show_lwzq);
        lwyqshow    =findViewById(R.id.b1_tv_show_lwyq);
        lwzhshow    =findViewById(R.id.b1_tv_show_lwzh);
        lwyhshow    =findViewById(R.id.b1_tv_show_lwyh);
        cmzqshow    =findViewById(R.id.b1_tv_show_cmzq);
        cmyqshow    =findViewById(R.id.b1_tv_show_cmyq);
        cmzhshow    =findViewById(R.id.b1_tv_show_cmzh);
        cmyhshow    =findViewById(R.id.b1_tv_show_cmyh);
        cczqshow    =findViewById(R.id.b1_tv_show_cczq);
        ccyqshow    =findViewById(R.id.b1_tv_show_ccyq);
        cczhshow    =findViewById(R.id.b1_tv_show_cczh);
        ccyhshow    =findViewById(R.id.b1_tv_show_ccyh);
        yzbzqshow   =findViewById(R.id.b1_tv_show_yzbzq);
        yzbyqshow   =findViewById(R.id.b1_tv_show_yzbyq);
        yzbzhshow   =findViewById(R.id.b1_tv_show_yzbzh);
        yzbyhshow   =findViewById(R.id.b1_tv_show_yzbyh);
        cdzqshow    =findViewById(R.id.b1_tv_show_cdzq);
        cdyqshow    =findViewById(R.id.b1_tv_show_cdyq);
        cdzhshow    =findViewById(R.id.b1_tv_show_cdzh);
        cdyhshow    =findViewById(R.id.b1_tv_show_cdyh);
        hsjzqshow   =findViewById(R.id.b1_tv_show_hsjzq);
        hsjyqshow   =findViewById(R.id.b1_tv_show_hsjyq);
        bxgqbshow   =findViewById(R.id.b1_tv_show_bxgqb);
        bxghbshow   =findViewById(R.id.b1_tv_show_bxghb);
        fdblqbshow  =findViewById(R.id.b1_tv_show_fdblqb);
        fdblhbshow  =findViewById(R.id.b1_tv_show_fdblhb);
        ygqqbshow   =findViewById(R.id.b1_tv_show_ygqqb);
        ygqhbshow   =findViewById(R.id.b1_tv_show_ygqhb);
        fdjcgshow   =findViewById(R.id.b1_tv_show_fdjcg);
        dgshow      =findViewById(R.id.b1_tv_show_dg);
        tcshow      =findViewById(R.id.b1_tv_show_tc);
        hbxgshow    =findViewById(R.id.b1_tv_show_hbxg);
        dpshow      =findViewById(R.id.b1_tv_show_dp);
        pqgshow     =findViewById(R.id.b1_tv_show_pqg);
        chzhqshow   =findViewById(R.id.b1_tv_show_chzhq);
        wzshow      =findViewById(R.id.b1_tv_show_wz);
        dyshow      =findViewById(R.id.b1_tv_show_dy);
        xdcsscdshow =findViewById(R.id.b1_tv_show_xdcsscd);
        jykwzshow   =findViewById(R.id.b1_tv_show_jykwz);
        czshow      =findViewById(R.id.b1_tv_show_cz);
        ylshow      =findViewById(R.id.b1_tv_show_yl);
        yxsscdshow  =findViewById(R.id.b1_tv_show_yxsscd);
        fdongjshow  =findViewById(R.id.b1_tv_show_fdongj);
        fdianjshow  =findViewById(R.id.b1_tv_show_fdianj);
        qdjshow     =findViewById(R.id.b1_tv_show_qdj);
        dhxqshow    =findViewById(R.id.b1_tv_show_dhxq);
        jylqqshow   =findViewById(R.id.b1_tv_show_jylqq);
        kqlqqshow   =findViewById(R.id.b1_tv_show_kqlqq);
        zkzlqshow   =findViewById(R.id.b1_tv_show_zkzlq);
        bxhshow     =findViewById(R.id.b1_tv_show_bxh);
        bsqlhqshow  =findViewById(R.id.b1_tv_show_bsqlhq);
        srqshow     =findViewById(R.id.b1_tv_show_srq);
        lnqshow     =findViewById(R.id.b1_tv_show_lnq);
        lqfsshow    =findViewById(R.id.b1_tv_show_lqfs);
        jqqgshow    =findViewById(R.id.b1_tv_show_jqqg);
        pqqgshow    =findViewById(R.id.b1_tv_show_pqqg);
        wlzyqshow   =findViewById(R.id.b1_tv_show_wlzyq);
        lqygshow    =findViewById(R.id.b1_tv_show_lqyg);
        qxygshow    =findViewById(R.id.b1_tv_show_qxyg);
        zdygshow    =findViewById(R.id.b1_tv_show_zdyg);
        zlzxygshow  =findViewById(R.id.b1_tv_show_zlzxyg);
        ktysjshow   =findViewById(R.id.b1_tv_show_ktysj);
        ABSkzqshow  =findViewById(R.id.b1_tv_show_ABSkzq);
        zqdshow     =findViewById(R.id.b1_tv_show_zqd);
        yqdshow     =findViewById(R.id.b1_tv_show_yqd);
        ybbshow     =findViewById(R.id.b1_tv_show_ybb);
        zxpshow     =findViewById(R.id.b1_tv_show_zxp);
        zyjxhshow   =findViewById(R.id.b1_tv_show_zyjxh);
        dhkgshow    =findViewById(R.id.b1_tv_show_dhkg);
        yspbfqshow  =findViewById(R.id.b1_tv_show_yspbfq);
        gfjshow     =findViewById(R.id.b1_tv_show_gfj);
        zqmshow     =findViewById(R.id.b1_tv_show_zqm);
        zhmshow     =findViewById(R.id.b1_tv_show_zhm);
        dyqshow     =findViewById(R.id.b1_tv_show_dyq);
        stxshow     =findViewById(R.id.b1_tv_show_stx);
        zyfsxshow   =findViewById(R.id.b1_tv_show_zyfsx);
        jswzyshow   =findViewById(R.id.b1_tv_show_jswzy);
        fjszyshow   =findViewById(R.id.b1_tv_show_fjszy);
        hpzyshow    =findViewById(R.id.b1_tv_show_hpzy);
        yqmshow     =findViewById(R.id.b1_tv_show_yqm);
        yhmshow     =findViewById(R.id.b1_tv_show_yhm);
        btshow      =findViewById(R.id.b1_tv_show_bt);
        zhcdshow    =findViewById(R.id.b1_tv_show_zhcd);
        yhcdshow    =findViewById(R.id.b1_tv_show_yhcd);
        sscdAshow   =findViewById(R.id.b1_tv_show_hbxsscdA);
        sscdBshow   =findViewById(R.id.b1_tv_show_hbxsscdB);

        myqs    =findViewById(R.id.b1_sp_myqs);
        qhbw = findViewById(R.id.b1_sp_qhbw);
        ltzq    =findViewById(R.id.b1_sp_ltzq);
        ltyq    =findViewById(R.id.b1_sp_ltyq);
        ltzh    =findViewById(R.id.b1_sp_ltzh);
        ltyh    =findViewById(R.id.b1_sp_ltyh);
        lwzq    =findViewById(R.id.b1_sp_lwzq);
        lwyq    =findViewById(R.id.b1_sp_lwyq);
        lwzh    =findViewById(R.id.b1_sp_lwzh);
        lwyh    =findViewById(R.id.b1_sp_lwyh);
        cmzq    =findViewById(R.id.b1_sp_cmzq);
        cmyq    =findViewById(R.id.b1_sp_cmyq);
        cmzh    =findViewById(R.id.b1_sp_cmzh);
        cmyh    =findViewById(R.id.b1_sp_cmyh);
        cczq    =findViewById(R.id.b1_sp_cczq);
        ccyq    =findViewById(R.id.b1_sp_ccyq);
        cczh    =findViewById(R.id.b1_sp_cczh);
        ccyh    =findViewById(R.id.b1_sp_ccyh);
        yzbzq   =findViewById(R.id.b1_sp_yzbzq);
        yzbyq   =findViewById(R.id.b1_sp_yzbyq);
        yzbzh   =findViewById(R.id.b1_sp_yzbzh);
        yzbyh   =findViewById(R.id.b1_sp_yzbyh);
        cdzq    =findViewById(R.id.b1_sp_cdzq);
        cdyq    =findViewById(R.id.b1_sp_cdyq);
        cdzh    =findViewById(R.id.b1_sp_cdzh);
        cdyh    =findViewById(R.id.b1_sp_cdyh);
        hsjzq   =findViewById(R.id.b1_sp_hsjzq);
        hsjyq   =findViewById(R.id.b1_sp_hsjyq);
        bxgqb   =findViewById(R.id.b1_sp_bxgqb);
        bxghb   =findViewById(R.id.b1_sp_bxghb);
        fdblqb  =findViewById(R.id.b1_sp_fdblqb);
        fdblhb  =findViewById(R.id.b1_sp_fdblhb);
        ygqqb   =findViewById(R.id.b1_sp_ygqqb);
        ygqhb   =findViewById(R.id.b1_sp_ygqhb);
        fdjcg   =findViewById(R.id.b1_sp_fdjcg);
        dg      =findViewById(R.id.b1_sp_dg);
        tc      =findViewById(R.id.b1_sp_tc);
        hbxg    =findViewById(R.id.b1_sp_hbxg);
        dp      =findViewById(R.id.b1_sp_dp);
        pqg     =findViewById(R.id.b1_sp_pqg);
        chzhq   =findViewById(R.id.b1_sp_chzhq);
        wz      =findViewById(R.id.b1_sp_wz);
        dy      =findViewById(R.id.b1_sp_dy);
        xdcsscd =findViewById(R.id.b1_sp_xdcsscd);
        jykwz   =findViewById(R.id.b1_sp_jykwz);
        cz      =findViewById(R.id.b1_sp_cz);
        yl      =findViewById(R.id.b1_sp_yl);
        yxsscd  =findViewById(R.id.b1_sp_yxsscd);
        fdongj  =findViewById(R.id.b1_sp_fdongj);
        fdianj  =findViewById(R.id.b1_sp_fdianj);
        qdj     =findViewById(R.id.b1_sp_qdj);
        dhxq    =findViewById(R.id.b1_sp_dhxq);
        jylqq   =findViewById(R.id.b1_sp_jylqq);
        kqlqq   =findViewById(R.id.b1_sp_kqlqq);
        zkzlq   =findViewById(R.id.b1_sp_zkzlq);
        bxh     =findViewById(R.id.b1_sp_bxh);
        bsqlhq  =findViewById(R.id.b1_sp_bsqlhq);
        srq     =findViewById(R.id.b1_sp_srq);
        lnq     =findViewById(R.id.b1_sp_lnq);
        lqfs    =findViewById(R.id.b1_sp_lqfs);
        jqqg    =findViewById(R.id.b1_sp_jqqg);
        pqqg    =findViewById(R.id.b1_sp_pqqg);
        wlzyq   =findViewById(R.id.b1_sp_wlzyq);
        lqyg    =findViewById(R.id.b1_sp_lqyg);
        qxyg    =findViewById(R.id.b1_sp_qxyg);
        zdyg    =findViewById(R.id.b1_sp_zdyg);
        zlzxyg  =findViewById(R.id.b1_sp_zlzxyg);
        ktysj   =findViewById(R.id.b1_sp_ktysj);
        ABSkzq  =findViewById(R.id.b1_sp_ABSkzq);
        zqd     =findViewById(R.id.b1_sp_zqd);
        yqd     =findViewById(R.id.b1_sp_yqd);
        ybb     =findViewById(R.id.b1_sp_ybb);
        zxp     =findViewById(R.id.b1_sp_zxp);
        zyjxh   =findViewById(R.id.b1_sp_zyjxh);
        dhkg    =findViewById(R.id.b1_sp_dhkg);
        yspbfq  =findViewById(R.id.b1_sp_yspbfq);
        gfj     =findViewById(R.id.b1_sp_gfj);
        zqm     =findViewById(R.id.b1_sp_zqm);
        zhm     =findViewById(R.id.b1_sp_zhm);
        dyq     =findViewById(R.id.b1_sp_dyq);
        stx     =findViewById(R.id.b1_sp_stx);
        zyfsx   =findViewById(R.id.b1_sp_zyfsx);
        jswzy   =findViewById(R.id.b1_sp_jswzy);
        fjszy   =findViewById(R.id.b1_sp_fjszy);
        hpzy    =findViewById(R.id.b1_sp_hpzy);
        yqm     =findViewById(R.id.b1_sp_yqm);
        yhm     =findViewById(R.id.b1_sp_yhm);
        bt      =findViewById(R.id.b1_sp_bt);
        zhcd    =findViewById(R.id.b1_sp_zhcd);
        yhcd    =findViewById(R.id.b1_sp_yhcd);
        sscdA   =findViewById(R.id.b1_sp_hbxsscdA);
        sscdB   =findViewById(R.id.b1_sp_hbxsscdB);

        zywpA=findViewById(R.id.b1_et_hbxzywpA);
        zywpB=findViewById(R.id.b1_et_hbxzywpB);

        Utility.ifOrnot(this,myqs,myqsshow);
        Utility.ifOrnot(this,qhbw,qhbwshow);
        Utility.ifOrnot(this,ltzq,ltzqshow);
        Utility.ifOrnot(this,ltyq,ltyqshow);
        Utility.ifOrnot(this,ltzh,ltzhshow);
        Utility.ifOrnot(this,ltyh,ltyhshow);
        Utility.ifOrnot(this,lwzq,lwzqshow);
        Utility.ifOrnot(this,lwyq,lwyqshow);
        Utility.ifOrnot(this,lwzh,lwzhshow);
        Utility.ifOrnot(this,lwyh,lwyhshow);
        Utility.ifOrnot(this,cmzq,cmzqshow);
        Utility.ifOrnot(this,cmyq,cmyqshow);
        Utility.ifOrnot(this,cmzh,cmzhshow);
        Utility.ifOrnot(this,cmyh,cmyhshow);
        Utility.ifOrnot(this,cczq,cczqshow);
        Utility.ifOrnot(this,ccyq,ccyqshow);
        Utility.ifOrnot(this,cczh,cczhshow);
        Utility.ifOrnot(this,ccyh,ccyhshow);
        Utility.ifOrnot(this,yzbzq,yzbzqshow);
        Utility.ifOrnot(this,yzbyq,yzbyqshow);
        Utility.ifOrnot(this,yzbzh,yzbzhshow);
        Utility.ifOrnot(this,yzbyh,yzbyhshow);
        Utility.ifOrnot(this,cdzq,cdzqshow);
        Utility.ifOrnot(this,cdyq,cdyqshow);
        Utility.ifOrnot(this,cdzh,cdzhshow);
        Utility.ifOrnot(this,cdyh,cdyhshow);
        Utility.ifOrnot(this,hsjzq,hsjzqshow);
        Utility.ifOrnot(this,hsjyq,hsjyqshow);
        Utility.ifOrnot(this,bxgqb,bxgqbshow);
        Utility.ifOrnot(this,bxghb,bxghbshow);
        Utility.ifOrnot(this,fdblqb,fdblqbshow);
        Utility.ifOrnot(this,fdblhb,fdblhbshow);
        Utility.ifOrnot(this,ygqqb,ygqqbshow);
        Utility.ifOrnot(this,ygqhb,ygqhbshow);
        Utility.ifOrnot(this,fdjcg,fdjcgshow);
        Utility.ifOrnot(this,dg,dgshow);
        Utility.ifOrnot(this,tc,tcshow);
        Utility.ifOrnot(this,hbxg,hbxgshow);
        Utility.ifOrnot(this,dp,dpshow);
        Utility.ifOrnot(this,pqg,pqgshow);
        Utility.ifOrnot(this,chzhq,chzhqshow);
        Utility.ifOrnot(this,wz,wzshow);
        Utility.ifOrnot(this,dy,dyshow);
        Utility.ifOrnot(this,xdcsscd,xdcsscdshow);
        Utility.ifOrnot(this,jykwz,jykwzshow);
        Utility.ifOrnot(this,cz,czshow);
        Utility.ifOrnot(this,yl,ylshow);
        Utility.ifOrnot(this,yxsscd,yxsscdshow);
        Utility.ifOrnot(this,fdongj,fdongjshow);
        Utility.ifOrnot(this,fdianj,fdianjshow);
        Utility.ifOrnot(this,qdj,qdjshow);
        Utility.ifOrnot(this,dhxq,dhxqshow);
        Utility.ifOrnot(this,jylqq,jylqqshow);
        Utility.ifOrnot(this,kqlqq,kqlqqshow);
        Utility.ifOrnot(this,zkzlq,zkzlqshow);
        Utility.ifOrnot(this,bxh,bxhshow);
        Utility.ifOrnot(this,bsqlhq,bsqlhqshow);
        Utility.ifOrnot(this,srq,srqshow);
        Utility.ifOrnot(this,lnq,lnqshow);
        Utility.ifOrnot(this,lqfs,lqfsshow);
        Utility.ifOrnot(this,jqqg,jqqgshow);
        Utility.ifOrnot(this,pqqg,pqqgshow);
        Utility.ifOrnot(this,wlzyq,wlzyqshow);
        Utility.ifOrnot(this,lqyg,lqygshow);
        Utility.ifOrnot(this,qxyg,qxygshow);
        Utility.ifOrnot(this,zdyg,zdygshow);
        Utility.ifOrnot(this,zlzxyg,zlzxygshow);
        Utility.ifOrnot(this,ktysj,ktysjshow);
        Utility.ifOrnot(this,ABSkzq,ABSkzqshow);
        Utility.ifOrnot(this,zqd,zqdshow);
        Utility.ifOrnot(this,yqd,yqdshow);
        Utility.ifOrnot(this,ybb,ybbshow);
        Utility.ifOrnot(this,zxp,zxpshow);
        Utility.ifOrnot(this,zyjxh,zyjxhshow);
        Utility.ifOrnot(this,dhkg,dhkgshow);
        Utility.ifOrnot(this,yspbfq,yspbfqshow);
        Utility.ifOrnot(this,gfj,gfjshow);
        Utility.ifOrnot(this,zqm,zqmshow);
        Utility.ifOrnot(this,zhm,zhmshow);
        Utility.ifOrnot(this,dyq,dyqshow);
        Utility.ifOrnot(this,stx,stxshow);
        Utility.ifOrnot(this,zyfsx,zyfsxshow);
        Utility.ifOrnot(this,jswzy,jswzyshow);
        Utility.ifOrnot(this,fjszy,fjszyshow);
        Utility.ifOrnot(this,hpzy,hpzyshow);
        Utility.ifOrnot(this,yqm,yqmshow);
        Utility.ifOrnot(this,yhm,yhmshow);
        Utility.ifOrnot(this,bt,btshow);
        Utility.ifOrnot(this,zhcd,zhcdshow);
        Utility.ifOrnot(this,yhcd,yhcdshow);
        Utility.ifOrnot(this,sscdA,sscdAshow);
        Utility.ifOrnot(this,sscdB,sscdBshow);
    }


    public void click(View view) {
        switch (view.getId()){
            case R.id.b1_btn_next:
                SQLiteDatabase db = helper.getWritableDatabase();

                String s1   =Utility.connect(myqs   ,myqsshow   );
                String s2 = Utility.connect(qhbw,qhbwshow);
                String s3   =Utility.connect(ltzq   ,ltzqshow   );
                String s4   =Utility.connect(ltyq   ,ltyqshow   );
                String s5   =Utility.connect(ltzh   ,ltzhshow   );
                String s6   =Utility.connect(ltyh   ,ltyhshow   );
                String s7   =Utility.connect(lwzq   ,lwzqshow   );
                String s8   =Utility.connect(lwyq   ,lwyqshow   );
                String s9   =Utility.connect(lwzh   ,lwzhshow   );
                String s10  =Utility.connect(lwyh   ,lwyhshow   );
                String s11  =Utility.connect(cmzq   ,cmzqshow   );
                String s12  =Utility.connect(cmyq   ,cmyqshow   );
                String s13  =Utility.connect(cmzh   ,cmzhshow   );
                String s14  =Utility.connect(cmyh   ,cmyhshow   );
                String s15  =Utility.connect(cczq   ,cczqshow   );
                String s16  =Utility.connect(ccyq   ,ccyqshow   );
                String s17  =Utility.connect(cczh   ,cczhshow   );
                String s18  =Utility.connect(ccyh   ,ccyhshow   );
                String s19  =Utility.connect(yzbzq  ,yzbzqshow  );
                String s20  =Utility.connect(yzbyq  ,yzbyqshow  );
                String s21  =Utility.connect(yzbzh  ,yzbzhshow  );
                String s22  =Utility.connect(yzbyh  ,yzbyhshow  );
                String s23  =Utility.connect(cdzq   ,cdzqshow   );
                String s24  =Utility.connect(cdyq   ,cdyqshow   );
                String s25  =Utility.connect(cdzh   ,cdzhshow   );
                String s26  =Utility.connect(cdyh   ,cdyhshow   );
                String s27  =Utility.connect(hsjzq  ,hsjzqshow  );
                String s28  =Utility.connect(hsjyq  ,hsjyqshow  );
                String s29  =Utility.connect(bxgqb  ,bxgqbshow  );
                String s30  =Utility.connect(bxghb  ,bxghbshow  );
                String s31  =Utility.connect(fdblqb ,fdblqbshow );
                String s32  =Utility.connect(fdblhb ,fdblhbshow );
                String s33  =Utility.connect(ygqqb  ,ygqqbshow  );
                String s34  =Utility.connect(ygqhb  ,ygqhbshow  );
                String s35  =Utility.connect(fdjcg  ,fdjcgshow  );
                String s36  =Utility.connect(dg     ,dgshow     );
                String s37  =Utility.connect(tc     ,tcshow     );
                String s38  =Utility.connect(hbxg   ,hbxgshow   );
                String s39  =Utility.connect(dp     ,dpshow     );
                String s40  =Utility.connect(pqg    ,pqgshow    );
                String s41  =Utility.connect(chzhq  ,chzhqshow  );
                String s42  =Utility.connect(wz     ,wzshow     );
                String s43  =Utility.connect(dy     ,dyshow     );
                String s44  =Utility.connect(xdcsscd,xdcsscdshow);
                String s45  =Utility.connect(jykwz  ,jykwzshow  );
                String s46  =Utility.connect(cz     ,czshow     );
                String s47  =Utility.connect(yl     ,ylshow     );
                String s48  =Utility.connect(yxsscd ,yxsscdshow );
                String s49  =Utility.connect(fdongj ,fdongjshow );
                String s50  =Utility.connect(fdianj ,fdianjshow );
                String s51  =Utility.connect(qdj    ,qdjshow    );
                String s52  =Utility.connect(dhxq   ,dhxqshow   );
                String s53  =Utility.connect(jylqq  ,jylqqshow  );
                String s54  =Utility.connect(kqlqq  ,kqlqqshow  );
                String s55  =Utility.connect(zkzlq  ,zkzlqshow  );
                String s56  =Utility.connect(bxh    ,bxhshow    );
                String s57  =Utility.connect(bsqlhq ,bsqlhqshow );
                String s58  =Utility.connect(srq    ,srqshow    );
                String s59  =Utility.connect(lnq    ,lnqshow    );
                String s60  =Utility.connect(lqfs   ,lqfsshow   );
                String s61  =Utility.connect(jqqg   ,jqqgshow   );
                String s62  =Utility.connect(pqqg   ,pqqgshow   );
                String s63  =Utility.connect(wlzyq  ,wlzyqshow  );
                String s64  =Utility.connect(lqyg   ,lqygshow   );
                String s65  =Utility.connect(qxyg   ,qxygshow   );
                String s66  =Utility.connect(zdyg   ,zdygshow   );
                String s67  =Utility.connect(zlzxyg ,zlzxygshow );
                String s68  =Utility.connect(ktysj  ,ktysjshow  );
                String s69  =Utility.connect(ABSkzq ,ABSkzqshow );
                String s70  =Utility.connect(zqd    ,zqdshow    );
                String s71  =Utility.connect(yqd    ,yqdshow    );
                String s72  =Utility.connect(ybb    ,ybbshow    );
                String s73  =Utility.connect(zxp    ,zxpshow    );
                String s74  =Utility.connect(zyjxh  ,zyjxhshow  );
                String s75  =Utility.connect(dhkg   ,dhkgshow   );
                String s76  =Utility.connect(yspbfq ,yspbfqshow );
                String s77  =Utility.connect(gfj    ,gfjshow    );
                String s78  =Utility.connect(zqm    ,zqmshow    );
                String s79  =Utility.connect(zhm    ,zhmshow    );
                String s80  =Utility.connect(dyq    ,dyqshow    );
                String s81  =Utility.connect(stx    ,stxshow    );
                String s82  =Utility.connect(zyfsx  ,zyfsxshow  );
                String s83  =Utility.connect(jswzy  ,jswzyshow  );
                String s84  =Utility.connect(fjszy  ,fjszyshow  );
                String s85  =Utility.connect(hpzy   ,hpzyshow   );
                String s86  =Utility.connect(yqm    ,yqmshow    );
                String s87  =Utility.connect(yhm    ,yhmshow    );
                String s88  =Utility.connect(bt     ,btshow     );
                String s89  =Utility.connect(zhcd   ,zhcdshow   );
                String s90  =Utility.connect(yhcd   ,yhcdshow   );
                String s92  =Utility.connect(sscdA  ,sscdAshow  );
                String s94  =Utility.connect(sscdB  ,sscdBshow  );
                String s91  =zywpA.getText().toString();
                String s93  =zywpB.getText().toString();

                String[] args2={acc_ID_time,clsbdm,s3,s4,s5,s6,s7,s8,s9,s10,s11,s12,s13,s14,s15,s16,s17,s18,s19,
                        s20,s21,s22,s23,s24,s25,s26,s27,s28,s29,s30,s31,s32,s33,s34,s35,s36,s37,s38,
                        s39,s40,s41};
                String[] args4={acc_ID_time,clsbdm,s42,s43,s44,s45,s46,s47,s48,s49,s50,s51,s52,s53,s54,s55,s56,s57,
                        s58,s59,s60,s61,s62,s63,s64,s65,s66,s67,s68,s69,s70,s71,s72,s73,s74,s75,s76,
                        s77,s78,s79,s80,s81,s82,s83,s84,s85,s86,s87,s88,s89,s90,s91,s92,s93,s94};
                String[] args20={acc_ID_time,clsbdm,s1,s2};

                Utility.insert(db,"baseinfo_bqh",args10,args20);
                Utility.insert(db,"baseinfo_b1W",args1,args2);
                Utility.insert(db,"baseinfo_b1N",args3,args4);

                Intent intent = new Intent(ActivityB1.this, ActivityBB.class);
                //intent.putExtra("clsbdm",clsbdm);
                intent.putExtra("acc_ID_time",acc_ID_time);
                intent.putExtra("wjm",wjm);
                intent.putExtra("clsbdm",clsbdm);
                startActivity(intent);
                break;

            case R.id.b1_btn_photo:
                Intent intent_camera = new Intent(ActivityB1.this, CameraActivity.class);
                intent_camera.putExtra("wjm",wjm);
                startActivity(intent_camera);
                break;
        }
    }
}

